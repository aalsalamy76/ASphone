# Contribuer à A.Sphone

Merci de votre intérêt. Cette section décrit ce qui est attendu avant d'ouvrir une pull request.

## Mise en place

1. Installer un JDK 17 et le SDK Android (plateforme 35).
2. Cloner le dépôt, puis lancer `./gradlew --no-daemon assembleDebug` pour vérifier que le build passe.

## Règles de confidentialité (non négociables)

- Ne jamais écrire dans les journaux (`Log`) un contenu de SMS, un numéro complet, un nom de contact, une traduction, une phrase secrète ou une clé.
- Les tests ne doivent jamais passer un appel réel ni envoyer un SMS réel. Utilisez des substituts.
- Ne jamais ajouter de permission `INTERNET`.
- Ne jamais fusionner, supprimer ou modifier automatiquement un contact sans action explicite de l'utilisateur.
- Ne jamais committer de keystore, de mot de passe, de `local.properties` ou de `google-services.json`.

## Conventions de code

- Kotlin idiomatique, Jetpack Compose et Material 3, injection avec Hilt, base Room.
- Le formatage et l'analyse statique doivent passer : `./gradlew --no-daemon ktlintCheck detekt`.
- L'ordre des imports suit le style ktlint : `*`, `java.**`, `javax.**`, `kotlin.**`, puis les alias.
- Tout nouveau texte visible est une ressource : ajoutez la clé dans `values/strings.xml` **et** dans les cinq autres fichiers `values-*/strings.xml`. Les marqueurs de format (`%1$s`, `%1$d`) doivent être identiques dans toutes les langues.
- La logique métier pure va dans `core:common` ou `core:model`, avec des tests unitaires.

## Tests

- Tout changement de logique métier doit être accompagné de tests unitaires.
- Lancer `./gradlew --no-daemon testDebugUnitTest` avant d'ouvrir la pull request.

## Pull requests

- Une pull request = une intention claire. Décrivez le « pourquoi » dans le corps.
- Renseignez la case à cocher de confidentialité du modèle de pull request.
- Les workflows CI doivent passer. Un échec de lint, de détekt ou de tests bloque la fusion.

## Signaler un problème

Utilisez les modèles d'issue (bogue ou proposition). Ne joignez jamais de données personnelles réelles. Pour une faille de sécurité, suivez [SECURITY.md](SECURITY.md).
