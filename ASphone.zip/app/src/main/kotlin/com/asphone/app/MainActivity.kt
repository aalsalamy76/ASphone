package com.asphone.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.data.notifications.ReminderActions
import com.asphone.core.designsystem.theme.ASphoneTheme
import dagger.hilt.android.AndroidEntryPoint

/** Activité principale : thème, navigation et routage des notifications. */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private var pendingRoute by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingRoute = routeFor(intent)

        setContent {
            val viewModel: AppViewModel = hiltViewModel()
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            ASphoneTheme(
                themeMode = settings.themeMode,
                amoled = settings.amoled,
                dynamicColor = settings.dynamicColor,
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(
                        pendingRoute = pendingRoute,
                        onRouteHandled = { pendingRoute = null },
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingRoute = routeFor(intent)
    }

    /** Traduit une action de notification en destination. Aucune action ne lance d'appel ni d'envoi. */
    private fun routeFor(intent: Intent?): String? = when (intent?.action) {
        ReminderActions.OPEN_THREAD -> Routes.thread(
            threadId = -1L,
            address = intent?.getStringExtra(ReminderActions.EXTRA_NUMBER).orEmpty(),
        )
        ReminderActions.OPEN_REMINDERS -> Routes.reminders(number = "", name = "")
        else -> null
    }
}
