package com.asphone.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.asphone.core.data.sms.SmsActions
import com.asphone.core.data.sms.SmsRepository
import com.asphone.core.data.sms.SmsStatusMapper
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Reçoit la confirmation réelle d'envoi ou de remise, puis met à jour l'état du message.
 * Un message n'est jamais marqué « envoyé » sans ce retour du système.
 */
@AndroidEntryPoint
class SmsStatusReceiver : BroadcastReceiver() {

    @Inject
    lateinit var sms: SmsRepository

    override fun onReceive(context: Context, intent: Intent) {
        val messageId = intent.getLongExtra(SmsActions.EXTRA_MESSAGE_ID, -1L)
        if (messageId < 0) return
        val state = when (intent.action) {
            SmsActions.SENT -> SmsStatusMapper.sentState(resultCode)
            SmsActions.DELIVERED -> SmsStatusMapper.deliveredState(resultCode)
            else -> return
        }
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                sms.updateState(messageId, state)
            } finally {
                pending.finish()
            }
        }
    }
}
