package com.asphone.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.data.settings.SettingsRepository
import com.asphone.core.model.AppSettings
import com.asphone.core.model.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/** Préférences d'affichage lues au démarrage de l'activité principale. */
@HiltViewModel
class AppViewModel @Inject constructor(
    repository: SettingsRepository,
) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settings.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        AppSettings(themeMode = ThemeMode.SYSTEM, amoled = false, dynamicColor = true),
    )
}
