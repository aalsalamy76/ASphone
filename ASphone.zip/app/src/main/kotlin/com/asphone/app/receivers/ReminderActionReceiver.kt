package com.asphone.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.asphone.core.data.notifications.ReminderActions
import com.asphone.core.data.reminders.ReminderNotifier
import com.asphone.core.data.reminders.ReminderRepository
import com.asphone.core.model.SnoozeOption
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Actions des notifications de rappel : report, terminé ou annulation. Aucune ne compose de numéro. */
@AndroidEntryPoint
class ReminderActionReceiver : BroadcastReceiver() {

    @Inject
    lateinit var reminders: ReminderRepository

    @Inject
    lateinit var notifier: ReminderNotifier

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra(ReminderActions.EXTRA_REMINDER_ID, -1L)
        val action = intent.action
        if (reminderId < 0 || action == null) return
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                when (action) {
                    ReminderActions.SNOOZE_10 -> reminders.snooze(reminderId, SnoozeOption.TEN_MINUTES)
                    ReminderActions.SNOOZE_HOUR -> reminders.snooze(reminderId, SnoozeOption.ONE_HOUR)
                    ReminderActions.SNOOZE_TOMORROW -> reminders.snooze(reminderId, SnoozeOption.TOMORROW)
                    ReminderActions.DONE -> reminders.complete(reminderId)
                    ReminderActions.CANCEL -> reminders.cancel(reminderId)
                    else -> return@launch
                }
                notifier.cancel(reminderId)
            } finally {
                pending.finish()
            }
        }
    }
}
