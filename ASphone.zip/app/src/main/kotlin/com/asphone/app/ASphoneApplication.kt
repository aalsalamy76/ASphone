package com.asphone.app

import android.app.Application
import com.asphone.core.data.notifications.NotificationChannels
import com.asphone.core.data.reminders.ReminderRepository
import com.asphone.core.data.scheduling.ScheduledSmsRepository
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Point d'entrée. Crée les canaux de notification et replanifie les tâches actives :
 * WorkManager les conserve après un redémarrage, mais une mise à jour de l'application peut les réinitialiser.
 */
@HiltAndroidApp
class ASphoneApplication : Application() {

    @Inject
    lateinit var scheduledSms: ScheduledSmsRepository

    @Inject
    lateinit var reminders: ReminderRepository

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.createAll(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching {
                scheduledSms.rescheduleActive()
                reminders.rescheduleActive()
            }
        }
    }
}
