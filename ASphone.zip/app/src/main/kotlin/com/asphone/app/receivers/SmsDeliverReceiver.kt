package com.asphone.app.receivers

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.asphone.app.MainActivity
import com.asphone.core.data.blocking.BlockedNumbersRepository
import com.asphone.core.data.contacts.ContactsRepository
import com.asphone.core.data.notifications.NotificationChannels
import com.asphone.core.data.notifications.ReminderActions
import com.asphone.core.data.settings.SettingsRepository
import com.asphone.core.data.sms.SmsRepository
import com.asphone.core.designsystem.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Réception d'un SMS (uniquement lorsque A.Sphone est l'application SMS par défaut).
 * Les numéros bloqués sont ignorés ; les autres messages sont enregistrés puis notifiés.
 */
@AndroidEntryPoint
class SmsDeliverReceiver : BroadcastReceiver() {

    @Inject
    lateinit var sms: SmsRepository

    @Inject
    lateinit var blocked: BlockedNumbersRepository

    @Inject
    lateinit var contacts: ContactsRepository

    @Inject
    lateinit var settings: SettingsRepository

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val subscriptionId = intent.getIntExtra(KEY_SUBSCRIPTION, -1).takeIf { it >= 0 }
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                parts
                    .filter { !it.originatingAddress.isNullOrBlank() }
                    .groupBy { it.originatingAddress.orEmpty() }
                    .forEach { (address, segments) ->
                        if (blocked.isBlocked(address)) return@forEach
                        val body = segments.joinToString(separator = "") { it.messageBody.orEmpty() }
                        val timestamp = segments.first().timestampMillis
                        sms.storeIncoming(address, body, timestamp, subscriptionId)
                        notifyIncoming(context, address, body)
                    }
            } finally {
                pending.finish()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun notifyIncoming(context: Context, address: String, body: String) {
        if (!NotificationChannels.areEnabled(context)) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val showDetails = settings.showMessageDetails.first()
        val name = runCatching { contacts.displayNameFor(address) }.getOrNull() ?: address
        val text = if (showDetails) body else context.getString(R.string.notif_sms_hidden)

        val openIntent = Intent(context, MainActivity::class.java)
            .setAction(ReminderActions.OPEN_THREAD)
            .putExtra(ReminderActions.EXTRA_NUMBER, address)
        val contentIntent = PendingIntent.getActivity(
            context,
            address.hashCode(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val publicVersion = NotificationCompat.Builder(context, NotificationChannels.INCOMING_SMS)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(context.getString(R.string.notif_sms_hidden))
            .build()
        val notification = NotificationCompat.Builder(context, NotificationChannels.INCOMING_SMS)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(name)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(address.hashCode(), notification)
    }

    private companion object {
        /** Extra système indiquant la carte SIM qui a reçu le message. */
        const val KEY_SUBSCRIPTION = "subscription"
    }
}
