package com.asphone.app.telecom

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService
import com.asphone.core.data.telecom.ActiveCallRegistry
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Service d'interface d'appel (InCallService), actif lorsque A.Sphone est l'application Téléphone.
 * Il transmet l'état des appels au registre partagé. Aucun enregistrement audio n'est effectué.
 */
@AndroidEntryPoint
class CallService : InCallService() {

    @Inject
    lateinit var registry: ActiveCallRegistry

    override fun onCreate() {
        super.onCreate()
        registry.attach(this)
    }

    override fun onDestroy() {
        registry.detach()
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        registry.onCallAdded(call)
        startActivity(
            Intent(this, InCallActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }

    override fun onCallRemoved(call: Call) {
        registry.onCallRemoved(call)
    }
}
