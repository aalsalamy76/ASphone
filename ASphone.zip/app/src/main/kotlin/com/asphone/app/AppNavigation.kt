package com.asphone.app

import android.net.Uri
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import androidx.navigation.compose.rememberNavController
import com.asphone.core.designsystem.R
import com.asphone.feature.contacts.ContactDetailScreen
import com.asphone.feature.contacts.ContactsScreen
import com.asphone.feature.messages.ConversationsScreen
import com.asphone.feature.messages.ScheduleScreen
import com.asphone.feature.messages.ThreadScreen
import com.asphone.feature.phone.DialerScreen
import com.asphone.feature.reminders.RemindersScreen
import com.asphone.feature.settings.AboutScreen
import com.asphone.feature.settings.SettingsScreen

/** Itinéraires de l'application. Les modèles (« {arg} ») servent à déclarer les arguments. */
object Routes {
    const val PHONE = "phone"
    const val MESSAGES = "messages"
    const val CONTACTS = "contacts"
    const val CONTACT_DETAIL = "contacts/{contactId}"
    const val THREAD = "thread?threadId={threadId}&address={address}"
    const val SCHEDULE = "schedule?recipient={recipient}"
    const val REMINDERS = "reminders?number={number}&name={name}"
    const val SETTINGS = "settings"
    const val ABOUT = "about"

    fun contact(id: Long): String = "contacts/$id"

    fun thread(threadId: Long, address: String): String =
        "thread?threadId=$threadId&address=${Uri.encode(address)}"

    fun schedule(recipient: String): String = "schedule?recipient=${Uri.encode(recipient)}"

    fun reminders(number: String, name: String): String =
        "reminders?number=${Uri.encode(number)}&name=${Uri.encode(name)}"
}

private data class TopLevelItem(
    val pattern: String,
    val destination: String,
    val label: Int,
    val icon: ImageVector,
)

private val TOP_LEVEL_ITEMS = listOf(
    TopLevelItem(Routes.PHONE, Routes.PHONE, R.string.nav_phone, Icons.Filled.Call),
    TopLevelItem(Routes.MESSAGES, Routes.MESSAGES, R.string.nav_messages, Icons.Filled.Sms),
    TopLevelItem(Routes.CONTACTS, Routes.CONTACTS, R.string.nav_contacts, Icons.Filled.Person),
    TopLevelItem(Routes.REMINDERS, Routes.reminders(number = "", name = ""), R.string.nav_reminders, Icons.Filled.Alarm),
    TopLevelItem(Routes.SETTINGS, Routes.SETTINGS, R.string.nav_settings, Icons.Filled.Settings),
)

/** Largeur à partir de laquelle la navigation latérale remplace la barre du bas (tablettes, pliables). */
private const val WIDE_BREAKPOINT_DP = 600

@Composable
fun AppRoot(
    pendingRoute: String?,
    onRouteHandled: () -> Unit,
) {
    val navController = rememberNavController()
    val entry by navController.currentBackStackEntryAsState()
    val currentRoute = entry?.destination?.route
    val showChrome = TOP_LEVEL_ITEMS.any { it.pattern == currentRoute }
    val wide = LocalConfiguration.current.screenWidthDp >= WIDE_BREAKPOINT_DP

    LaunchedEffect(pendingRoute) {
        if (pendingRoute != null) {
            navController.navigate(pendingRoute) { launchSingleTop = true }
            onRouteHandled()
        }
    }

    fun navigateTopLevel(item: TopLevelItem) {
        navController.navigate(item.destination) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Row(modifier = Modifier.fillMaxSize()) {
        if (showChrome && wide) {
            NavigationRail {
                TOP_LEVEL_ITEMS.forEach { item ->
                    NavigationRailItem(
                        selected = currentRoute == item.pattern,
                        onClick = { navigateTopLevel(item) },
                        icon = { Icon(item.icon, contentDescription = null) },
                        label = { Text(stringResource(item.label)) },
                    )
                }
            }
        }
        Scaffold(
            modifier = Modifier.weight(1f),
            bottomBar = {
                if (showChrome && !wide) {
                    NavigationBar {
                        TOP_LEVEL_ITEMS.forEach { item ->
                            NavigationBarItem(
                                selected = currentRoute == item.pattern,
                                onClick = { navigateTopLevel(item) },
                                icon = { Icon(item.icon, contentDescription = null) },
                                label = { Text(stringResource(item.label)) },
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Routes.PHONE,
                modifier = Modifier.padding(innerPadding),
            ) {
                composable(Routes.PHONE) {
                    DialerScreen(
                        onOpenThread = { address -> navController.navigate(Routes.thread(-1L, address)) },
                    )
                }
                composable(Routes.MESSAGES) {
                    ConversationsScreen(
                        onOpenThread = { threadId, address ->
                            navController.navigate(Routes.thread(threadId, address))
                        },
                        onOpenSchedule = { navController.navigate(Routes.schedule("")) },
                    )
                }
                composable(Routes.CONTACTS) {
                    ContactsScreen(
                        onOpenContact = { id -> navController.navigate(Routes.contact(id)) },
                    )
                }
                composable(
                    Routes.CONTACT_DETAIL,
                    arguments = listOf(navArgument("contactId") { type = NavType.LongType }),
                ) {
                    ContactDetailScreen(
                        onBack = { navController.popBackStack() },
                        onOpenThread = { address -> navController.navigate(Routes.thread(-1L, address)) },
                        onSchedule = { number -> navController.navigate(Routes.schedule(number)) },
                        onReminder = { number, name -> navController.navigate(Routes.reminders(number, name)) },
                    )
                }
                composable(
                    Routes.THREAD,
                    arguments = listOf(
                        navArgument("threadId") {
                            type = NavType.LongType
                            defaultValue = -1L
                        },
                        navArgument("address") {
                            type = NavType.StringType
                            defaultValue = ""
                        },
                    ),
                ) {
                    ThreadScreen(onBack = { navController.popBackStack() })
                }
                composable(
                    Routes.SCHEDULE,
                    arguments = listOf(
                        navArgument("recipient") {
                            type = NavType.StringType
                            defaultValue = ""
                        },
                    ),
                ) {
                    ScheduleScreen(onBack = { navController.popBackStack() })
                }
                composable(
                    Routes.REMINDERS,
                    arguments = listOf(
                        navArgument("number") {
                            type = NavType.StringType
                            defaultValue = ""
                        },
                        navArgument("name") {
                            type = NavType.StringType
                            defaultValue = ""
                        },
                    ),
                ) {
                    RemindersScreen(
                        onOpenThread = { address -> navController.navigate(Routes.thread(-1L, address)) },
                    )
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen(onOpenAbout = { navController.navigate(Routes.ABOUT) })
                }
                composable(Routes.ABOUT) {
                    AboutScreen(onBack = { navController.popBackStack() })
                }
            }
        }
    }
}
