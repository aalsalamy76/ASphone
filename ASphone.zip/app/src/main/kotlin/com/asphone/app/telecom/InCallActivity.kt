package com.asphone.app.telecom

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.data.settings.SettingsRepository
import com.asphone.core.designsystem.theme.ASphoneTheme
import com.asphone.core.model.AppSettings
import com.asphone.core.model.ThemeMode
import com.asphone.feature.phone.InCallScreen
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/** Écran d'appel en cours, affiché par-dessus l'écran verrouillé lorsque l'appel le demande. */
@AndroidEntryPoint
class InCallActivity : ComponentActivity() {

    @Inject
    lateinit var settings: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val current by settings.settings.collectAsStateWithLifecycle(
                initialValue = AppSettings(themeMode = ThemeMode.SYSTEM, amoled = false, dynamicColor = true),
            )
            ASphoneTheme(
                themeMode = current.themeMode,
                amoled = current.amoled,
                dynamicColor = current.dynamicColor,
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    InCallScreen(onFinished = { finish() })
                }
            }
        }
    }
}
