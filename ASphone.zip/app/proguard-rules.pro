# Règles R8 de A.Sphone (build release uniquement).

# Sérialisation de la sauvegarde chiffrée : les classes doivent garder leurs noms de champs.
-keepattributes *Annotation*, InnerClasses, EnclosingMethod, Signature
-keep,includedescriptorclasses class com.asphone.core.data.backup.** { *; }
-keepclassmembers class com.asphone.core.data.backup.** {
    *** Companion;
}

# Composants instanciés par le système Android (services, récepteurs, activités).
-keep class com.asphone.app.** extends android.app.Activity
-keep class com.asphone.app.** extends android.content.BroadcastReceiver
-keep class com.asphone.app.telecom.CallService

# Ne pas journaliser en release (aucun contenu de SMS ou de numéro ne doit apparaître dans les logs).
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
}
