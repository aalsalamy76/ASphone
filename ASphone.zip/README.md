# A.Sphone

**A.Sphone** est une application Android de téléphonie et de messagerie : appels, SMS, contacts, programmation de messages et rappels. Elle fonctionne **sans connexion Internet** et n'envoie aucune donnée hors de l'appareil.

- **Développeur** : Abdullah AL-SALAMY
- **LinkedIn** : https://www.linkedin.com/in/abdullah-a-2982451a6
- **Package** : `com.asphone.app` · minSdk 26 (Android 8.0) · targetSdk 35
- **Licence** : tous droits réservés (voir [LICENSE](LICENSE)), à confirmer par le développeur.

A.Sphone n'est affilié à aucun opérateur mobile ni à aucun fabricant d'appareils.

## Statut

**Le code est complet, mais il n'a pas été compilé dans l'environnement où il a été rédigé**, car l'accès aux dépôts Google et Maven y était bloqué. Aucun APK n'a donc été produit ni testé sur appareil. Les commandes de build décrites plus bas doivent être exécutées sur une machine connectée avant toute utilisation.

### Vérifications effectuées

- 52 tests unitaires des modules purs Kotlin, exécutés avec kotlinc 2.0.21 : `core:common` (22), `core:model` (23), `core:security` (7). Tous réussissent.
- Analyse syntaxique (tree-sitter) de 93 fichiers Kotlin, sans erreur.
- Fichiers XML (ressources, manifeste) et YAML (workflows) bien formés.
- 209 clés de texte présentes dans les six langues, avec les mêmes marqueurs de format.

### Non vérifié

- Compilation Android (AGP, Compose, Room/KSP, Hilt), ktlint, detekt, lint, tests Android.
- Génération de l'APK debug, de l'APK ou de l'AAB release, et signature.
- Comportement sur appareil réel (rôles par défaut, appels, réception SMS).

## Fonctionnalités

### Téléphone

- Clavier avec correspondance des lettres, journal des appels récents.
- Un appel n'est émis qu'après une action explicite de l'utilisateur. Aucun appel n'est passé automatiquement.
- Écran d'appel entrant et en cours (service `InCallService`) : répondre, refuser, raccrocher, couper le micro, haut-parleur, mettre en attente.
- Blocage de numéros, après confirmation.

### Contacts

- Liste, recherche par nom, numéro ou T9, création et suppression (après confirmation).
- Doublons **proposés** seulement (même nom ou même numéro). A.Sphone ne fusionne jamais deux contacts : cette opération se fait dans l'application Contacts.
- Depuis la fiche : appeler, écrire, programmer un SMS, créer un rappel, bloquer ou débloquer.

### Messages

- Liste des conversations, nouveau message, fil de discussion avec l'état de chaque message (en file, envoi, envoyé, distribué, non envoyé).
- Un message n'est marqué « envoyé » qu'après confirmation du système, via les `PendingIntent` `SENT` et `DELIVERED`.
- Compteur de caractères et de segments, avec distinction entre encodage GSM-7 et UCS-2.
- Réception des SMS. A.Sphone doit être l'application SMS par défaut.

### Programmation de SMS

- Un ou plusieurs destinataires, date et heure, puis récurrence : une fois, quotidienne, jours ouvrés, hebdomadaire, jours choisis, tous les N jours, mensuelle, annuelle, anniversaire.
- Suspendre, reprendre, dupliquer, annuler.
- Une date passée ou un destinataire invalide empêche l'enregistrement.

### Rappels

- Rappeler ou écrire à une personne plus tard : dans 15 minutes, dans 30 minutes, dans 1 heure, cet après-midi, ou demain à 9 h.
- Depuis la notification : reporter de 10 minutes, d'une heure ou à demain ; marquer comme terminé ; annuler.
- Aucun numéro n'est composé et aucun message n'est envoyé automatiquement. Le rappel ouvre le clavier ou la conversation, et c'est l'utilisateur qui confirme.

### Réglages

- Thème clair, sombre ou suivant le système ; mode AMOLED ; couleurs dynamiques (Android 12 et plus).
- Langue : langue du système, français, English, español, العربية, हिन्दी ou 简体中文.
- Rôles : application Téléphone et application SMS par défaut.
- Notifications : choisir d'afficher ou non le texte des messages.
- Sauvegarde chiffrée : export et import (voir ci-dessous).

### Sauvegarde chiffrée

- Le fichier exporté (`A-Sphone-sauvegarde.asphb`) contient les programmations, les rappels, les numéros bloqués et les réglages. Il ne contient **ni contacts, ni SMS, ni journal d'appels**.
- Chiffrement : la clé est dérivée de la phrase secrète par PBKDF2-HMAC-SHA256 (600 000 itérations, sel de 16 octets), puis le contenu est chiffré en AES-256-GCM (nonce de 12 octets, tag de 128 bits). L'en-tête est authentifié.
- La phrase secrète compte au moins 12 caractères. **Sans elle, la sauvegarde est irrécupérable.**

## Langues

Six langues : anglais (langue par défaut), français, arabe (mise en page de droite à gauche), espagnol, hindi et chinois simplifié. Les textes sont dans `core/designsystem/src/main/res/values*/strings.xml`.

## Architecture

Le projet compte **12 modules Gradle** :

| Module | Rôle |
|---|---|
| `app` | Point d'entrée, navigation, récepteurs, service d'appel, activité d'appel |
| `core:common` | Utilitaires purs : numéros de téléphone, T9, GSM-7, détection de doublons |
| `core:model` | Modèles métier, règles de récurrence, machine d'états des messages, validation |
| `core:security` | Chiffrement des sauvegardes |
| `core:database` | Base Room : entités et DAO |
| `core:designsystem` | Thème Material 3, composants et chaînes de texte |
| `core:data` | Dépôts, travailleurs WorkManager, notifications, intégration téléphonie |
| `feature:phone` | Clavier, journal, écran d'appel |
| `feature:contacts` | Contacts et fiche contact |
| `feature:messages` | Conversations, fil, programmation de SMS |
| `feature:reminders` | Rappels |
| `feature:settings` | Réglages, sauvegarde, à propos |

**Écart avec le cahier des charges** : l'architecture prévoyait environ 60 modules. Elle a été ramenée à 12 modules, en regroupant les sous-modules fins. Les couches restent séparées (modèle, données, fonctionnalités). Cet écart est volontaire.

Technologies : Kotlin, Jetpack Compose, Material 3, Hilt, Room, DataStore, WorkManager, Navigation Compose, coroutines et Flow, AppCompat (changement de langue), `ContactsContract`, `Telephony`, `Telecom`, `RoleManager`.

## Permissions

`CALL_PHONE`, `ANSWER_PHONE_CALLS`, `READ_PHONE_STATE`, `READ_CALL_LOG`, `WRITE_CALL_LOG`, `READ_CONTACTS`, `WRITE_CONTACTS`, `READ_SMS`, `SEND_SMS`, `RECEIVE_SMS`, `POST_NOTIFICATIONS`.

**Aucune permission `INTERNET`** n'est déclarée dans le manifeste. Aucun test automatique ne le vérifie encore : c'est à relire à chaque modification du manifeste.

## Compiler et tester

Prérequis : JDK 17 et Android SDK (plateforme 35). Ces commandes doivent être lancées sur une machine connectée :

```bash
./gradlew --no-daemon assembleDebug
./gradlew --no-daemon testDebugUnitTest
./gradlew --no-daemon lintDebug
./gradlew --no-daemon ktlintCheck
./gradlew --no-daemon detekt
```

**Avant le premier build** : le JAR du Gradle Wrapper a été assemblé à la main dans l'environnement de rédaction. Il faut le régénérer avec `gradle wrapper --gradle-version 8.13`, puis commiter le résultat.

Sans fichier de signature, `assembleRelease` produit un APK **non signé**, qui ne s'installe pas.

## Signature et secrets GitHub

La signature release n'est activée que si la variable `ANDROID_KEYSTORE_PATH` est définie. Les mots de passe sont lus dans `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` et `ANDROID_KEY_PASSWORD`.

Dans GitHub (Settings → Secrets and variables → Actions), créer ces quatre secrets :

| Secret | Contenu |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | Le keystore encodé en base64 (`base64 -w0 release.jks`) |
| `ANDROID_KEYSTORE_PASSWORD` | Mot de passe du keystore |
| `ANDROID_KEY_ALIAS` | Alias de la clé |
| `ANDROID_KEY_PASSWORD` | Mot de passe de la clé |

Ne jamais versionner le keystore ni son mot de passe. Le `.gitignore` exclut `*.jks`, `*.keystore`, `*.p12`, `*.pfx` et `keystore.properties`.

## Workflows GitHub Actions

- **Android CI** (`.github/workflows/android-ci.yaml`) : à chaque push, pull request ou lancement manuel. Vérifie le wrapper, lance ktlint, detekt, lint debug et les tests unitaires, puis produit l'APK debug. Publie les artefacts `A-Sphone-debug`, `A-Sphone-source`, `A-Sphone-builds` et `rapports-tests-lint`.
- **Android Release** (`.github/workflows/android-release.yaml`) : à chaque tag `v*` ou lancement manuel. Vérifie d'abord les quatre secrets et s'arrête proprement s'ils manquent. Décode le keystore dans un fichier temporaire, supprimé en fin de job, puis produit l'APK et l'AAB signés. Publie `A-Sphone-release` et `A-Sphone-source`.
- **CodeQL** (`.github/workflows/codeql.yaml`) : analyse Java et Kotlin à chaque push et pull request sur `main`, et chaque semaine.
- **Dependabot** (`.github/dependabot.yaml`) : mises à jour hebdomadaires des dépendances Gradle et des actions GitHub.

Pour lancer un workflow à la main : onglet **Actions**, choisir le workflow, puis **Run workflow**.

## Limites connues

- Pas de MMS ni de WAP push.
- Le rôle d'application SMS par défaut est nécessaire pour envoyer et recevoir des SMS. Le rôle d'application Téléphone par défaut est nécessaire pour que les appels entrants s'affichent sur l'écran de A.Sphone.
- Les SMS programmés partent à l'heure prévue quand le téléphone est allumé. Android peut retarder l'envoi (mise en veille, économie d'énergie) et ne garantit pas la seconde exacte.
- Les restrictions d'Android 12 et plus sur les appels et les notifications s'appliquent.
- Pas d'enregistrement d'appels, pas de messages vocaux, pas de fusion automatique de contacts.
- Les tests d'instrumentation (Room sur appareil, interface) ne sont pas écrits. Seuls les tests unitaires JVM existent.
- La phrase secrète de sauvegarde est saisie dans un champ texte Compose : elle existe donc brièvement sous forme de `String`, que le code ne peut pas effacer. Elle est convertie en `CharArray`, effacé après usage.
- Pas de synchronisation cloud, pas de version iOS.

## Développeur

Abdullah AL-SALAMY, LinkedIn : https://www.linkedin.com/in/abdullah-a-2982451a6

Voir aussi : [CONTRIBUTING.md](CONTRIBUTING.md), [SECURITY.md](SECURITY.md), [CHANGELOG.md](CHANGELOG.md).
