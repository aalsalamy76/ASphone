# Politique de sécurité

## Signaler une vulnérabilité

Ne publiez pas de faille dans une issue ou une pull request publique.

Utilisez le signalement privé de GitHub : onglet **Security**, puis **Report a vulnerability**. Décrivez :

- la version concernée ou le commit ;
- les étapes pour reproduire le problème ;
- l'impact estimé (par exemple fuite de données personnelles, contournement d'une confirmation).

Ne joignez à votre signalement ni vrais SMS, ni vrais numéros, ni contacts, ni sauvegardes chiffrées contenant des données personnelles.

## Périmètre

Sont particulièrement concernés :

- toute transmission de données hors de l'appareil (A.Sphone ne doit déclarer aucune permission `INTERNET`) ;
- toute fuite de contenu de SMS, de numéros ou de contacts dans les journaux, les notifications publiques ou les fichiers exportés ;
- tout défaut du chiffrement des sauvegardes (`core:security`) ;
- tout appel ou tout SMS déclenché sans action explicite de l'utilisateur.

## Délais

Le mainteneur accuse réception dans la mesure de sa disponibilité, puis tient le signalant informé de l'avancement. Aucun programme de récompense n'est proposé.
