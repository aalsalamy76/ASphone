## Description

<!-- Quel changement, et pourquoi. -->

## Type de changement

- [ ] Correction de bogue
- [ ] Nouvelle fonctionnalité
- [ ] Refactoring sans changement de comportement
- [ ] Documentation ou configuration

## Vérifications

- [ ] `./gradlew --no-daemon ktlintCheck detekt` passe
- [ ] `./gradlew --no-daemon testDebugUnitTest` passe
- [ ] `./gradlew --no-daemon lintDebug` passe
- [ ] `./gradlew --no-daemon assembleDebug` réussit
- [ ] Chaque nouveau texte visible existe dans les six langues, avec les mêmes marqueurs de format

## Confidentialité et sécurité

- [ ] Aucun SMS, numéro complet, nom de contact, mot de passe ou clé n'est écrit dans les journaux
- [ ] Aucune permission `INTERNET` n'a été ajoutée
- [ ] Les tests n'effectuent aucun appel ni SMS réel
- [ ] Aucun secret, keystore ni `local.properties` n'est committé
