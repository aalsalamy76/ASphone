---
name: Bogue
about: Signaler un comportement incorrect
title: "[Bogue] "
labels: bug
---

## Description

<!-- Ce qui ne fonctionne pas. -->

## Étapes pour reproduire

1.
2.
3.

## Comportement attendu

## Comportement observé

## Environnement

- Modèle d'appareil et version d'Android :
- Version de A.Sphone (ou commit) :
- A.Sphone est-elle l'application SMS par défaut ? oui / non
- A.Sphone est-elle l'application Téléphone par défaut ? oui / non

## Données personnelles

Ne joignez ni SMS, ni numéros, ni contacts, ni sauvegarde chiffrée. Décrivez le problème sans ces informations.
