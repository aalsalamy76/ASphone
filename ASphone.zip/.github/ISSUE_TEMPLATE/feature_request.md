---
name: Proposition
about: Proposer une amélioration ou une nouvelle fonctionnalité
title: "[Proposition] "
labels: enhancement
---

## Besoin

<!-- Quelle difficulté l'utilisateur rencontre-t-il ? -->

## Solution proposée

## Alternatives envisagées

## Impact sur la confidentialité

<!-- Cette proposition ajoute-t-elle une donnée, une permission ou un échange avec l'extérieur ? A.Sphone ne doit déclarer aucune permission INTERNET. -->
