pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "A-Sphone"

include(":app")

// Noyau
include(":core:common")
include(":core:model")
include(":core:security")
include(":core:database")
include(":core:designsystem")
include(":core:data")

// Fonctionnalités
include(":feature:phone")
include(":feature:contacts")
include(":feature:messages")
include(":feature:reminders")
include(":feature:settings")
