package com.asphone.core.security

import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class BackupCryptoTest {

    // Nombre d'itérations réduit uniquement pour accélérer les tests.
    private val fastIterations = 1_000
    private val data = "{\"contacts\":[]}".encodeToByteArray()

    @Test
    fun `un chiffrement suivi d'un déchiffrement restitue les données`() {
        val encrypted = BackupCrypto.encrypt(data, "phrase".toCharArray(), fastIterations)
        val decrypted = BackupCrypto.decrypt(encrypted, "phrase".toCharArray())
        assertContentEquals(data, decrypted)
    }

    @Test
    fun `le texte chiffré ne contient pas le texte clair`() {
        val encrypted = BackupCrypto.encrypt(data, "phrase".toCharArray(), fastIterations)
        assertFalse(String(encrypted, Charsets.ISO_8859_1).contains("contacts"))
    }

    @Test
    fun `deux chiffrements du même contenu diffèrent (sel et nonce uniques)`() {
        val first = BackupCrypto.encrypt(data, "phrase".toCharArray(), fastIterations)
        val second = BackupCrypto.encrypt(data, "phrase".toCharArray(), fastIterations)
        assertFalse(first.contentEquals(second))
    }

    @Test
    fun `une mauvaise phrase secrète est refusée`() {
        val encrypted = BackupCrypto.encrypt(data, "bonne".toCharArray(), fastIterations)
        assertFailsWith<BackupException> {
            BackupCrypto.decrypt(encrypted, "mauvaise".toCharArray())
        }
    }

    @Test
    fun `une altération du fichier est détectée`() {
        val encrypted = BackupCrypto.encrypt(data, "phrase".toCharArray(), fastIterations)
        encrypted[encrypted.size - 1] = (encrypted[encrypted.size - 1].toInt() xor 0x01).toByte()
        assertFailsWith<BackupException> {
            BackupCrypto.decrypt(encrypted, "phrase".toCharArray())
        }
    }

    @Test
    fun `un fichier sans signature est refusé`() {
        val garbage = ByteArray(200) { 7 }
        assertFailsWith<BackupException> {
            BackupCrypto.decrypt(garbage, "phrase".toCharArray())
        }
    }

    @Test
    fun `une phrase vide est refusée au chiffrement`() {
        assertTrue(runCatching { BackupCrypto.encrypt(data, CharArray(0), fastIterations) }.isFailure)
    }
}
