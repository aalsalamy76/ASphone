package com.asphone.core.security

import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Erreur de sauvegarde. Le message ne contient jamais de donnée personnelle. */
class BackupException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * Chiffrement des sauvegardes locales.
 *
 * Format versionné (version 1), tous les champs en big-endian :
 * MAGIC (4 o) | VERSION (1 o) | ITERATIONS (4 o) | SEL (16 o) | NONCE (12 o) | CHIFFRÉ + TAG GCM (128 bits)
 *
 * - Clé : PBKDF2-HMAC-SHA256 à partir de la phrase secrète, sel unique par sauvegarde.
 * - Chiffrement : AES-256-GCM, nonce unique par sauvegarde.
 * - Les en-têtes (magic, version, itérations) sont authentifiés comme données associées.
 */
object BackupCrypto {

    private val MAGIC = byteArrayOf('A'.code.toByte(), 'S'.code.toByte(), 'P'.code.toByte(), 'H'.code.toByte())
    private const val VERSION: Byte = 1
    private const val SALT_LENGTH = 16
    private const val NONCE_LENGTH = 12
    private const val KEY_BITS = 256
    private const val TAG_BITS = 128
    private const val DEFAULT_ITERATIONS = 600_000
    private const val HEADER_LENGTH = 4 + 1 + 4 + SALT_LENGTH + NONCE_LENGTH

    private val random = SecureRandom()

    fun encrypt(
        plaintext: ByteArray,
        passphrase: CharArray,
        iterations: Int = DEFAULT_ITERATIONS,
    ): ByteArray {
        require(passphrase.isNotEmpty()) { "La phrase secrète ne peut pas être vide." }
        val salt = ByteArray(SALT_LENGTH).also(random::nextBytes)
        val nonce = ByteArray(NONCE_LENGTH).also(random::nextBytes)
        val header = buildHeader(iterations, salt, nonce)
        return try {
            val key = deriveKey(passphrase, salt, iterations)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_BITS, nonce))
            cipher.updateAAD(header)
            val body = cipher.doFinal(plaintext)
            header + body
        } catch (error: GeneralSecurityException) {
            throw BackupException("Chiffrement impossible.", error)
        }
    }

    fun decrypt(encrypted: ByteArray, passphrase: CharArray): ByteArray {
        if (encrypted.size <= HEADER_LENGTH) throw BackupException("Fichier de sauvegarde invalide.")
        val buffer = ByteBuffer.wrap(encrypted)
        val magic = ByteArray(MAGIC.size)
        buffer.get(magic)
        if (!magic.contentEquals(MAGIC)) throw BackupException("Fichier de sauvegarde invalide.")
        val version = buffer.get()
        if (version != VERSION) throw BackupException("Version de sauvegarde non prise en charge : $version.")
        val iterations = buffer.getInt()
        val salt = ByteArray(SALT_LENGTH)
        buffer.get(salt)
        val nonce = ByteArray(NONCE_LENGTH)
        buffer.get(nonce)
        val header = encrypted.copyOfRange(0, HEADER_LENGTH)
        val body = encrypted.copyOfRange(HEADER_LENGTH, encrypted.size)
        return try {
            val key = deriveKey(passphrase, salt, iterations)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, nonce))
            cipher.updateAAD(header)
            cipher.doFinal(body)
        } catch (error: GeneralSecurityException) {
            throw BackupException("Phrase secrète incorrecte ou sauvegarde altérée.", error)
        }
    }

    private fun buildHeader(iterations: Int, salt: ByteArray, nonce: ByteArray): ByteArray =
        ByteBuffer.allocate(HEADER_LENGTH)
            .put(MAGIC)
            .put(VERSION)
            .putInt(iterations)
            .put(salt)
            .put(nonce)
            .array()

    private fun deriveKey(passphrase: CharArray, salt: ByteArray, iterations: Int): SecretKeySpec {
        val spec = PBEKeySpec(passphrase, salt, iterations, KEY_BITS)
        try {
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val material = factory.generateSecret(spec).encoded
            return SecretKeySpec(material, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    private const val TRANSFORMATION = "AES/GCM/NoPadding"
}
