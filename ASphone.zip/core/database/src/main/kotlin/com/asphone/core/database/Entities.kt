package com.asphone.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * SMS programmé. Les destinataires sont stockés séparés par ';' et les jours de
 * récurrence personnalisés par ',' (noms de [java.time.DayOfWeek]).
 */
@Entity(tableName = "scheduled_sms")
data class ScheduledSmsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipients: String,
    val body: String,
    val firstRunMillis: Long,
    val nextRunMillis: Long,
    val zoneId: String,
    val subscriptionId: Int?,
    val recurrenceType: String,
    val intervalDays: Int,
    val daysOfWeek: String,
    val status: String,
    val lastError: String?,
)

/** Rappel d'appel ou de message. */
@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val number: String,
    val contactName: String?,
    val note: String,
    val dueAtMillis: Long,
    val zoneId: String,
    val status: String,
    val draftText: String?,
)

/** Numéro bloqué : les appels et SMS de ce numéro sont rejetés. */
@Entity(tableName = "blocked_numbers")
data class BlockedNumberEntity(
    @PrimaryKey val number: String,
    val addedAtMillis: Long,
)
