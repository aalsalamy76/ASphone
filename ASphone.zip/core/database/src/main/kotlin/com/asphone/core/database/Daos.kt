package com.asphone.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduledSmsDao {

    @Query("SELECT * FROM scheduled_sms ORDER BY nextRunMillis ASC")
    fun observeAll(): Flow<List<ScheduledSmsEntity>>

    @Query("SELECT * FROM scheduled_sms WHERE id = :id")
    suspend fun getById(id: Long): ScheduledSmsEntity?

    @Query("SELECT * FROM scheduled_sms WHERE status = 'ACTIVE'")
    suspend fun getActive(): List<ScheduledSmsEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ScheduledSmsEntity): Long

    @Update
    suspend fun update(entity: ScheduledSmsEntity)

    @Query("DELETE FROM scheduled_sms WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface ReminderDao {

    @Query("SELECT * FROM reminders ORDER BY dueAtMillis ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getById(id: Long): ReminderEntity?

    @Query("SELECT * FROM reminders WHERE status = 'PENDING'")
    suspend fun getPending(): List<ReminderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ReminderEntity): Long

    @Update
    suspend fun update(entity: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface BlockedNumberDao {

    @Query("SELECT * FROM blocked_numbers ORDER BY addedAtMillis DESC")
    fun observeAll(): Flow<List<BlockedNumberEntity>>

    @Query("SELECT * FROM blocked_numbers")
    suspend fun getAll(): List<BlockedNumberEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: BlockedNumberEntity)

    @Query("DELETE FROM blocked_numbers WHERE number = :number")
    suspend fun delete(number: String)
}
