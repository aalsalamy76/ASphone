package com.asphone.core.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        ScheduledSmsEntity::class,
        ReminderEntity::class,
        BlockedNumberEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class ASphoneDatabase : RoomDatabase() {

    abstract fun scheduledSmsDao(): ScheduledSmsDao

    abstract fun reminderDao(): ReminderDao

    abstract fun blockedNumberDao(): BlockedNumberDao

    companion object {
        const val NAME = "asphone.db"
    }
}
