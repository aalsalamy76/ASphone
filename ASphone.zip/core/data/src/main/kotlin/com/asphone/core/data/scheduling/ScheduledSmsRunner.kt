package com.asphone.core.data.scheduling

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.asphone.core.data.sms.SmsSender
import com.asphone.core.model.Recurrences
import com.asphone.core.model.ScheduledStatus
import dagger.hilt.android.qualifiers.ApplicationContext
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import javax.inject.Inject
import javax.inject.Singleton

/** Exécute une programmation : envoi à chaque destinataire, puis calcul de la prochaine occurrence. */
@Singleton
class ScheduledSmsRunner @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ScheduledSmsRepository,
    private val sender: SmsSender,
) {

    suspend fun execute(id: Long) {
        val schedule = repository.get(id) ?: return
        if (schedule.status != ScheduledStatus.ACTIVE) return

        if (schedule.body.isBlank() || schedule.recipients.isEmpty()) {
            repository.recordError(id, "Message vide ou sans destinataire.")
            return
        }
        if (!hasSendPermission()) {
            repository.recordError(id, "Permission d'envoi de SMS retirée.")
            return
        }

        schedule.recipients.forEach { recipient ->
            sender.send(recipient, schedule.body, schedule.subscriptionId)
        }

        val zone = ZoneId.of(schedule.zoneId)
        val anchor = ZonedDateTime.ofInstant(Instant.ofEpochMilli(schedule.firstRunMillis), zone)
        val current = ZonedDateTime.ofInstant(Instant.ofEpochMilli(schedule.nextRunMillis), zone)
        val next = Recurrences.next(anchor, current, schedule.recurrence)
        repository.advanceAfterRun(id, next?.toInstant()?.toEpochMilli())
    }

    private fun hasSendPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) ==
            PackageManager.PERMISSION_GRANTED
}
