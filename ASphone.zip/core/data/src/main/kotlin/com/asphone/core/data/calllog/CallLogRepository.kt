package com.asphone.core.data.calllog

import android.content.Context
import android.provider.CallLog
import com.asphone.core.model.CallLogEntry
import com.asphone.core.model.CallType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/** Historique des appels (lecture seule). L'enregistrement des appels n'est jamais effectué. */
@Singleton
class CallLogRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {

    suspend fun recent(limit: Int = DEFAULT_LIMIT): List<CallLogEntry> = withContext(Dispatchers.IO) {
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.TYPE,
        )
        context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            projection,
            null,
            null,
            "${CallLog.Calls.DATE} DESC",
        )?.use { cursor ->
            buildList {
                while (size < limit && cursor.moveToNext()) {
                    add(
                        CallLogEntry(
                            id = cursor.getLong(0),
                            number = cursor.getString(1).orEmpty(),
                            contactName = cursor.getString(2),
                            timestampMillis = cursor.getLong(3),
                            durationSeconds = cursor.getLong(4),
                            type = mapType(cursor.getInt(5)),
                            simSlot = null,
                        ),
                    )
                }
            }
        }.orEmpty()
    }

    private fun mapType(raw: Int): CallType = when (raw) {
        CallLog.Calls.OUTGOING_TYPE -> CallType.OUTGOING
        CallLog.Calls.MISSED_TYPE -> CallType.MISSED
        CallLog.Calls.VOICEMAIL_TYPE -> CallType.VOICEMAIL
        CallLog.Calls.REJECTED_TYPE -> CallType.REJECTED
        CallLog.Calls.BLOCKED_TYPE -> CallType.BLOCKED
        else -> CallType.INCOMING
    }

    private companion object {
        const val DEFAULT_LIMIT = 200
    }
}
