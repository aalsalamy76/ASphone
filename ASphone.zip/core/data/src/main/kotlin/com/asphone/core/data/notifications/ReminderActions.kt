package com.asphone.core.data.notifications

/** Actions et extras partagés entre les notifications et les composants de l'application. */
object ReminderActions {
    const val SNOOZE_10 = "com.asphone.app.action.REMINDER_SNOOZE_10"
    const val SNOOZE_HOUR = "com.asphone.app.action.REMINDER_SNOOZE_HOUR"
    const val SNOOZE_TOMORROW = "com.asphone.app.action.REMINDER_SNOOZE_TOMORROW"
    const val DONE = "com.asphone.app.action.REMINDER_DONE"
    const val CANCEL = "com.asphone.app.action.REMINDER_CANCEL"
    const val OPEN_THREAD = "com.asphone.app.action.OPEN_THREAD"
    const val OPEN_REMINDERS = "com.asphone.app.action.OPEN_REMINDERS"

    const val EXTRA_REMINDER_ID = "com.asphone.app.extra.REMINDER_ID"
    const val EXTRA_NUMBER = "com.asphone.app.extra.NUMBER"
}
