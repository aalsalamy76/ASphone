package com.asphone.core.data.blocking

import com.asphone.core.common.PhoneNumbers
import com.asphone.core.database.BlockedNumberDao
import com.asphone.core.database.BlockedNumberEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** Numéros bloqués : appels rejetés et SMS ignorés. */
@Singleton
class BlockedNumbersRepository @Inject constructor(
    private val dao: BlockedNumberDao,
) {

    fun observe(): Flow<List<String>> = dao.observeAll().map { list -> list.map { it.number } }

    suspend fun block(number: String) {
        val normalized = PhoneNumbers.normalize(number)
        if (normalized.isNotEmpty()) {
            dao.insert(BlockedNumberEntity(number = normalized, addedAtMillis = System.currentTimeMillis()))
        }
    }

    suspend fun unblock(number: String) {
        dao.delete(PhoneNumbers.normalize(number))
    }

    /** Vrai si le numéro correspond à un numéro bloqué (comparaison sur les neuf derniers chiffres). */
    suspend fun isBlocked(number: String): Boolean =
        dao.getAll().any { PhoneNumbers.sameNumber(it.number, number) }
}
