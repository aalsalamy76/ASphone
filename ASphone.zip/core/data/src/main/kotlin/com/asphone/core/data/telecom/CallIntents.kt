package com.asphone.core.data.telecom

import android.content.Intent
import android.net.Uri

/**
 * Intention d'appel explicite. Elle ne doit être utilisée qu'après une action directe de l'utilisateur
 * et une autorisation CALL_PHONE accordée. Aucun appel automatique n'est jamais lancé.
 */
object CallIntents {

    fun call(number: String): Intent =
        Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
