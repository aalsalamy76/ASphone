package com.asphone.core.data.di

import com.asphone.core.data.reminders.ReminderRunner
import com.asphone.core.data.scheduling.ScheduledSmsRunner
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/** Accès aux dépendances depuis les travaux WorkManager, qui ne sont pas injectés par Hilt. */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface WorkerEntryPoint {
    fun scheduledSmsRunner(): ScheduledSmsRunner
    fun reminderRunner(): ReminderRunner
}
