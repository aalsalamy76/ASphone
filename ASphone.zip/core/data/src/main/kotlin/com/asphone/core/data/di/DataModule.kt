package com.asphone.core.data.di

import android.content.Context
import androidx.room.Room
import com.asphone.core.database.ASphoneDatabase
import com.asphone.core.database.BlockedNumberDao
import com.asphone.core.database.ReminderDao
import com.asphone.core.database.ScheduledSmsDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): ASphoneDatabase =
        Room.databaseBuilder(context, ASphoneDatabase::class.java, ASphoneDatabase.NAME).build()

    @Provides
    fun provideScheduledSmsDao(database: ASphoneDatabase): ScheduledSmsDao = database.scheduledSmsDao()

    @Provides
    fun provideReminderDao(database: ASphoneDatabase): ReminderDao = database.reminderDao()

    @Provides
    fun provideBlockedNumberDao(database: ASphoneDatabase): BlockedNumberDao = database.blockedNumberDao()
}
