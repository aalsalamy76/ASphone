package com.asphone.core.data.sms

import android.content.ContentValues
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import com.asphone.core.data.contacts.ContactsRepository
import com.asphone.core.model.Conversation
import com.asphone.core.model.MessageState
import com.asphone.core.model.SmsDirection
import com.asphone.core.model.SmsMessage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lecture et écriture des SMS dans le fournisseur système (A.Sphone doit être l'application SMS par défaut
 * pour écrire et recevoir). Les états affichés reflètent uniquement ce que le système a confirmé.
 */
@Singleton
class SmsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val contacts: ContactsRepository,
) {

    private val resolver get() = context.contentResolver

    /** Conversations groupées par fil, la plus récente en premier. */
    suspend fun conversations(): List<Conversation> {
        val byThread = LinkedHashMap<Long, Conversation>()
        withContext(Dispatchers.IO) {
            resolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.READ),
                null,
                null,
                "${Telephony.Sms.DATE} DESC",
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val thread = cursor.getLong(0)
                    val unread = if (cursor.getInt(4) == 0) 1 else 0
                    val existing = byThread[thread]
                    if (existing == null) {
                        byThread[thread] = Conversation(
                            threadId = thread,
                            address = cursor.getString(1).orEmpty(),
                            displayName = null,
                            lastMessagePreview = cursor.getString(2).orEmpty(),
                            lastTimestampMillis = cursor.getLong(3),
                            unreadCount = unread,
                            pinned = false,
                        )
                    } else if (unread == 1) {
                        byThread[thread] = existing.copy(unreadCount = existing.unreadCount + 1)
                    }
                }
            }
        }
        return byThread.values.map { conversation ->
            conversation.copy(displayName = contacts.displayNameFor(conversation.address))
        }
    }

    /** Messages d'un fil, du plus ancien au plus récent. */
    suspend fun messages(threadId: Long): List<SmsMessage> = withContext(Dispatchers.IO) {
        val projection = arrayOf(
            Telephony.Sms._ID,
            Telephony.Sms.THREAD_ID,
            Telephony.Sms.ADDRESS,
            Telephony.Sms.BODY,
            Telephony.Sms.DATE,
            Telephony.Sms.TYPE,
            Telephony.Sms.STATUS,
            Telephony.Sms.READ,
            Telephony.Sms.SUBSCRIPTION_ID,
        )
        resolver.query(
            Telephony.Sms.CONTENT_URI,
            projection,
            "${Telephony.Sms.THREAD_ID} = ?",
            arrayOf(threadId.toString()),
            "${Telephony.Sms.DATE} ASC",
        )?.use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    val type = cursor.getInt(5)
                    val status = cursor.getInt(6)
                    add(
                        SmsMessage(
                            id = cursor.getLong(0),
                            threadId = cursor.getLong(1),
                            address = cursor.getString(2).orEmpty(),
                            body = cursor.getString(3).orEmpty(),
                            timestampMillis = cursor.getLong(4),
                            direction = mapDirection(type),
                            state = mapState(type, status),
                            read = cursor.getInt(7) == 1,
                            subscriptionId = cursor.getInt(8).takeIf { it >= 0 },
                        ),
                    )
                }
            }
        }.orEmpty()
    }

    /** Insère un message sortant en file d'attente (état QUEUED dans le fournisseur). */
    suspend fun insertOutgoing(address: String, body: String, subscriptionId: Int?): Long =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, address)
                put(Telephony.Sms.BODY, body)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.READ, 1)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
                if (subscriptionId != null && subscriptionId >= 0) {
                    put(Telephony.Sms.SUBSCRIPTION_ID, subscriptionId)
                }
            }
            val uri = resolver.insert(Telephony.Sms.Outbox.CONTENT_URI, values)
            uri?.lastPathSegment?.toLongOrNull() ?: -1L
        }

    /** Enregistre un SMS reçu (appelé uniquement après contrôle des numéros bloqués). */
    suspend fun storeIncoming(address: String, body: String, timestampMillis: Long, subscriptionId: Int?) =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, address)
                put(Telephony.Sms.BODY, body)
                put(Telephony.Sms.DATE, timestampMillis)
                put(Telephony.Sms.READ, 0)
                put(Telephony.Sms.SEEN, 0)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
                if (subscriptionId != null && subscriptionId >= 0) {
                    put(Telephony.Sms.SUBSCRIPTION_ID, subscriptionId)
                }
            }
            resolver.insert(Telephony.Sms.Inbox.CONTENT_URI, values)
            Unit
        }

    /** Met à jour l'état d'un message d'après le résultat réel de l'envoi ou de la remise. */
    suspend fun updateState(messageId: Long, state: MessageState) = withContext(Dispatchers.IO) {
        val values = ContentValues()
        when (state) {
            MessageState.SENDING, MessageState.QUEUED ->
                values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
            MessageState.SENT -> values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
            MessageState.DELIVERED -> {
                values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
                values.put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_COMPLETE)
            }
            MessageState.FAILED -> values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_FAILED)
            else -> return@withContext
        }
        resolver.update(messageUri(messageId), values, null, null)
        Unit
    }

    /** Marque comme lus tous les messages d'un fil. */
    suspend fun markThreadRead(threadId: Long) = withContext(Dispatchers.IO) {
        val values = ContentValues().apply { put(Telephony.Sms.READ, 1) }
        resolver.update(
            Telephony.Sms.CONTENT_URI,
            values,
            "${Telephony.Sms.THREAD_ID} = ? AND ${Telephony.Sms.READ} = 0",
            arrayOf(threadId.toString()),
        )
        Unit
    }

    /** Signal émis à chaque changement du fournisseur SMS (réception, envoi, mise à jour d'état). */
    fun changes(): Flow<Unit> = callbackFlow {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        resolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, observer)
        trySend(Unit)
        awaitClose { resolver.unregisterContentObserver(observer) }
    }.conflate()

    /** Identifiant du fil existant pour une adresse, ou null si aucune conversation n'existe encore. */
    suspend fun threadIdFor(address: String): Long? = withContext(Dispatchers.IO) {
        resolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.THREAD_ID),
            "${Telephony.Sms.ADDRESS} = ?",
            arrayOf(address),
            "${Telephony.Sms.DATE} DESC",
        )?.use { cursor -> if (cursor.moveToFirst()) cursor.getLong(0) else null }
    }

    private fun messageUri(messageId: Long): Uri =
        Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, messageId.toString())

    private fun mapDirection(type: Int): SmsDirection = when (type) {
        Telephony.Sms.MESSAGE_TYPE_INBOX -> SmsDirection.INBOX
        Telephony.Sms.MESSAGE_TYPE_DRAFT -> SmsDirection.DRAFT
        Telephony.Sms.MESSAGE_TYPE_OUTBOX,
        Telephony.Sms.MESSAGE_TYPE_QUEUED,
        -> SmsDirection.OUTBOX
        else -> SmsDirection.SENT
    }

    private fun mapState(type: Int, status: Int): MessageState = when (type) {
        Telephony.Sms.MESSAGE_TYPE_INBOX -> MessageState.RECEIVED
        Telephony.Sms.MESSAGE_TYPE_DRAFT -> MessageState.DRAFT
        Telephony.Sms.MESSAGE_TYPE_OUTBOX, Telephony.Sms.MESSAGE_TYPE_QUEUED -> MessageState.QUEUED
        Telephony.Sms.MESSAGE_TYPE_FAILED -> MessageState.FAILED
        else -> if (status == Telephony.Sms.STATUS_COMPLETE) MessageState.DELIVERED else MessageState.SENT
    }
}
