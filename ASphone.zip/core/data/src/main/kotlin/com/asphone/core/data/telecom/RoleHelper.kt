package com.asphone.core.data.telecom

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.telecom.TelecomManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Rôles système : Téléphone (ROLE_DIALER) et SMS (ROLE_SMS).
 * Sur Android 10+ on utilise RoleManager ; avant, les intentions système équivalentes.
 */
@Singleton
class RoleHelper @Inject constructor(
    @ApplicationContext private val context: Context,
) {

    fun isDialerHeld(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return roleManager()?.isRoleHeld(RoleManager.ROLE_DIALER) == true
        }
        val telecom = context.getSystemService(TelecomManager::class.java)
        return telecom?.defaultDialerPackage == context.packageName
    }

    fun dialerRequestIntent(): Intent? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return roleManager()?.createRequestRoleIntent(RoleManager.ROLE_DIALER)
        }
        return Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, context.packageName)
    }

    fun isSmsHeld(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return roleManager()?.isRoleHeld(RoleManager.ROLE_SMS) == true
        }
        return Telephony.Sms.getDefaultSmsPackage(context) == context.packageName
    }

    fun smsRequestIntent(): Intent? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return roleManager()?.createRequestRoleIntent(RoleManager.ROLE_SMS)
        }
        return Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, context.packageName)
    }

    private fun roleManager(): RoleManager? = context.getSystemService(RoleManager::class.java)
}
