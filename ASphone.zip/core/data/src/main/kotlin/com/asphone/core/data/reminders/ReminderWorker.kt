package com.asphone.core.data.reminders

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ListenableWorker
import androidx.work.WorkerParameters
import com.asphone.core.data.di.WorkerEntryPoint
import dagger.hilt.android.EntryPointAccessors

/** Travail WorkManager qui déclenche la notification d'un rappel à son échéance. */
class ReminderWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): ListenableWorker.Result {
        val id = inputData.getLong(KEY_ID, -1L)
        if (id < 0) return ListenableWorker.Result.failure()
        EntryPointAccessors
            .fromApplication(applicationContext, WorkerEntryPoint::class.java)
            .reminderRunner()
            .execute(id)
        return ListenableWorker.Result.success()
    }

    companion object {
        const val KEY_ID = "reminder_id"
    }
}
