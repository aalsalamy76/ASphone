package com.asphone.core.data.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationManagerCompat
import com.asphone.core.designsystem.R

/** Canaux de notification créés au démarrage de l'application. */
object NotificationChannels {

    const val REMINDERS = "reminders"
    const val SCHEDULED_SMS = "scheduled_sms"
    const val INCOMING_SMS = "incoming_sms"

    fun createAll(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val channels = listOf(
            NotificationChannel(REMINDERS, context.getString(R.string.notif_channel_reminders), NotificationManager.IMPORTANCE_HIGH),
            NotificationChannel(SCHEDULED_SMS, context.getString(R.string.notif_channel_scheduled), NotificationManager.IMPORTANCE_DEFAULT),
            NotificationChannel(INCOMING_SMS, context.getString(R.string.notif_channel_incoming), NotificationManager.IMPORTANCE_HIGH),
        )
        manager.createNotificationChannels(channels)
    }

    /** Vrai si l'utilisateur autorise les notifications de l'application. */
    fun areEnabled(context: Context): Boolean = NotificationManagerCompat.from(context).areNotificationsEnabled()
}
