package com.asphone.core.data.reminders

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.asphone.core.data.notifications.NotificationChannels
import com.asphone.core.data.notifications.ReminderActions
import com.asphone.core.designsystem.R
import com.asphone.core.model.Reminder
import com.asphone.core.model.ReminderKind
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Affiche les rappels. Le numéro n'est jamais composé automatiquement : « Appeler maintenant »
 * ouvre seulement le composeur du téléphone.
 */
@Singleton
class ReminderNotifier @Inject constructor(
    @ApplicationContext private val context: Context,
) {

    @SuppressLint("MissingPermission")
    fun show(reminder: Reminder) {
        if (!NotificationChannels.areEnabled(context)) return

        val name = reminder.contactName ?: reminder.number
        val titleRes = if (reminder.kind == ReminderKind.CALL) {
            R.string.notif_reminder_call_title
        } else {
            R.string.notif_reminder_message_title
        }
        val title = context.getString(titleRes, name)
        val text = reminder.note.ifBlank { context.getString(R.string.notif_reminder_text_default) }
        val hidden = context.getString(R.string.notif_reminder_hidden)

        val publicVersion = NotificationCompat.Builder(context, NotificationChannels.REMINDERS)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(hidden)
            .build()

        val builder = NotificationCompat.Builder(context, NotificationChannels.REMINDERS)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openIntent(ReminderActions.OPEN_REMINDERS, reminder))
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)

        if (reminder.kind == ReminderKind.CALL) {
            builder.addAction(0, context.getString(R.string.action_call_now), dialIntent(reminder.number))
        } else {
            builder.addAction(0, context.getString(R.string.action_compose), openIntent(ReminderActions.OPEN_THREAD, reminder))
        }
        builder
            .addAction(0, context.getString(R.string.action_snooze_10), actionIntent(ReminderActions.SNOOZE_10, reminder.id, 1))
            .addAction(0, context.getString(R.string.action_done), actionIntent(ReminderActions.DONE, reminder.id, 2))

        NotificationManagerCompat.from(context).notify(notificationId(reminder.id), builder.build())
    }

    fun cancel(reminderId: Long) {
        NotificationManagerCompat.from(context).cancel(notificationId(reminderId))
    }

    private fun dialIntent(number: String): PendingIntent {
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
        return PendingIntent.getActivity(
            context,
            notificationId(0) + 3,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun openIntent(action: String, reminder: Reminder): PendingIntent {
        val intent = Intent(action)
            .setPackage(context.packageName)
            .putExtra(ReminderActions.EXTRA_REMINDER_ID, reminder.id)
            .putExtra(ReminderActions.EXTRA_NUMBER, reminder.number)
        return PendingIntent.getActivity(
            context,
            notificationId(reminder.id) + action.length % 7,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun actionIntent(action: String, reminderId: Long, slot: Int): PendingIntent {
        val intent = Intent(action)
            .setPackage(context.packageName)
            .putExtra(ReminderActions.EXTRA_REMINDER_ID, reminderId)
        return PendingIntent.getBroadcast(
            context,
            notificationId(reminderId) + slot,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun notificationId(reminderId: Long): Int = (BASE_ID + reminderId).toInt()

    private companion object {
        const val BASE_ID = 10_000L
    }
}
