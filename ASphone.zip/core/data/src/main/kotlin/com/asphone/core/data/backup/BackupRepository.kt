package com.asphone.core.data.backup

import com.asphone.core.data.blocking.BlockedNumbersRepository
import com.asphone.core.data.reminders.ReminderRepository
import com.asphone.core.data.scheduling.ScheduleValidationException
import com.asphone.core.data.scheduling.ScheduledSmsRepository
import com.asphone.core.data.settings.SettingsRepository
import com.asphone.core.model.Recurrence
import com.asphone.core.model.RecurrenceType
import com.asphone.core.model.ReminderKind
import com.asphone.core.model.ReminderStatus
import com.asphone.core.model.ScheduledStatus
import com.asphone.core.model.ThemeMode
import com.asphone.core.security.BackupCrypto
import com.asphone.core.security.BackupException
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.time.DayOfWeek
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class BackupSettings(
    val themeMode: String,
    val amoled: Boolean,
    val dynamicColor: Boolean,
)

@Serializable
data class ScheduledSmsBackup(
    val recipients: List<String>,
    val body: String,
    val nextRunMillis: Long,
    val zoneId: String,
    val subscriptionId: Int?,
    val recurrenceType: String,
    val intervalDays: Int,
    val daysOfWeek: List<String>,
)

@Serializable
data class ReminderBackup(
    val kind: String,
    val number: String,
    val contactName: String?,
    val note: String,
    val dueAtMillis: Long,
    val zoneId: String,
    val draftText: String?,
)

/** Contenu d'une sauvegarde, format versionné. */
@Serializable
data class BackupPayload(
    val format: String = FORMAT,
    val version: Int = VERSION,
    val createdAtMillis: Long,
    val settings: BackupSettings,
    val scheduledSms: List<ScheduledSmsBackup>,
    val reminders: List<ReminderBackup>,
    val blockedNumbers: List<String>,
) {
    companion object {
        const val FORMAT = "asphone-backup"
        const val VERSION = 1
    }
}

/** Bilan d'une restauration : les éléments échus ou invalides sont ignorés et comptés. */
data class RestoreResult(
    val schedules: Int,
    val reminders: Int,
    val blockedNumbers: Int,
    val skipped: Int,
)

/**
 * Sauvegarde chiffrée locale : programmations, rappels, numéros bloqués et préférences.
 * Les contacts, SMS et historiques d'appels ne sont pas inclus dans cette version.
 */
@Singleton
class BackupRepository @Inject constructor(
    private val scheduled: ScheduledSmsRepository,
    private val reminders: ReminderRepository,
    private val blocked: BlockedNumbersRepository,
    private val settings: SettingsRepository,
) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    suspend fun export(passphrase: CharArray, nowMillis: Long): ByteArray {
        val schedules = scheduled.observe().first()
            .filter { it.status == ScheduledStatus.ACTIVE || it.status == ScheduledStatus.SUSPENDED }
            .map { schedule ->
                ScheduledSmsBackup(
                    recipients = schedule.recipients,
                    body = schedule.body,
                    nextRunMillis = schedule.nextRunMillis,
                    zoneId = schedule.zoneId,
                    subscriptionId = schedule.subscriptionId,
                    recurrenceType = schedule.recurrence.type.name,
                    intervalDays = schedule.recurrence.intervalDays,
                    daysOfWeek = schedule.recurrence.daysOfWeek.map { it.name }.sorted(),
                )
            }
        val pending = reminders.observe().first()
            .filter { it.status == ReminderStatus.PENDING }
            .map { reminder ->
                ReminderBackup(
                    kind = reminder.kind.name,
                    number = reminder.number,
                    contactName = reminder.contactName,
                    note = reminder.note,
                    dueAtMillis = reminder.dueAtMillis,
                    zoneId = reminder.zoneId,
                    draftText = reminder.draftText,
                )
            }
        val preferences = settings.settings.first()
        val payload = BackupPayload(
            createdAtMillis = nowMillis,
            settings = BackupSettings(
                themeMode = preferences.themeMode.name,
                amoled = preferences.amoled,
                dynamicColor = preferences.dynamicColor,
            ),
            scheduledSms = schedules,
            reminders = pending,
            blockedNumbers = blocked.observe().first(),
        )
        val text = json.encodeToString(BackupPayload.serializer(), payload)
        return BackupCrypto.encrypt(text.encodeToByteArray(), passphrase)
    }

    /** Restaure une sauvegarde. Lève [BackupException] si la phrase est fausse ou le fichier altéré. */
    suspend fun restore(bytes: ByteArray, passphrase: CharArray, nowMillis: Long): RestoreResult {
        val plaintext = BackupCrypto.decrypt(bytes, passphrase)
        val payload = try {
            json.decodeFromString(BackupPayload.serializer(), plaintext.decodeToString())
        } catch (error: kotlinx.serialization.SerializationException) {
            throw BackupException("Contenu de sauvegarde illisible.", error)
        }
        if (payload.format != BackupPayload.FORMAT || payload.version != BackupPayload.VERSION) {
            throw BackupException("Version de sauvegarde non prise en charge.")
        }

        var skipped = 0
        var restoredSchedules = 0
        payload.scheduledSms.forEach { item ->
            try {
                scheduled.create(
                    recipients = item.recipients,
                    body = item.body,
                    runAtMillis = item.nextRunMillis,
                    zoneId = item.zoneId,
                    subscriptionId = item.subscriptionId,
                    recurrence = Recurrence(
                        type = RecurrenceType.valueOf(item.recurrenceType),
                        intervalDays = item.intervalDays,
                        daysOfWeek = item.daysOfWeek.map { DayOfWeek.valueOf(it) }.toSet(),
                    ),
                )
                restoredSchedules++
            } catch (error: ScheduleValidationException) {
                skipped++
            } catch (error: IllegalArgumentException) {
                skipped++
            }
        }

        var restoredReminders = 0
        payload.reminders.forEach { item ->
            if (item.dueAtMillis <= nowMillis) {
                skipped++
            } else {
                reminders.create(
                    kind = ReminderKind.valueOf(item.kind),
                    number = item.number,
                    contactName = item.contactName,
                    note = item.note,
                    dueAtMillis = item.dueAtMillis,
                    zoneId = item.zoneId,
                    draftText = item.draftText,
                )
                restoredReminders++
            }
        }

        payload.blockedNumbers.forEach { blocked.block(it) }

        settings.setThemeMode(runCatching { ThemeMode.valueOf(payload.settings.themeMode) }.getOrDefault(ThemeMode.SYSTEM))
        settings.setAmoled(payload.settings.amoled)
        settings.setDynamicColor(payload.settings.dynamicColor)

        return RestoreResult(
            schedules = restoredSchedules,
            reminders = restoredReminders,
            blockedNumbers = payload.blockedNumbers.size,
            skipped = skipped,
        )
    }
}
