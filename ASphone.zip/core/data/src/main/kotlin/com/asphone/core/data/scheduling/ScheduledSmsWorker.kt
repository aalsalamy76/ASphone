package com.asphone.core.data.scheduling

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ListenableWorker
import androidx.work.WorkerParameters
import com.asphone.core.data.di.WorkerEntryPoint
import dagger.hilt.android.EntryPointAccessors

/** Travail WorkManager : exécute une programmation. Il ne relance jamais en boucle. */
class ScheduledSmsWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): ListenableWorker.Result {
        val id = inputData.getLong(KEY_ID, -1L)
        if (id < 0) return ListenableWorker.Result.failure()
        val runner = EntryPointAccessors
            .fromApplication(applicationContext, WorkerEntryPoint::class.java)
            .scheduledSmsRunner()
        runner.execute(id)
        return ListenableWorker.Result.success()
    }

    companion object {
        const val KEY_ID = "scheduled_sms_id"
    }
}
