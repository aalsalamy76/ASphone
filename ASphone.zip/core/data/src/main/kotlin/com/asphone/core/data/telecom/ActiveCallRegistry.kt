package com.asphone.core.data.telecom

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.IdentityHashMap
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

enum class CallPhase { RINGING, DIALING, ACTIVE, ON_HOLD, DISCONNECTED }

/** Vue d'un appel en cours, sans référence au framework Telecom. */
data class ActiveCall(
    val id: String,
    val number: String,
    val displayName: String?,
    val phase: CallPhase,
)

/**
 * Registre des appels gérés par [com.asphone.app.telecom.CallService] (InCallService).
 * Il ne conserve aucun enregistrement audio et ne transcrit jamais un appel.
 */
@Singleton
class ActiveCallRegistry @Inject constructor() {

    private val _calls = MutableStateFlow<List<ActiveCall>>(emptyList())
    val calls: StateFlow<List<ActiveCall>> = _calls.asStateFlow()

    private val ids = IdentityHashMap<Call, String>()
    private val live = mutableListOf<Call>()
    private var service: InCallService? = null

    fun attach(service: InCallService) {
        this.service = service
    }

    fun detach() {
        service = null
    }

    fun onCallAdded(call: Call) {
        val id = UUID.randomUUID().toString()
        ids[call] = id
        live += call
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) = publish()
            override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
        })
        publish()
    }

    fun onCallRemoved(call: Call) {
        live.remove(call)
        ids.remove(call)
        publish()
    }

    fun answer(id: String) = withCall(id) { it.answer(VideoProfile.STATE_AUDIO_ONLY) }

    fun reject(id: String) = withCall(id) { it.reject(false, null) }

    fun hangUp(id: String) = withCall(id) { it.disconnect() }

    fun setOnHold(id: String, hold: Boolean) = withCall(id) { if (hold) it.hold() else it.unhold() }

    fun setMuted(muted: Boolean) {
        service?.setMuted(muted)
    }

    fun setSpeaker(enabled: Boolean) {
        val route = if (enabled) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE
        service?.setAudioRoute(route)
    }

    private fun withCall(id: String, action: (Call) -> Unit) {
        live.firstOrNull { ids[it] == id }?.let(action)
    }

    private fun publish() {
        _calls.value = live.mapNotNull { call ->
            val id = ids[call] ?: return@mapNotNull null
            ActiveCall(
                id = id,
                number = call.details?.handle?.schemeSpecificPart.orEmpty(),
                displayName = call.details?.callerDisplayName?.takeIf { it.isNotBlank() },
                phase = phaseOf(call.state),
            )
        }
    }

    private fun phaseOf(state: Int): CallPhase = when (state) {
        Call.STATE_RINGING, Call.STATE_SIMULATED_RINGING -> CallPhase.RINGING
        Call.STATE_ACTIVE -> CallPhase.ACTIVE
        Call.STATE_HOLDING -> CallPhase.ON_HOLD
        Call.STATE_DISCONNECTED -> CallPhase.DISCONNECTED
        else -> CallPhase.DIALING
    }
}
