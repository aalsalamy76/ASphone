package com.asphone.core.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.asphone.core.model.AppSettings
import com.asphone.core.model.ThemeMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Préférences persistées dans DataStore (aucune donnée sensible). */
@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val amoledKey = booleanPreferencesKey("amoled")
    private val dynamicKey = booleanPreferencesKey("dynamic_color")
    private val notifyDetailsKey = booleanPreferencesKey("notify_details")

    val settings: Flow<AppSettings> = context.settingsStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[themeKey]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            amoled = prefs[amoledKey] ?: false,
            dynamicColor = prefs[dynamicKey] ?: true,
        )
    }

    /** Vrai si le contenu des messages peut apparaître dans les notifications. */
    val showMessageDetails: Flow<Boolean> = context.settingsStore.data.map { prefs ->
        prefs[notifyDetailsKey] ?: true
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsStore.edit { it[themeKey] = mode.name }
    }

    suspend fun setAmoled(enabled: Boolean) {
        context.settingsStore.edit { it[amoledKey] = enabled }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.settingsStore.edit { it[dynamicKey] = enabled }
    }

    suspend fun setShowMessageDetails(enabled: Boolean) {
        context.settingsStore.edit { it[notifyDetailsKey] = enabled }
    }
}
