package com.asphone.core.data.scheduling

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.asphone.core.database.ScheduledSmsDao
import com.asphone.core.database.ScheduledSmsEntity
import com.asphone.core.model.Recurrence
import com.asphone.core.model.RecurrenceType
import com.asphone.core.model.ScheduleError
import com.asphone.core.model.ScheduledSms
import com.asphone.core.model.ScheduledSmsValidator
import com.asphone.core.model.ScheduledStatus
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.DayOfWeek
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/** Erreur de validation d'un SMS programmé ; la liste contient les motifs. */
class ScheduleValidationException(val errors: List<ScheduleError>) :
    IllegalArgumentException("Programmation invalide : $errors")

/**
 * Persistance (Room) et planification (WorkManager) des SMS programmés.
 * WorkManager reprend automatiquement les tâches après un redémarrage du téléphone.
 */
@Singleton
class ScheduledSmsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dao: ScheduledSmsDao,
) {

    fun observe(): Flow<List<ScheduledSms>> = dao.observeAll().map { list -> list.map(::toModel) }

    suspend fun get(id: Long): ScheduledSms? = dao.getById(id)?.let(::toModel)

    suspend fun create(
        recipients: List<String>,
        body: String,
        runAtMillis: Long,
        zoneId: String,
        subscriptionId: Int?,
        recurrence: Recurrence,
    ): Long {
        val errors = ScheduledSmsValidator.validate(recipients, body, runAtMillis, System.currentTimeMillis())
        if (errors.isNotEmpty()) throw ScheduleValidationException(errors)
        val id = dao.insert(
            ScheduledSmsEntity(
                recipients = recipients.joinToString(SEPARATOR),
                body = body,
                firstRunMillis = runAtMillis,
                nextRunMillis = runAtMillis,
                zoneId = zoneId,
                subscriptionId = subscriptionId,
                recurrenceType = recurrence.type.name,
                intervalDays = recurrence.intervalDays,
                daysOfWeek = recurrence.daysOfWeek.joinToString(",") { it.name },
                status = ScheduledStatus.ACTIVE.name,
                lastError = null,
            ),
        )
        enqueue(id, runAtMillis)
        return id
    }

    /** Suspend ou réactive une programmation. */
    suspend fun setSuspended(id: Long, suspended: Boolean) {
        val entity = dao.getById(id) ?: return
        if (suspended) {
            dao.update(entity.copy(status = ScheduledStatus.SUSPENDED.name))
            cancelWork(id)
        } else {
            dao.update(entity.copy(status = ScheduledStatus.ACTIVE.name))
            enqueue(id, entity.nextRunMillis)
        }
    }

    suspend fun cancel(id: Long) {
        val entity = dao.getById(id) ?: return
        dao.update(entity.copy(status = ScheduledStatus.CANCELLED.name))
        cancelWork(id)
    }

    /** Duplique une programmation, décalée d'une heure après sa prochaine émission. */
    suspend fun duplicate(id: Long): Long? {
        val entity = dao.getById(id) ?: return null
        val runAt = maxOf(entity.nextRunMillis, System.currentTimeMillis()) + ONE_HOUR_MILLIS
        return create(
            recipients = entity.recipients.split(SEPARATOR).filter { it.isNotBlank() },
            body = entity.body,
            runAtMillis = runAt,
            zoneId = entity.zoneId,
            subscriptionId = entity.subscriptionId,
            recurrence = Recurrence(
                type = RecurrenceType.valueOf(entity.recurrenceType),
                intervalDays = entity.intervalDays,
                daysOfWeek = parseDays(entity.daysOfWeek),
            ),
        )
    }

    /** Replanifie toutes les programmations actives (appelé au démarrage de l'application). */
    suspend fun rescheduleActive() {
        dao.getActive().forEach { enqueue(it.id, it.nextRunMillis) }
    }

    /** Enregistre une erreur sur la programmation (par ex. permission retirée). */
    suspend fun recordError(id: Long, message: String) {
        val entity = dao.getById(id) ?: return
        dao.update(entity.copy(status = ScheduledStatus.FAILED.name, lastError = message))
    }

    /**
     * Après une émission : calcule la prochaine occurrence, ou termine la programmation.
     * Renvoie la nouvelle échéance ou null si la programmation est terminée.
     */
    suspend fun advanceAfterRun(id: Long, nextRunMillis: Long?) {
        val entity = dao.getById(id) ?: return
        if (nextRunMillis == null) {
            dao.update(entity.copy(status = ScheduledStatus.COMPLETED.name))
        } else {
            dao.update(entity.copy(nextRunMillis = nextRunMillis))
            enqueue(id, nextRunMillis)
        }
    }

    private fun enqueue(id: Long, runAtMillis: Long) {
        val delay = (runAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<ScheduledSmsWorker>()
            .setInputData(workDataOf(ScheduledSmsWorker.KEY_ID to id))
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(workName(id), ExistingWorkPolicy.REPLACE, request)
    }

    private fun cancelWork(id: Long) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(id))
    }

    private fun toModel(entity: ScheduledSmsEntity): ScheduledSms = ScheduledSms(
        id = entity.id,
        recipients = entity.recipients.split(SEPARATOR).filter { it.isNotBlank() },
        body = entity.body,
        firstRunMillis = entity.firstRunMillis,
        zoneId = entity.zoneId,
        subscriptionId = entity.subscriptionId,
        recurrence = Recurrence(
            type = RecurrenceType.valueOf(entity.recurrenceType),
            intervalDays = entity.intervalDays,
            daysOfWeek = parseDays(entity.daysOfWeek),
        ),
        status = runCatching { ScheduledStatus.valueOf(entity.status) }.getOrDefault(ScheduledStatus.FAILED),
        nextRunMillis = entity.nextRunMillis,
    )

    private fun parseDays(raw: String): Set<DayOfWeek> =
        raw.split(",").filter { it.isNotBlank() }.map { DayOfWeek.valueOf(it) }.toSet()

    companion object {
        const val SEPARATOR = ";"
        private const val ONE_HOUR_MILLIS = 3_600_000L

        fun workName(id: Long): String = "scheduled-sms-$id"
    }
}
