package com.asphone.core.data.contacts

import android.content.ContentProviderOperation
import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds
import com.asphone.core.common.ContactCandidate
import com.asphone.core.common.DuplicateDetector
import com.asphone.core.common.DuplicateGroup
import com.asphone.core.common.PhoneNumbers
import com.asphone.core.common.T9
import com.asphone.core.model.ContactSummary
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/** Détail d'un contact : tous les numéros et adresses e-mail. */
data class ContactDetail(
    val id: Long,
    val displayName: String,
    val phones: List<String>,
    val emails: List<String>,
    val starred: Boolean,
)

/** Accès à ContactsContract. Aucune suppression ou fusion automatique n'est effectuée. */
@Singleton
class ContactsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {

    private val resolver: ContentResolver get() = context.contentResolver

    /** Tous les contacts triés par nom ; le filtrage se fait ensuite côté domaine. */
    suspend fun listAll(): List<ContactSummary> = withContext(Dispatchers.IO) {
        val phones = phonesByContact()
        val contacts = mutableListOf<ContactSummary>()
        val projection = arrayOf(
            ContactsContract.Contacts._ID,
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
            ContactsContract.Contacts.STARRED,
        )
        resolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            projection,
            null,
            null,
            "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} COLLATE NOCASE ASC",
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                contacts += ContactSummary(
                    id = id,
                    displayName = cursor.getString(1).orEmpty(),
                    primaryPhone = phones[id]?.firstOrNull(),
                    starred = cursor.getInt(2) == 1,
                )
            }
        }
        contacts
    }

    /** Recherche : nom, sous-chaîne, numéro ou correspondance T9. */
    suspend fun search(query: String): List<ContactSummary> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return listAll()
        val digitsOnly = trimmed.all { it.isDigit() || it == '+' || it == ' ' }
        return listAll().filter { contact ->
            contact.displayName.contains(trimmed, ignoreCase = true) ||
                (digitsOnly && contact.primaryPhone?.let { PhoneNumbers.key(it).contains(PhoneNumbers.key(trimmed)) } == true) ||
                T9.matches(trimmed, contact.displayName)
        }
    }

    suspend fun detail(contactId: Long): ContactDetail? = withContext(Dispatchers.IO) {
        val projection = arrayOf(
            ContactsContract.Contacts._ID,
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
            ContactsContract.Contacts.STARRED,
        )
        val base = resolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            projection,
            "${ContactsContract.Contacts._ID} = ?",
            arrayOf(contactId.toString()),
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                Triple(cursor.getLong(0), cursor.getString(1).orEmpty(), cursor.getInt(2) == 1)
            } else {
                null
            }
        } ?: return@withContext null

        ContactDetail(
            id = base.first,
            displayName = base.second,
            phones = queryColumn(
                CommonDataKinds.Phone.CONTENT_URI,
                CommonDataKinds.Phone.NUMBER,
                contactId,
            ),
            emails = queryColumn(
                CommonDataKinds.Email.CONTENT_URI,
                CommonDataKinds.Email.ADDRESS,
                contactId,
            ),
            starred = base.third,
        )
    }

    /** Crée un contact (nom, numéro, e-mail facultatif) dans le compte local du téléphone. */
    suspend fun create(name: String, phone: String, email: String?) = withContext(Dispatchers.IO) {
        val ops = arrayListOf(
            ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(CommonDataKinds.Phone.NUMBER, phone)
                .withValue(CommonDataKinds.Phone.TYPE, CommonDataKinds.Phone.TYPE_MOBILE)
                .build(),
        )
        if (!email.isNullOrBlank()) {
            ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                .withValue(CommonDataKinds.Email.ADDRESS, email)
                .withValue(CommonDataKinds.Email.TYPE, CommonDataKinds.Email.TYPE_HOME)
                .build()
        }
        resolver.applyBatch(ContactsContract.AUTHORITY, ops)
        Unit
    }

    /** Supprime le contact (toutes ses lignes brutes). L'appelant doit avoir confirmé. */
    suspend fun delete(contactId: Long): Int = withContext(Dispatchers.IO) {
        val rawIds = resolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts._ID),
            "${ContactsContract.RawContacts.CONTACT_ID} = ?",
            arrayOf(contactId.toString()),
            null,
        )?.use { cursor ->
            buildList { while (cursor.moveToNext()) add(cursor.getLong(0)) }
        }.orEmpty()
        rawIds.sumOf { rawId ->
            resolver.delete(
                Uri.withAppendedPath(ContactsContract.RawContacts.CONTENT_URI, rawId.toString()),
                null,
                null,
            )
        }
    }

    /** Groupes de doublons proposés à l'utilisateur (aucune fusion automatique). */
    suspend fun findDuplicates(): List<DuplicateGroup> {
        val candidates = listAll().map { summary ->
            val detail = detail(summary.id)
            ContactCandidate(summary.id, summary.displayName, detail?.phones.orEmpty())
        }
        return DuplicateDetector.find(candidates)
    }

    /** Nom affiché pour un numéro, ou null si inconnu. */
    suspend fun displayNameFor(number: String): String? = withContext(Dispatchers.IO) {
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        resolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    }

    private fun phonesByContact(): Map<Long, List<String>> {
        val map = mutableMapOf<Long, MutableList<String>>()
        resolver.query(
            CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(CommonDataKinds.Phone.CONTACT_ID, CommonDataKinds.Phone.NUMBER),
            null,
            null,
            null,
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                map.getOrPut(cursor.getLong(0)) { mutableListOf() }.add(cursor.getString(1).orEmpty())
            }
        }
        return map
    }

    private fun queryColumn(uri: Uri, column: String, contactId: Long): List<String> =
        resolver.query(
            uri,
            arrayOf(column),
            "${ContactsContract.Data.CONTACT_ID} = ?",
            arrayOf(contactId.toString()),
            null,
        )?.use { cursor ->
            buildList { while (cursor.moveToNext()) add(cursor.getString(0).orEmpty()) }
        }.orEmpty()
}
