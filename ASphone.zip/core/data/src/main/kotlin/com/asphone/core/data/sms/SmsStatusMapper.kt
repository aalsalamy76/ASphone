package com.asphone.core.data.sms

import android.app.Activity
import com.asphone.core.model.MessageState

/**
 * Traduit le résultat renvoyé par le système en état de message.
 * Un résultat différent de RESULT_OK n'est jamais considéré comme un envoi réussi.
 */
object SmsStatusMapper {

    fun sentState(resultCode: Int): MessageState =
        if (resultCode == Activity.RESULT_OK) MessageState.SENT else MessageState.FAILED

    fun deliveredState(resultCode: Int): MessageState =
        if (resultCode == Activity.RESULT_OK) MessageState.DELIVERED else MessageState.FAILED
}
