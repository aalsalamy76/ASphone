package com.asphone.core.data.reminders

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.asphone.core.database.ReminderDao
import com.asphone.core.database.ReminderEntity
import com.asphone.core.model.Reminder
import com.asphone.core.model.ReminderKind
import com.asphone.core.model.ReminderStatus
import com.asphone.core.model.ReminderTiming
import com.asphone.core.model.SnoozeOption
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Rappels d'appel et de message. Un rappel ne compose jamais de numéro et n'envoie jamais de message :
 * il ne fait que proposer des actions à l'utilisateur.
 */
@Singleton
class ReminderRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dao: ReminderDao,
) {

    fun observe(): Flow<List<Reminder>> = dao.observeAll().map { list -> list.map(::toModel) }

    suspend fun get(id: Long): Reminder? = dao.getById(id)?.let(::toModel)

    suspend fun create(
        kind: ReminderKind,
        number: String,
        contactName: String?,
        note: String,
        dueAtMillis: Long,
        zoneId: String,
        draftText: String?,
    ): Long {
        val id = dao.insert(
            ReminderEntity(
                kind = kind.name,
                number = number,
                contactName = contactName,
                note = note,
                dueAtMillis = dueAtMillis,
                zoneId = zoneId,
                status = ReminderStatus.PENDING.name,
                draftText = draftText,
            ),
        )
        enqueue(id, dueAtMillis)
        return id
    }

    suspend fun complete(id: Long) = updateStatus(id, ReminderStatus.DONE)

    suspend fun cancel(id: Long) = updateStatus(id, ReminderStatus.CANCELLED)

    /** Reporte l'échéance selon l'option choisie dans la notification ou l'écran. */
    suspend fun snooze(id: Long, option: SnoozeOption) {
        val entity = dao.getById(id) ?: return
        val now = System.currentTimeMillis()
        val newDue = ReminderTiming.snooze(entity.dueAtMillis, entity.zoneId, option, now)
        dao.update(entity.copy(dueAtMillis = newDue, status = ReminderStatus.PENDING.name))
        enqueue(id, newDue)
    }

    suspend fun rescheduleActive() {
        dao.getPending().forEach { enqueue(it.id, it.dueAtMillis) }
    }

    private suspend fun updateStatus(id: Long, status: ReminderStatus) {
        val entity = dao.getById(id) ?: return
        dao.update(entity.copy(status = status.name))
        WorkManager.getInstance(context).cancelUniqueWork(workName(id))
    }

    private fun enqueue(id: Long, dueAtMillis: Long) {
        val delay = (dueAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInputData(workDataOf(ReminderWorker.KEY_ID to id))
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(workName(id), ExistingWorkPolicy.REPLACE, request)
    }

    private fun toModel(entity: ReminderEntity): Reminder = Reminder(
        id = entity.id,
        kind = runCatching { ReminderKind.valueOf(entity.kind) }.getOrDefault(ReminderKind.CALL),
        number = entity.number,
        contactName = entity.contactName,
        note = entity.note,
        dueAtMillis = entity.dueAtMillis,
        zoneId = entity.zoneId,
        status = runCatching { ReminderStatus.valueOf(entity.status) }.getOrDefault(ReminderStatus.PENDING),
        draftText = entity.draftText,
    )

    companion object {
        fun workName(id: Long): String = "reminder-$id"
    }
}
