package com.asphone.core.data.sms

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager
import com.asphone.core.model.MessageState
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Actions diffusées par le système lorsque l'envoi ou la remise est confirmé. */
object SmsActions {
    const val SENT = "com.asphone.app.action.SMS_SENT"
    const val DELIVERED = "com.asphone.app.action.SMS_DELIVERED"
    const val EXTRA_MESSAGE_ID = "com.asphone.app.extra.MESSAGE_ID"
}

/**
 * Envoi de SMS via SmsManager. Le message n'est marqué « envoyé » que lorsque le système
 * confirme l'envoi (résultat RESULT_OK) dans [SmsStatusReceiver].
 */
@Singleton
class SmsSender @Inject constructor(
    @ApplicationContext private val context: Context,
    private val smsRepository: SmsRepository,
) {

    /**
     * Envoie un SMS à un destinataire. Renvoie l'identifiant du message dans le fournisseur SMS.
     * En cas d'erreur immédiate, le message passe à [MessageState.FAILED].
     */
    suspend fun send(address: String, body: String, subscriptionId: Int?): Long {
        require(body.isNotBlank()) { "Le message ne peut pas être vide." }
        val messageId = smsRepository.insertOutgoing(address, body, subscriptionId)
        if (messageId < 0) return messageId

        val manager = smsManager(subscriptionId)
        val parts = manager.divideMessage(body)
        val sentIntent = statusIntent(SmsActions.SENT, messageId, requestOffset = 0)
        val deliveredIntent = statusIntent(SmsActions.DELIVERED, messageId, requestOffset = 1)

        val dispatched = runCatching {
            if (parts.size == 1) {
                manager.sendTextMessage(address, null, body, sentIntent, deliveredIntent)
            } else {
                manager.sendMultipartTextMessage(
                    address,
                    null,
                    parts,
                    arrayListOf(sentIntent),
                    arrayListOf(deliveredIntent),
                )
            }
        }
        if (dispatched.isFailure) {
            smsRepository.updateState(messageId, MessageState.FAILED)
        } else {
            smsRepository.updateState(messageId, MessageState.SENDING)
        }
        return messageId
    }

    private fun statusIntent(action: String, messageId: Long, requestOffset: Int): PendingIntent {
        val intent = Intent(action)
            .setPackage(context.packageName)
            .putExtra(SmsActions.EXTRA_MESSAGE_ID, messageId)
        val requestCode = (messageId * 2 + requestOffset).toInt()
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /** SmsManager de la carte SIM demandée, ou celui par défaut si aucune carte n'est précisée. */
    @Suppress("DEPRECATION")
    private fun smsManager(subscriptionId: Int?): SmsManager = when {
        subscriptionId != null && subscriptionId >= 0 ->
            SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            context.getSystemService(SmsManager::class.java)
        else -> SmsManager.getDefault()
    }
}
