package com.asphone.core.data.reminders

import com.asphone.core.model.ReminderStatus
import javax.inject.Inject
import javax.inject.Singleton

/** Exécute un rappel arrivé à échéance : affiche la notification si le rappel est toujours en attente. */
@Singleton
class ReminderRunner @Inject constructor(
    private val repository: ReminderRepository,
    private val notifier: ReminderNotifier,
) {

    suspend fun execute(id: Long) {
        val reminder = repository.get(id) ?: return
        if (reminder.status == ReminderStatus.PENDING) {
            notifier.show(reminder)
        }
    }
}
