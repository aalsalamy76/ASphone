package com.asphone.core.common

/** Utilitaires de normalisation des numéros de téléphone. */
object PhoneNumbers {

    /** Nombre minimal de chiffres pour comparer deux numéros par leur fin. */
    private const val SUFFIX_LENGTH = 9

    /**
     * Normalise un numéro : conserve le « + » initial et les chiffres, supprime
     * espaces, tirets, points et parenthèses. Le préfixe « 00 » devient « + ».
     */
    fun normalize(raw: String): String {
        val trimmed = raw.trim()
        val hasPlus = trimmed.startsWith("+")
        val digits = trimmed.filter { it.isDigit() }
        return when {
            hasPlus -> "+$digits"
            digits.startsWith("00") && digits.length > 2 -> "+${digits.substring(2)}"
            else -> digits
        }
    }

    /** Vrai si le numéro normalisé contient au moins trois chiffres (numéros courts inclus). */
    fun isPlausible(raw: String): Boolean = normalize(raw).count { it.isDigit() } >= 3

    /**
     * Compare deux numéros. Si les deux ont au moins neuf chiffres, seuls les neuf derniers
     * sont comparés (contourne les différences d'indicatif national).
     */
    fun sameNumber(first: String, second: String): Boolean {
        val a = normalize(first).filter { it.isDigit() }
        val b = normalize(second).filter { it.isDigit() }
        if (a.isEmpty() || b.isEmpty()) return false
        if (a.length >= SUFFIX_LENGTH && b.length >= SUFFIX_LENGTH) {
            return a.takeLast(SUFFIX_LENGTH) == b.takeLast(SUFFIX_LENGTH)
        }
        return a == b
    }

    /** Clé de regroupement stable pour un numéro (utilisée par la détection de doublons). */
    fun key(raw: String): String {
        val digits = normalize(raw).filter { it.isDigit() }
        return if (digits.length >= SUFFIX_LENGTH) digits.takeLast(SUFFIX_LENGTH) else digits
    }
}
