package com.asphone.core.common

/** Contact minimal utilisé pour la détection de doublons. */
data class ContactCandidate(
    val id: Long,
    val displayName: String,
    val phones: List<String>,
)

/** Groupe de contacts probablement identiques, avec la raison de la détection. */
data class DuplicateGroup(
    val contactIds: List<Long>,
    val reason: DuplicateReason,
)

enum class DuplicateReason { SAME_PHONE, SAME_NAME }

/**
 * Détecte les doublons par numéro commun ou par nom identique (sans casse ni espaces superflus).
 * Ne fusionne jamais rien : il ne fait que proposer des groupes à l'utilisateur.
 */
object DuplicateDetector {

    fun find(contacts: List<ContactCandidate>): List<DuplicateGroup> {
        val groups = mutableListOf<DuplicateGroup>()

        val byPhone = contacts
            .flatMap { contact ->
                contact.phones
                    .filter(PhoneNumbers::isPlausible)
                    .map { PhoneNumbers.key(it) to contact.id }
            }
            .groupBy(keySelector = { it.first }, valueTransform = { it.second })
            .mapValues { (_, ids) -> ids.distinct() }
            .filterValues { it.size > 1 }
        byPhone.values.forEach { ids ->
            groups += DuplicateGroup(ids, DuplicateReason.SAME_PHONE)
        }

        val byName = contacts
            .filter { it.displayName.isNotBlank() }
            .groupBy { normalizeName(it.displayName) }
            .filterValues { it.size > 1 }
        byName.values.forEach { members ->
            groups += DuplicateGroup(members.map { it.id }, DuplicateReason.SAME_NAME)
        }

        return groups
    }

    private fun normalizeName(name: String): String =
        name.trim().lowercase().split(Regex("\\s+")).joinToString(" ")
}
