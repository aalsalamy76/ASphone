package com.asphone.core.common

/**
 * Recherche T9 : chaque lettre correspond à une touche du clavier téléphonique.
 * Exemple : « sam » -> « 726 ».
 */
object T9 {

    private val letterToDigit: Map<Char, Char> = buildMap {
        mapOf(
            '2' to "abc",
            '3' to "def",
            '4' to "ghi",
            '5' to "jkl",
            '6' to "mno",
            '7' to "pqrs",
            '8' to "tuv",
            '9' to "wxyz",
        ).forEach { (digit, letters) ->
            letters.forEach { letter -> put(letter, digit) }
        }
    }

    /** Convertit un texte en suite de chiffres T9 ; les espaces sont conservés comme séparateurs. */
    fun toDigits(text: String): String = buildString {
        for (raw in text.lowercase()) {
            when {
                raw == ' ' -> append(' ')
                raw in '0'..'9' -> append(raw)
                else -> letterToDigit[normalizeAccent(raw)]?.let { digit -> append(digit) }
            }
        }
    }

    /**
     * Vrai si la requête (chiffres saisis sur le clavier) correspond au début d'un mot
     * du texte candidat, ou au début du texte entier.
     */
    fun matches(query: String, candidate: String): Boolean {
        val cleanQuery = query.filter { it in '2'..'9' }
        if (cleanQuery.isEmpty()) return false
        val candidateDigits = toDigits(candidate)
        if (candidateDigits.startsWith(cleanQuery)) return true
        return candidateDigits
            .split(' ')
            .any { word -> word.startsWith(cleanQuery) }
    }

    private fun normalizeAccent(c: Char): Char = when (c) {
        'à', 'á', 'â', 'ä' -> 'a'
        'è', 'é', 'ê', 'ë' -> 'e'
        'ì', 'í', 'î', 'ï' -> 'i'
        'ò', 'ó', 'ô', 'ö' -> 'o'
        'ù', 'ú', 'û', 'ü' -> 'u'
        'ç' -> 'c'
        'ñ' -> 'n'
        else -> c
    }
}
