package com.asphone.core.common

/** Jeu de caractères GSM 03.38 (table de base, 128 entrées dont ESC à l'indice 0x1B). */
private const val GSM_BASIC =
    "@£\$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞ\u001BÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?" +
        "¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà"

/** Caractères de la table étendue : chacun occupe deux septets (précédé de ESC). */
private const val GSM_EXTENDED = "^{}\\[~]|€\u000C"

private val basicSet: Set<Char> = GSM_BASIC.toSet()
private val extendedSet: Set<Char> = GSM_EXTENDED.toSet()

enum class SmsEncoding { GSM_7, UCS_2 }

/**
 * Résultat de l'analyse d'un SMS.
 * @property units septets (GSM-7) ou unités UTF-16 (UCS-2) utilisés.
 * @property segments nombre de SMS facturés.
 * @property remainingInSegment caractères restants avant l'ajout d'un segment.
 */
data class SmsSegmentInfo(
    val encoding: SmsEncoding,
    val units: Int,
    val segments: Int,
    val remainingInSegment: Int,
)

object Gsm7 {

    /** Vrai si tous les caractères sont représentables en GSM-7 (table de base ou étendue). */
    fun isGsm7(text: String): Boolean = text.all { it in basicSet || it in extendedSet }

    /** Nombre de septets GSM-7 nécessaires ; les caractères étendus comptent pour deux. */
    fun septetCount(text: String): Int = text.fold(0) { total, char ->
        total + if (char in extendedSet) 2 else 1
    }

    /** Analyse un texte : encodage, nombre de segments et caractères restants. */
    fun analyze(text: String): SmsSegmentInfo {
        return if (isGsm7(text)) {
            val septets = septetCount(text)
            analyzeUnits(SmsEncoding.GSM_7, septets, singleLimit = 160, multipartLimit = 153)
        } else {
            analyzeUnits(SmsEncoding.UCS_2, text.length, singleLimit = 70, multipartLimit = 67)
        }
    }

    private fun analyzeUnits(
        encoding: SmsEncoding,
        units: Int,
        singleLimit: Int,
        multipartLimit: Int,
    ): SmsSegmentInfo {
        if (units == 0) {
            return SmsSegmentInfo(encoding, 0, 0, singleLimit)
        }
        if (units <= singleLimit) {
            return SmsSegmentInfo(encoding, units, 1, singleLimit - units)
        }
        val segments = (units + multipartLimit - 1) / multipartLimit
        val remaining = segments * multipartLimit - units
        return SmsSegmentInfo(encoding, units, segments, remaining)
    }
}
