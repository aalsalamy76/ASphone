package com.asphone.core.common

/** Informations du projet, affichées dans l'écran « À propos » et la documentation. */
object ProjectInfo {
    const val APP_NAME = "A.Sphone"
    const val PACKAGE_NAME = "com.asphone.app"
    const val DEVELOPER_NAME = "Abdullah AL-SALAMY"

    /** Adresse exacte du profil du développeur : ne jamais la modifier ni la raccourcir. */
    const val LINKEDIN_URL = "https://www.linkedin.com/in/abdullah-a-2982451a6"
}
