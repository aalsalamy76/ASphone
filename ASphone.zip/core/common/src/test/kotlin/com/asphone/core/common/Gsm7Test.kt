package com.asphone.core.common

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class Gsm7Test {

    @Test
    fun `reconnaît un texte GSM-7 simple`() {
        assertTrue(Gsm7.isGsm7("Bonjour, à demain !"))
        assertFalse(Gsm7.isGsm7("ça va"))
    }

    @Test
    fun `un caractère étendu compte pour deux septets`() {
        assertEquals(2, Gsm7.septetCount("€"))
        assertEquals(4, Gsm7.septetCount("a€b"))
    }

    @Test
    fun `un emoji fait passer le message en UCS-2`() {
        assertFalse(Gsm7.isGsm7("Merci 😀"))
        assertEquals(SmsEncoding.UCS_2, Gsm7.analyze("Merci 😀").encoding)
    }

    @Test
    fun `160 septets tiennent en un seul segment`() {
        val info = Gsm7.analyze("a".repeat(160))
        assertEquals(SmsEncoding.GSM_7, info.encoding)
        assertEquals(1, info.segments)
        assertEquals(0, info.remainingInSegment)
    }

    @Test
    fun `161 septets donnent deux segments de 153`() {
        val info = Gsm7.analyze("a".repeat(161))
        assertEquals(2, info.segments)
        assertEquals(306 - 161, info.remainingInSegment)
    }

    @Test
    fun `70 caractères UCS-2 tiennent en un segment`() {
        val info = Gsm7.analyze("é€😀".repeat(1).padEnd(70, 'é'))
        assertEquals(SmsEncoding.UCS_2, info.encoding)
        assertEquals(1, info.segments)
    }

    @Test
    fun `texte vide`() {
        val info = Gsm7.analyze("")
        assertEquals(0, info.segments)
        assertEquals(160, info.remainingInSegment)
    }
}
