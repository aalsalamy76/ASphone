package com.asphone.core.common

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class PhoneNumbersTest {

    @Test
    fun `supprime les séparateurs et conserve le plus initial`() {
        assertEquals("+33612345678", PhoneNumbers.normalize("+33 (0)6 12-34.56.78".replace("(0)", "")))
    }

    @Test
    fun `convertit le préfixe 00 en plus`() {
        assertEquals("+33612345678", PhoneNumbers.normalize("0033 6 12 34 56 78"))
    }

    @Test
    fun `compare les neuf derniers chiffres pour les numéros longs`() {
        assertTrue(PhoneNumbers.sameNumber("+33612345678", "0612345678"))
        assertFalse(PhoneNumbers.sameNumber("0612345678", "0612345679"))
    }

    @Test
    fun `rejette les chaînes sans chiffres`() {
        assertFalse(PhoneNumbers.isPlausible("abc"))
        assertTrue(PhoneNumbers.isPlausible("112"))
    }
}
