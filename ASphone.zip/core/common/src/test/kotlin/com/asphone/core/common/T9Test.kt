package com.asphone.core.common

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class T9Test {

    @Test
    fun `convertit les lettres en chiffres du clavier`() {
        assertEquals("726", T9.toDigits("sam"))
        assertEquals("2662", T9.toDigits("Anna"))
    }

    @Test
    fun `ignore les accents pour la correspondance`() {
        assertEquals("43", T9.toDigits("hé"))
    }

    @Test
    fun `correspond au début du nom complet`() {
        assertTrue(T9.matches("726", "Sam Dupont"))
    }

    @Test
    fun `correspond au début d'un mot du nom`() {
        assertTrue(T9.matches("2662", "Jean Anna"))
    }

    @Test
    fun `ne correspond pas quand aucun mot ne commence par la requête`() {
        assertFalse(T9.matches("999", "Sam Dupont"))
    }

    @Test
    fun `une requête vide ne correspond à rien`() {
        assertFalse(T9.matches("", "Sam"))
        assertFalse(T9.matches("1", "Sam"))
    }
}
