package com.asphone.core.common

import kotlin.test.Test
import kotlin.test.assertEquals

class ProjectInfoTest {

    @Test
    fun `l'URL LinkedIn du développeur est exactement celle exigée`() {
        assertEquals("https://www.linkedin.com/in/abdullah-a-2982451a6", ProjectInfo.LINKEDIN_URL)
    }

    @Test
    fun `le nom du développeur et du package sont correctement renseignés`() {
        assertEquals("Abdullah AL-SALAMY", ProjectInfo.DEVELOPER_NAME)
        assertEquals("com.asphone.app", ProjectInfo.PACKAGE_NAME)
    }
}
