package com.asphone.core.common

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class DuplicateDetectorTest {

    @Test
    fun `regroupe deux contacts ayant le même numéro`() {
        val groups = DuplicateDetector.find(
            listOf(
                ContactCandidate(1, "Sam", listOf("+33 6 12 34 56 78")),
                ContactCandidate(2, "Samuel", listOf("0612345678")),
                ContactCandidate(3, "Anna", listOf("0700000000")),
            ),
        )
        val phone = groups.single { it.reason == DuplicateReason.SAME_PHONE }
        assertEquals(listOf(1L, 2L), phone.contactIds.sorted())
    }

    @Test
    fun `regroupe deux contacts au nom identique sans tenir compte de la casse`() {
        val groups = DuplicateDetector.find(
            listOf(
                ContactCandidate(1, "Marie  Curie", emptyList()),
                ContactCandidate(2, "marie curie", emptyList()),
            ),
        )
        assertTrue(groups.any { it.reason == DuplicateReason.SAME_NAME && it.contactIds.size == 2 })
    }

    @Test
    fun `ne propose aucun groupe pour des contacts distincts`() {
        val groups = DuplicateDetector.find(
            listOf(
                ContactCandidate(1, "Sam", listOf("0611111111")),
                ContactCandidate(2, "Anna", listOf("0622222222")),
            ),
        )
        assertTrue(groups.isEmpty())
    }
}
