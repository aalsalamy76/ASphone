package com.asphone.core.model

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class RecurrencesTest {

    private val paris = ZoneId.of("Europe/Paris")

    private fun at(date: String, time: String): ZonedDateTime =
        LocalDate.parse(date).atTime(LocalTime.parse(time)).atZone(paris)

    @Test
    fun `une occurrence unique n'a pas de suivante`() {
        val anchor = at("2027-01-10", "09:00")
        assertNull(Recurrences.next(anchor, anchor, Recurrence(RecurrenceType.ONCE)))
    }

    @Test
    fun `quotidien conserve l'heure locale à travers le passage à l'heure d'été`() {
        val anchor = at("2027-03-26", "09:00")
        val next = Recurrences.next(anchor, anchor, Recurrence(RecurrenceType.DAILY))
        assertEquals(at("2027-03-27", "09:00"), next)
        val afterDst = Recurrences.next(anchor, next!!, Recurrence(RecurrenceType.DAILY))
        assertEquals(LocalTime.of(9, 0), afterDst!!.toLocalTime())
    }

    @Test
    fun `mensuel le 31 janvier ne dérive pas après février`() {
        val anchor = at("2027-01-31", "08:00")
        val feb = Recurrences.next(anchor, anchor, Recurrence(RecurrenceType.MONTHLY))
        assertEquals(at("2027-02-28", "08:00"), feb)
        val mar = Recurrences.next(anchor, feb!!, Recurrence(RecurrenceType.MONTHLY))
        assertEquals(at("2027-03-31", "08:00"), mar)
    }

    @Test
    fun `jours ouvrés saute le week-end`() {
        // 2027-01-08 est un vendredi.
        val anchor = at("2027-01-08", "07:30")
        val next = Recurrences.next(anchor, anchor, Recurrence(RecurrenceType.WEEKDAYS))
        assertEquals(DayOfWeek.MONDAY, next!!.dayOfWeek)
        assertEquals(at("2027-01-11", "07:30"), next)
    }

    @Test
    fun `jours personnalisés choisit le prochain jour autorisé`() {
        val anchor = at("2027-01-04", "12:00") // lundi
        val rule = Recurrence(RecurrenceType.CUSTOM_DAYS, daysOfWeek = setOf(DayOfWeek.WEDNESDAY))
        assertEquals(at("2027-01-06", "12:00"), Recurrences.next(anchor, anchor, rule))
    }

    @Test
    fun `jours personnalisés sans jour renvoie null`() {
        val anchor = at("2027-01-04", "12:00")
        assertNull(Recurrences.next(anchor, anchor, Recurrence(RecurrenceType.CUSTOM_DAYS)))
    }

    @Test
    fun `périodicité personnalisée utilise l'intervalle en jours`() {
        val anchor = at("2027-01-01", "10:00")
        val rule = Recurrence(RecurrenceType.CUSTOM_INTERVAL, intervalDays = 3)
        assertEquals(at("2027-01-04", "10:00"), Recurrences.next(anchor, anchor, rule))
    }

    @Test
    fun `anniversaire avance d'une année`() {
        val anchor = at("1990-06-15", "00:00")
        val next = Recurrences.next(anchor, anchor, Recurrence(RecurrenceType.ANNIVERSARY))
        assertEquals(at("1991-06-15", "00:00"), next)
    }
}
