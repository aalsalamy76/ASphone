package com.asphone.core.model

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ReminderTimingTest {

    private val paris = ZoneId.of("Europe/Paris")

    @Test
    fun `l'après-midi d'un matin est le jour même à 14 h`() {
        val now = ZonedDateTime.of(2027, 1, 10, 9, 0, 0, 0, paris)
        val due = ReminderTiming.resolvePreset(now, ReminderPreset.THIS_AFTERNOON)
        assertEquals(LocalTime.of(14, 0), due.toLocalTime())
        assertEquals(10, due.dayOfMonth)
    }

    @Test
    fun `l'après-midi passé est reporté au lendemain`() {
        val now = ZonedDateTime.of(2027, 1, 10, 15, 0, 0, 0, paris)
        val due = ReminderTiming.resolvePreset(now, ReminderPreset.THIS_AFTERNOON)
        assertEquals(11, due.dayOfMonth)
    }

    @Test
    fun `demain est fixé à 9 h`() {
        val now = ZonedDateTime.of(2027, 1, 10, 22, 0, 0, 0, paris)
        val due = ReminderTiming.resolvePreset(now, ReminderPreset.TOMORROW)
        assertEquals(ZonedDateTime.of(2027, 1, 11, 9, 0, 0, 0, paris), due)
    }

    @Test
    fun `report de dix minutes depuis l'échéance`() {
        val due = ZonedDateTime.of(2027, 1, 10, 9, 0, 0, 0, paris).toInstant().toEpochMilli()
        val snoozed = ReminderTiming.snooze(due, "Europe/Paris", SnoozeOption.TEN_MINUTES, due)
        assertEquals(due + 10 * 60_000L, snoozed)
    }

    @Test
    fun `un report part de maintenant si l'échéance est dépassée`() {
        val due = Instant.parse("2027-01-10T08:00:00Z").toEpochMilli()
        val now = Instant.parse("2027-01-10T10:00:00Z").toEpochMilli()
        val snoozed = ReminderTiming.snooze(due, "Europe/Paris", SnoozeOption.ONE_HOUR, now)
        assertTrue(snoozed > now)
        assertEquals(now + 3_600_000L, snoozed)
    }
}
