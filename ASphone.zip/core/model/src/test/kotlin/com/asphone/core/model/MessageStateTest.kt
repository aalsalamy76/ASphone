package com.asphone.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertTrue

class MessageStateTest {

    @Test
    fun `un brouillon peut passer en file d'attente puis en envoi`() {
        val queued = MessageStateMachine.transition(MessageState.DRAFT, MessageState.QUEUED)
        assertEquals(TransitionResult.Applied(MessageState.QUEUED), queued)
        val sending = MessageStateMachine.transition(MessageState.QUEUED, MessageState.SENDING)
        assertEquals(TransitionResult.Applied(MessageState.SENDING), sending)
    }

    @Test
    fun `on ne peut pas passer directement de brouillon à envoyé`() {
        val result = MessageStateMachine.transition(MessageState.DRAFT, MessageState.SENT)
        assertIs<TransitionResult.Rejected>(result)
    }

    @Test
    fun `un message annulé ou expiré ne change plus d'état`() {
        assertTrue(MessageState.CANCELLED.allowedTargets().isEmpty())
        assertTrue(MessageState.EXPIRED.allowedTargets().isEmpty())
    }

    @Test
    fun `un échec peut être relancé`() {
        val retry = MessageStateMachine.transition(MessageState.FAILED, MessageState.QUEUED)
        assertEquals(TransitionResult.Applied(MessageState.QUEUED), retry)
    }

    @Test
    fun `seuls les états après envoi confirmé sont considérés comme partis`() {
        assertFalse(MessageState.SENDING.hasLeftDevice())
        assertFalse(MessageState.QUEUED.hasLeftDevice())
        assertTrue(MessageState.SENT.hasLeftDevice())
        assertTrue(MessageState.DELIVERED.hasLeftDevice())
    }
}
