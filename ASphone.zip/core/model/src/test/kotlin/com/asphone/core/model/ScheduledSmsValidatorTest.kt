package com.asphone.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ScheduledSmsValidatorTest {

    private val now = 1_000_000L
    private val future = now + 60_000L

    @Test
    fun `une programmation valide ne produit aucune erreur`() {
        val errors = ScheduledSmsValidator.validate(listOf("0612345678"), "Bonjour", future, now)
        assertTrue(errors.isEmpty())
    }

    @Test
    fun `détecte l'absence de destinataire`() {
        val errors = ScheduledSmsValidator.validate(emptyList(), "Bonjour", future, now)
        assertEquals(listOf(ScheduleError.NO_RECIPIENT), errors)
    }

    @Test
    fun `détecte un numéro invalide`() {
        val errors = ScheduledSmsValidator.validate(listOf("abc"), "Bonjour", future, now)
        assertEquals(listOf(ScheduleError.INVALID_RECIPIENT), errors)
    }

    @Test
    fun `détecte un message vide ou composé d'espaces`() {
        val errors = ScheduledSmsValidator.validate(listOf("0612345678"), "   ", future, now)
        assertEquals(listOf(ScheduleError.EMPTY_BODY), errors)
    }

    @Test
    fun `refuse une date passée`() {
        val errors = ScheduledSmsValidator.validate(listOf("0612345678"), "Bonjour", now - 1, now)
        assertEquals(listOf(ScheduleError.DATE_IN_PAST), errors)
    }
}
