package com.asphone.core.model

import com.asphone.core.common.PhoneNumbers

enum class ScheduleError {
    NO_RECIPIENT,
    INVALID_RECIPIENT,
    EMPTY_BODY,
    DATE_IN_PAST,
}

/** Contrôles effectués avant d'enregistrer un SMS programmé. */
object ScheduledSmsValidator {

    fun validate(
        recipients: List<String>,
        body: String,
        scheduledAtMillis: Long,
        nowMillis: Long,
    ): List<ScheduleError> {
        val errors = mutableListOf<ScheduleError>()
        if (recipients.isEmpty()) {
            errors += ScheduleError.NO_RECIPIENT
        } else if (recipients.any { !PhoneNumbers.isPlausible(it) }) {
            errors += ScheduleError.INVALID_RECIPIENT
        }
        if (body.isBlank()) {
            errors += ScheduleError.EMPTY_BODY
        }
        if (scheduledAtMillis <= nowMillis) {
            errors += ScheduleError.DATE_IN_PAST
        }
        return errors
    }
}
