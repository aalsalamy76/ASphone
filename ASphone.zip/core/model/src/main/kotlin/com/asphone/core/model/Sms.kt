package com.asphone.core.model

/** Sens d'un SMS par rapport à l'utilisateur. */
enum class SmsDirection { INBOX, SENT, DRAFT, OUTBOX }

/** Message SMS ou MMS (texte seul pour l'instant). */
data class SmsMessage(
    val id: Long,
    val threadId: Long,
    val address: String,
    val body: String,
    val timestampMillis: Long,
    val direction: SmsDirection,
    val state: MessageState,
    val read: Boolean,
    val subscriptionId: Int?,
)

/** Une conversation : un fil de messages avec un correspondant. */
data class Conversation(
    val threadId: Long,
    val address: String,
    val displayName: String?,
    val lastMessagePreview: String,
    val lastTimestampMillis: Long,
    val unreadCount: Int,
    val pinned: Boolean,
)
