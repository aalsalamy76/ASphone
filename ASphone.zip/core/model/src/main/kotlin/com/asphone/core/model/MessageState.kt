package com.asphone.core.model

/**
 * États d'un message. Un message n'est affiché « Envoyé » que lorsque l'envoi réel
 * a été confirmé par le système (état [SENT]), jamais avant.
 */
enum class MessageState {
    DRAFT,
    QUEUED,
    SENDING,
    SENT,
    DELIVERED,
    RECEIVED,
    READ,
    FAILED,
    CANCELLED,
    EXPIRED;

    /** Transitions autorisées depuis cet état. */
    fun allowedTargets(): Set<MessageState> = when (this) {
        DRAFT -> setOf(QUEUED, CANCELLED)
        QUEUED -> setOf(SENDING, CANCELLED, FAILED, EXPIRED)
        SENDING -> setOf(SENT, FAILED)
        SENT -> setOf(DELIVERED, FAILED, EXPIRED)
        FAILED -> setOf(QUEUED)
        DELIVERED -> setOf(READ)
        RECEIVED -> setOf(READ)
        READ, CANCELLED, EXPIRED -> emptySet()
    }

    /** Vrai si le message a effectivement quitté le téléphone. */
    fun hasLeftDevice(): Boolean = this == SENT || this == DELIVERED || this == READ
}

sealed interface TransitionResult {
    data class Applied(val state: MessageState) : TransitionResult
    data class Rejected(val from: MessageState, val to: MessageState) : TransitionResult
}

object MessageStateMachine {

    fun transition(from: MessageState, to: MessageState): TransitionResult =
        if (to in from.allowedTargets()) {
            TransitionResult.Applied(to)
        } else {
            TransitionResult.Rejected(from, to)
        }
}
