package com.asphone.core.model

import java.time.DayOfWeek
import java.time.ZonedDateTime

enum class RecurrenceType {
    ONCE,
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY,
    WEEKDAYS,
    CUSTOM_DAYS,
    ANNIVERSARY,
    CUSTOM_INTERVAL,
}

/**
 * Règle de récurrence. [intervalDays] ne sert qu'à [RecurrenceType.CUSTOM_INTERVAL],
 * [daysOfWeek] uniquement à [RecurrenceType.CUSTOM_DAYS].
 */
data class Recurrence(
    val type: RecurrenceType = RecurrenceType.ONCE,
    val intervalDays: Int = 1,
    val daysOfWeek: Set<DayOfWeek> = emptySet(),
)

enum class ScheduledStatus { ACTIVE, SUSPENDED, COMPLETED, CANCELLED, FAILED }

/**
 * SMS programmé. [firstRunMillis] est l'instant de la première émission ; l'heure locale
 * de [zoneId] est conservée d'une occurrence à l'autre (heure d'été / d'hiver).
 */
data class ScheduledSms(
    val id: Long,
    val recipients: List<String>,
    val body: String,
    val firstRunMillis: Long,
    val zoneId: String,
    val subscriptionId: Int?,
    val recurrence: Recurrence,
    val status: ScheduledStatus,
    val nextRunMillis: Long,
)

object Recurrences {

    private const val MAX_STEPS = 10_000L
    private val WEEKEND = setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)

    /**
     * Prochaine occurrence strictement postérieure à [current], calculée à partir de [anchor]
     * (première occurrence) pour éviter la dérive (ex. le 31 janvier -> 28 février -> 28 mars).
     * Renvoie null pour une occurrence unique ou une règle sans jour valide.
     */
    fun next(anchor: ZonedDateTime, current: ZonedDateTime, rule: Recurrence): ZonedDateTime? {
        return when (rule.type) {
            RecurrenceType.ONCE -> null
            RecurrenceType.DAILY -> stepFromAnchor(anchor, current) { a, k -> a.plusDays(k) }
            RecurrenceType.WEEKLY -> stepFromAnchor(anchor, current) { a, k -> a.plusWeeks(k) }
            RecurrenceType.MONTHLY -> stepFromAnchor(anchor, current) { a, k -> a.plusMonths(k) }
            RecurrenceType.YEARLY, RecurrenceType.ANNIVERSARY ->
                stepFromAnchor(anchor, current) { a, k -> a.plusYears(k) }
            RecurrenceType.CUSTOM_INTERVAL -> {
                val step = rule.intervalDays.coerceAtLeast(1).toLong()
                stepFromAnchor(anchor, current) { a, k -> a.plusDays(k * step) }
            }
            RecurrenceType.WEEKDAYS -> nextMatchingDay(anchor, current) { it !in WEEKEND }
            RecurrenceType.CUSTOM_DAYS -> {
                if (rule.daysOfWeek.isEmpty()) {
                    null
                } else {
                    nextMatchingDay(anchor, current) { it in rule.daysOfWeek }
                }
            }
        }
    }

    private fun stepFromAnchor(
        anchor: ZonedDateTime,
        current: ZonedDateTime,
        stepper: (ZonedDateTime, Long) -> ZonedDateTime,
    ): ZonedDateTime? {
        for (k in 1..MAX_STEPS) {
            val candidate = stepper(anchor, k)
            if (candidate.isAfter(current)) return candidate
        }
        return null
    }

    private fun nextMatchingDay(
        anchor: ZonedDateTime,
        current: ZonedDateTime,
        accept: (DayOfWeek) -> Boolean,
    ): ZonedDateTime? {
        val time = anchor.toLocalTime()
        var day = current.toLocalDate().plusDays(1)
        for (i in 0 until MAX_STEPS) {
            if (accept(day.dayOfWeek)) {
                val candidate = day.atTime(time).atZone(anchor.zone)
                if (candidate.isAfter(current)) return candidate
            }
            day = day.plusDays(1)
        }
        return null
    }
}
