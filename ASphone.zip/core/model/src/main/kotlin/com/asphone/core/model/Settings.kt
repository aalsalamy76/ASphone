package com.asphone.core.model

/** Mode d'affichage choisi par l'utilisateur. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Préférences globales de l'application. */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val amoled: Boolean = false,
    val dynamicColor: Boolean = true,
)
