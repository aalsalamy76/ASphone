package com.asphone.core.model

/** Type d'une entrée de l'historique d'appels. */
enum class CallType {
    INCOMING,
    OUTGOING,
    MISSED,
    REJECTED,
    BLOCKED,
    VOICEMAIL,
}

/** Entrée de l'historique d'appels. */
data class CallLogEntry(
    val id: Long,
    val number: String,
    val contactName: String?,
    val timestampMillis: Long,
    val durationSeconds: Long,
    val type: CallType,
    val simSlot: Int?,
)

/** Résumé d'un contact affiché dans les listes. */
data class ContactSummary(
    val id: Long,
    val displayName: String,
    val primaryPhone: String?,
    val starred: Boolean,
)
