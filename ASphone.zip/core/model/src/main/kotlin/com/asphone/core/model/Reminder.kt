package com.asphone.core.model

import java.time.ZoneId
import java.time.ZonedDateTime

enum class ReminderKind { CALL, MESSAGE }

enum class ReminderStatus { PENDING, DONE, CANCELLED }

/**
 * Rappel. Un rappel ne compose jamais un numéro et n'envoie jamais de message
 * automatiquement : il ne fait que proposer des actions à l'utilisateur.
 */
data class Reminder(
    val id: Long,
    val kind: ReminderKind,
    val number: String,
    val contactName: String?,
    val note: String,
    val dueAtMillis: Long,
    val zoneId: String,
    val status: ReminderStatus,
    val draftText: String?,
)

/** Raccourcis proposés à la création d'un rappel. */
enum class ReminderPreset {
    IN_15_MINUTES,
    IN_30_MINUTES,
    IN_ONE_HOUR,
    THIS_AFTERNOON,
    TOMORROW,
}

/** Actions de report proposées dans la notification. */
enum class SnoozeOption {
    TEN_MINUTES,
    ONE_HOUR,
    TOMORROW,
}

object ReminderTiming {

    private const val AFTERNOON_HOUR = 14
    private const val MORNING_HOUR = 9

    /** Date d'échéance correspondant à un raccourci, à partir de l'instant [now]. */
    fun resolvePreset(now: ZonedDateTime, preset: ReminderPreset): ZonedDateTime = when (preset) {
        ReminderPreset.IN_15_MINUTES -> now.plusMinutes(15)
        ReminderPreset.IN_30_MINUTES -> now.plusMinutes(30)
        ReminderPreset.IN_ONE_HOUR -> now.plusHours(1)
        ReminderPreset.THIS_AFTERNOON -> {
            val today = now.withHour(AFTERNOON_HOUR).withMinute(0).withSecond(0).withNano(0)
            if (today.isAfter(now)) today else today.plusDays(1)
        }
        ReminderPreset.TOMORROW -> now.plusDays(1)
            .withHour(MORNING_HOUR).withMinute(0).withSecond(0).withNano(0)
    }

    /** Nouvelle échéance après un report, dans le fuseau du rappel. */
    fun snooze(dueAtMillis: Long, zoneId: String, option: SnoozeOption, nowMillis: Long): Long {
        val zone = ZoneId.of(zoneId)
        val base = ZonedDateTime.ofInstant(
            java.time.Instant.ofEpochMilli(maxOf(dueAtMillis, nowMillis)),
            zone,
        )
        val target = when (option) {
            SnoozeOption.TEN_MINUTES -> base.plusMinutes(10)
            SnoozeOption.ONE_HOUR -> base.plusHours(1)
            SnoozeOption.TOMORROW -> base.plusDays(1)
        }
        return target.toInstant().toEpochMilli()
    }
}
