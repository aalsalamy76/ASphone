package com.asphone.core.designsystem.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Palette officielle A.Sphone.
val NightBlue = Color(0xFF0B1220)
val BluePrimary = Color(0xFF2563EB)
val SkyBlue = Color(0xFF38BDF8)
val Cyan = Color(0xFF06B6D4)
val Violet = Color(0xFF7C3AED)
val Green = Color(0xFF10B981)
val Orange = Color(0xFFF59E0B)
val Red = Color(0xFFEF4444)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val DarkBackground = Color(0xFF070B14)
val DarkSurface = Color(0xFF111827)
val LightText = Color(0xFF0F172A)
val DarkText = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF64748B)

// Coins arrondis de 16 à 24 dp.
val ASphoneShapes = Shapes(
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(24.dp),
)

// Polices système : Manrope et Inter ne sont pas embarquées (licences à vérifier, voir README).
val ASphoneTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 28.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp),
)
