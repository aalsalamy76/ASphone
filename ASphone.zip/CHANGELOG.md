# Journal des modifications

Le format suit [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/).

## [Non publié]

### Ajouté

- Téléphone : clavier, journal des appels récents, écran d'appel entrant et en cours (service `InCallService`), blocage de numéros avec confirmation.
- Contacts : liste, recherche par nom, numéro ou T9, création et suppression, proposition de doublons sans fusion automatique.
- Messages : conversations, fil de discussion, envoi et réception de SMS, compteur GSM-7 et UCS-2, états de message confirmés par le système.
- Programmation de SMS avec récurrences (une fois, quotidienne, jours ouvrés, hebdomadaire, jours choisis, tous les N jours, mensuelle, annuelle, anniversaire).
- Rappels pour appeler ou écrire plus tard, avec report, achèvement et annulation. Aucune action automatique.
- Réglages : thème, mode AMOLED, couleurs dynamiques, six langues (dont l'arabe de droite à gauche), rôles par défaut, sauvegarde chiffrée (PBKDF2-HMAC-SHA256 et AES-256-GCM).
- Workflows GitHub Actions : CI, release signée (secrets requis), CodeQL, Dependabot.

### Statut

- Code complet, **non compilé** dans l'environnement de rédaction. Validation restante : `assembleDebug`, tests unitaires, lint, ktlint et detekt sur une machine connectée.
