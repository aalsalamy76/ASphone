package com.asphone.feature.messages

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.common.PhoneNumbers
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.ASphoneCard
import com.asphone.core.designsystem.components.EmptyState
import com.asphone.core.designsystem.components.PrimaryActionButton
import com.asphone.core.model.Conversation
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

/** Liste des conversations SMS. Affiche un avertissement si A.Sphone n'est pas l'application SMS par défaut. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationsScreen(
    onOpenThread: (threadId: Long, address: String) -> Unit,
    onOpenSchedule: () -> Unit,
    viewModel: ConversationsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showNew by remember { mutableStateOf(false) }

    val permissions = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { viewModel.reload() }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        viewModel.reload()
    }

    LaunchedEffect(Unit) {
        val missing = listOf(Manifest.permission.READ_SMS, Manifest.permission.READ_CONTACTS)
            .filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissions.launch(missing.toTypedArray()) else viewModel.reload()
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.messages_title)) },
                actions = {
                    IconButton(onClick = onOpenSchedule) {
                        Icon(Icons.Filled.Schedule, contentDescription = stringResource(R.string.schedule_title))
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showNew = true }) {
                Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.messages_new))
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
        ) {
            if (!state.smsRoleHeld) {
                ASphoneCard {
                    Text(
                        text = stringResource(R.string.messages_role_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = {
                        viewModel.smsRoleIntent()?.let { intent -> roleLauncher.launch(intent) }
                    }) {
                        Text(stringResource(R.string.messages_role_action))
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            when {
                state.permissionMissing -> ASphoneCard {
                    Text(
                        text = stringResource(R.string.messages_permission_missing),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(12.dp))
                    PrimaryActionButton(
                        text = stringResource(R.string.action_grant),
                        onClick = { permissions.launch(arrayOf(Manifest.permission.READ_SMS)) },
                    )
                }
                !state.loading && state.conversations.isEmpty() -> EmptyState(
                    icon = Icons.Filled.Sms,
                    title = stringResource(R.string.messages_empty),
                    message = stringResource(R.string.messages_empty_message),
                    modifier = Modifier.weight(1f),
                )
                else -> LazyColumn(modifier = Modifier.weight(1f)) {
                    items(state.conversations, key = { it.threadId }) { conversation ->
                        ConversationRow(
                            conversation = conversation,
                            onClick = { onOpenThread(conversation.threadId, conversation.address) },
                        )
                    }
                }
            }
        }
    }

    if (showNew) {
        NewMessageDialog(
            onDismiss = { showNew = false },
            onConfirm = { address ->
                showNew = false
                onOpenThread(-1L, address)
            },
        )
    }
}

@Composable
private fun ConversationRow(conversation: Conversation, onClick: () -> Unit) {
    val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(conversation.lastTimestampMillis))
    ListItem(
        headlineContent = {
            Text(
                text = conversation.displayName ?: conversation.address,
                fontWeight = if (conversation.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        },
        supportingContent = {
            Text(
                text = conversation.lastMessagePreview,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        },
        trailingContent = {
            Column(horizontalAlignment = Alignment.End) {
                Text(text = time, style = MaterialTheme.typography.labelSmall)
                if (conversation.unreadCount > 0) {
                    Badge { Text(conversation.unreadCount.toString()) }
                }
            }
        },
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
private fun NewMessageDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var address by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.messages_new)) },
        text = {
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text(stringResource(R.string.messages_recipient_hint)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(PhoneNumbers.normalize(address)) },
                enabled = PhoneNumbers.isPlausible(address),
            ) {
                Text(stringResource(R.string.action_continue))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}
