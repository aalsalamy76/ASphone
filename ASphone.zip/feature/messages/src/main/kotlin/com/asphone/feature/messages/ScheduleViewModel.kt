package com.asphone.feature.messages

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.common.Gsm7
import com.asphone.core.common.PhoneNumbers
import com.asphone.core.common.SmsSegmentInfo
import com.asphone.core.data.scheduling.ScheduleValidationException
import com.asphone.core.data.scheduling.ScheduledSmsRepository
import com.asphone.core.model.Recurrence
import com.asphone.core.model.RecurrenceType
import com.asphone.core.model.ScheduleError
import com.asphone.core.model.ScheduledSms
import com.asphone.core.model.ScheduledSmsValidator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import javax.inject.Inject

private const val DEFAULT_INTERVAL_DAYS = "2"

/** Problèmes de saisie affichés sous le formulaire. */
enum class ScheduleIssue {
    NO_RECIPIENT,
    INVALID_RECIPIENT,
    EMPTY_BODY,
    DATE_IN_PAST,
    MISSING_DATE,
    MISSING_TIME,
    INVALID_INTERVAL,
    NO_DAY,
}

data class ScheduleFormState(
    val recipients: String = "",
    val body: String = "",
    val date: LocalDate? = null,
    val time: LocalTime? = null,
    val recurrence: RecurrenceType = RecurrenceType.ONCE,
    val intervalDays: String = DEFAULT_INTERVAL_DAYS,
    val days: Set<DayOfWeek> = emptySet(),
    val issues: List<ScheduleIssue> = emptyList(),
    val analysis: SmsSegmentInfo = Gsm7.analyze(""),
)

data class ScheduleUiState(
    val form: ScheduleFormState = ScheduleFormState(),
    val schedules: List<ScheduledSms> = emptyList(),
    val saved: Boolean = false,
)

/**
 * Programmation de SMS : formulaire, validation et gestion des programmations existantes.
 * Rien n'est envoyé pendant la saisie ; l'envoi a lieu à l'échéance, via WorkManager.
 */
@HiltViewModel
class ScheduleViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: ScheduledSmsRepository,
) : ViewModel() {

    private val _form = MutableStateFlow(
        ScheduleFormState(
            recipients = savedStateHandle.get<String>(ARG_RECIPIENT).orEmpty(),
        ),
    )
    private val _saved = MutableStateFlow(false)

    val uiState: StateFlow<ScheduleUiState> = combine(_form, repository.observe(), _saved) { form, schedules, saved ->
        ScheduleUiState(form = form, schedules = schedules, saved = saved)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), ScheduleUiState())

    fun onRecipientsChange(value: String) = _form.update { it.copy(recipients = value) }

    fun onBodyChange(value: String) = _form.update { it.copy(body = value, analysis = Gsm7.analyze(value)) }

    fun onDateChange(date: LocalDate) = _form.update { it.copy(date = date) }

    fun onTimeChange(time: LocalTime) = _form.update { it.copy(time = time) }

    fun onRecurrenceChange(type: RecurrenceType) = _form.update { it.copy(recurrence = type) }

    fun onIntervalChange(value: String) = _form.update { it.copy(intervalDays = value.filter { c -> c.isDigit() }.take(3)) }

    fun onDayToggle(day: DayOfWeek) = _form.update {
        it.copy(days = if (day in it.days) it.days - day else it.days + day)
    }

    fun consumeSaved() {
        _saved.value = false
    }

    /** Valide le formulaire puis enregistre la programmation. Les erreurs restent affichées. */
    fun save() {
        val form = _form.value
        val issues = mutableListOf<ScheduleIssue>()
        val recipients = parseRecipients(form.recipients)
        val zone = ZoneId.systemDefault()

        val date = form.date
        val time = form.time
        if (date == null) issues += ScheduleIssue.MISSING_DATE
        if (time == null) issues += ScheduleIssue.MISSING_TIME

        val interval = form.intervalDays.toIntOrNull() ?: 0
        if (form.recurrence == RecurrenceType.CUSTOM_INTERVAL && interval < 1) {
            issues += ScheduleIssue.INVALID_INTERVAL
        }
        if (form.recurrence == RecurrenceType.CUSTOM_DAYS && form.days.isEmpty()) {
            issues += ScheduleIssue.NO_DAY
        }

        if (date != null && time != null) {
            val runAt = ZonedDateTime.of(date, time, zone).toInstant().toEpochMilli()
            val validation = ScheduledSmsValidator.validate(recipients, form.body, runAt, System.currentTimeMillis())
            issues += validation.map(::toIssue)

            if (issues.isEmpty()) {
                val recurrence = Recurrence(
                    type = form.recurrence,
                    intervalDays = interval.coerceAtLeast(1),
                    daysOfWeek = if (form.recurrence == RecurrenceType.CUSTOM_DAYS) form.days else emptySet(),
                )
                viewModelScope.launch {
                    try {
                        repository.create(
                            recipients = recipients,
                            body = form.body,
                            runAtMillis = runAt,
                            zoneId = zone.id,
                            subscriptionId = null,
                            recurrence = recurrence,
                        )
                        _form.update { ScheduleFormState(recipients = form.recipients) }
                        _saved.value = true
                    } catch (error: ScheduleValidationException) {
                        _form.update { it.copy(issues = error.errors.map(::toIssue)) }
                    }
                }
                return
            }
        }
        _form.update { it.copy(issues = issues.distinct()) }
    }

    fun setSuspended(id: Long, suspended: Boolean) {
        viewModelScope.launch { repository.setSuspended(id, suspended) }
    }

    fun cancel(id: Long) {
        viewModelScope.launch { repository.cancel(id) }
    }

    fun duplicate(id: Long) {
        viewModelScope.launch { repository.duplicate(id) }
    }

    private fun toIssue(error: ScheduleError): ScheduleIssue = when (error) {
        ScheduleError.NO_RECIPIENT -> ScheduleIssue.NO_RECIPIENT
        ScheduleError.INVALID_RECIPIENT -> ScheduleIssue.INVALID_RECIPIENT
        ScheduleError.EMPTY_BODY -> ScheduleIssue.EMPTY_BODY
        ScheduleError.DATE_IN_PAST -> ScheduleIssue.DATE_IN_PAST
    }

    companion object {
        const val ARG_RECIPIENT = "recipient"
        private const val STOP_TIMEOUT_MILLIS = 5_000L

        /** Découpe la saisie sur virgules, points-virgules ou retours à la ligne. */
        fun parseRecipients(raw: String): List<String> =
            raw.split(',', ';', '\n')
                .map { PhoneNumbers.normalize(it) }
                .filter { it.isNotBlank() }
    }
}
