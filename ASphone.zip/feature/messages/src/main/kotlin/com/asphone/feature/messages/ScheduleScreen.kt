package com.asphone.feature.messages

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.item
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.ASphoneCard
import com.asphone.core.designsystem.components.ConfirmDialog
import com.asphone.core.designsystem.components.PrimaryActionButton
import com.asphone.core.designsystem.components.SectionTitle
import com.asphone.core.model.RecurrenceType
import com.asphone.core.model.ScheduledSms
import com.asphone.core.model.ScheduledStatus
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.format.TextStyle
import java.util.Locale
import android.text.format.DateFormat as AndroidDateFormat

/** Programmation de SMS : formulaire, sélecteurs Material 3 et liste des envois prévus. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(
    onBack: () -> Unit,
    viewModel: ScheduleViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val form = state.form
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val savedMessage = stringResource(R.string.schedule_saved)
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    var pendingCancel by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(state.saved) {
        if (state.saved) {
            viewModel.consumeSaved()
            scope.launch { snackbarHostState.showSnackbar(savedMessage) }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.schedule_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                OutlinedTextField(
                    value = form.recipients,
                    onValueChange = viewModel::onRecipientsChange,
                    label = { Text(stringResource(R.string.schedule_recipients)) },
                    supportingText = { Text(stringResource(R.string.schedule_recipients_hint)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                OutlinedTextField(
                    value = form.body,
                    onValueChange = viewModel::onBodyChange,
                    label = { Text(stringResource(R.string.schedule_body)) },
                    supportingText = {
                        Text(stringResource(R.string.messages_counter, form.analysis.units, form.analysis.segments))
                    },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.weight(1f)) {
                        Text(form.date?.format(dateFormatter()) ?: stringResource(R.string.schedule_pick_date))
                    }
                    OutlinedButton(onClick = { showTimePicker = true }, modifier = Modifier.weight(1f)) {
                        Text(form.time?.format(timeFormatter()) ?: stringResource(R.string.schedule_pick_time))
                    }
                }
            }
            item {
                RecurrenceSelector(
                    selected = form.recurrence,
                    onSelect = viewModel::onRecurrenceChange,
                )
            }
            if (form.recurrence == RecurrenceType.CUSTOM_INTERVAL) {
                item {
                    OutlinedTextField(
                        value = form.intervalDays,
                        onValueChange = viewModel::onIntervalChange,
                        label = { Text(stringResource(R.string.schedule_interval_days)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            if (form.recurrence == RecurrenceType.CUSTOM_DAYS) {
                item {
                    DaySelector(selected = form.days, onToggle = viewModel::onDayToggle)
                }
            }
            if (form.issues.isNotEmpty()) {
                item {
                    Column {
                        form.issues.forEach { issue ->
                            Text(
                                text = stringResource(issueLabel(issue)),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
            item {
                Text(
                    text = stringResource(R.string.schedule_delay_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item {
                PrimaryActionButton(
                    text = stringResource(R.string.schedule_save),
                    onClick = viewModel::save,
                )
            }
            item {
                Spacer(Modifier.height(8.dp))
                SectionTitle(stringResource(R.string.schedule_list_title))
            }
            if (state.schedules.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.schedule_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(state.schedules, key = { it.id }) { schedule ->
                ScheduleCard(
                    schedule = schedule,
                    onToggleSuspended = { viewModel.setSuspended(schedule.id, suspended = schedule.status != ScheduledStatus.SUSPENDED) },
                    onDuplicate = { viewModel.duplicate(schedule.id) },
                    onCancel = { pendingCancel = schedule.id },
                )
            }
        }
    }

    if (showDatePicker) {
        ScheduleDatePicker(
            initial = form.date,
            onDismiss = { showDatePicker = false },
            onPicked = { date ->
                viewModel.onDateChange(date)
                showDatePicker = false
            },
        )
    }

    if (showTimePicker) {
        ScheduleTimePicker(
            initial = form.time,
            is24Hour = AndroidDateFormat.is24HourFormat(context),
            onDismiss = { showTimePicker = false },
            onPicked = { time ->
                viewModel.onTimeChange(time)
                showTimePicker = false
            },
        )
    }

    pendingCancel?.let { id ->
        ConfirmDialog(
            title = stringResource(R.string.schedule_cancel_title),
            message = stringResource(R.string.schedule_cancel_message),
            confirmLabel = stringResource(R.string.schedule_cancel),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                viewModel.cancel(id)
                pendingCancel = null
            },
            onDismiss = { pendingCancel = null },
        )
    }
}

@Composable
private fun ScheduleCard(
    schedule: ScheduledSms,
    onToggleSuspended: () -> Unit,
    onDuplicate: () -> Unit,
    onCancel: () -> Unit,
) {
    val active = schedule.status == ScheduledStatus.ACTIVE || schedule.status == ScheduledStatus.SUSPENDED
    ASphoneCard {
        Text(
            text = schedule.body,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = schedule.recipients.joinToString(", "),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(
                R.string.schedule_next_run,
                formatDateTime(schedule.nextRunMillis, schedule.zoneId),
            ),
            style = MaterialTheme.typography.bodySmall,
        )
        Text(
            text = "${stringResource(recurrenceLabel(schedule.recurrence.type))} · ${stringResource(statusLabel(schedule.status))}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (active) {
                val suspended = schedule.status == ScheduledStatus.SUSPENDED
                IconButton(onClick = onToggleSuspended) {
                    Icon(
                        if (suspended) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = stringResource(
                            if (suspended) R.string.schedule_resume else R.string.schedule_suspend,
                        ),
                    )
                }
            }
            IconButton(onClick = onDuplicate) {
                Icon(Icons.Filled.ContentCopy, contentDescription = stringResource(R.string.schedule_duplicate))
            }
            if (active) {
                IconButton(onClick = onCancel) {
                    Icon(Icons.Filled.Cancel, contentDescription = stringResource(R.string.schedule_cancel))
                }
            }
        }
    }
}

@Composable
private fun RecurrenceSelector(selected: RecurrenceType, onSelect: (RecurrenceType) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.schedule_recurrence) + " : " + stringResource(recurrenceLabel(selected)))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            RecurrenceType.entries.forEach { type ->
                DropdownMenuItem(
                    text = { Text(stringResource(recurrenceLabel(type))) },
                    onClick = {
                        onSelect(type)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
private fun DaySelector(selected: Set<DayOfWeek>, onToggle: (DayOfWeek) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        DayOfWeek.entries.forEach { day ->
            FilterChip(
                selected = day in selected,
                onClick = { onToggle(day) },
                label = { Text(day.getDisplayName(TextStyle.SHORT, Locale.getDefault())) },
            )
        }
    }
}

@Composable
private fun ScheduleDatePicker(
    initial: LocalDate?,
    onDismiss: () -> Unit,
    onPicked: (LocalDate) -> Unit,
) {
    val initialMillis = (initial ?: LocalDate.now())
        .atStartOfDay(ZoneOffset.UTC)
        .toInstant()
        .toEpochMilli()
    val pickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    pickerState.selectedDateMillis?.let { millis ->
                        onPicked(Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate())
                    }
                },
            ) {
                Text(stringResource(R.string.action_ok))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    ) {
        DatePicker(state = pickerState)
    }
}

@Composable
private fun ScheduleTimePicker(
    initial: LocalTime?,
    is24Hour: Boolean,
    onDismiss: () -> Unit,
    onPicked: (LocalTime) -> Unit,
) {
    val base = initial ?: LocalTime.now().plusHours(1).withMinute(0).withSecond(0).withNano(0)
    val pickerState = rememberTimePickerState(
        initialHour = base.hour,
        initialMinute = base.minute,
        is24Hour = is24Hour,
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.schedule_pick_time)) },
        text = { TimePicker(state = pickerState) },
        confirmButton = {
            TextButton(onClick = { onPicked(LocalTime.of(pickerState.hour, pickerState.minute)) }) {
                Text(stringResource(R.string.action_ok))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}

private fun dateFormatter(): DateTimeFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)

private fun timeFormatter(): DateTimeFormatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)

private fun formatDateTime(millis: Long, zoneId: String): String =
    DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
        .format(Instant.ofEpochMilli(millis).atZone(ZoneId.of(zoneId)))

private fun issueLabel(issue: ScheduleIssue): Int = when (issue) {
    ScheduleIssue.NO_RECIPIENT -> R.string.schedule_error_no_recipient
    ScheduleIssue.INVALID_RECIPIENT -> R.string.schedule_error_invalid_recipient
    ScheduleIssue.EMPTY_BODY -> R.string.schedule_error_empty_body
    ScheduleIssue.DATE_IN_PAST -> R.string.schedule_error_past
    ScheduleIssue.MISSING_DATE -> R.string.schedule_error_missing_date
    ScheduleIssue.MISSING_TIME -> R.string.schedule_error_missing_time
    ScheduleIssue.INVALID_INTERVAL -> R.string.schedule_error_interval
    ScheduleIssue.NO_DAY -> R.string.schedule_error_no_day
}

private fun recurrenceLabel(type: RecurrenceType): Int = when (type) {
    RecurrenceType.ONCE -> R.string.recurrence_once
    RecurrenceType.DAILY -> R.string.recurrence_daily
    RecurrenceType.WEEKLY -> R.string.recurrence_weekly
    RecurrenceType.MONTHLY -> R.string.recurrence_monthly
    RecurrenceType.YEARLY -> R.string.recurrence_yearly
    RecurrenceType.WEEKDAYS -> R.string.recurrence_weekdays
    RecurrenceType.CUSTOM_DAYS -> R.string.recurrence_custom_days
    RecurrenceType.ANNIVERSARY -> R.string.recurrence_anniversary
    RecurrenceType.CUSTOM_INTERVAL -> R.string.recurrence_custom_interval
}

private fun statusLabel(status: ScheduledStatus): Int = when (status) {
    ScheduledStatus.ACTIVE -> R.string.schedule_status_active
    ScheduledStatus.SUSPENDED -> R.string.schedule_status_suspended
    ScheduledStatus.COMPLETED -> R.string.schedule_status_completed
    ScheduledStatus.CANCELLED -> R.string.schedule_status_cancelled
    ScheduledStatus.FAILED -> R.string.schedule_status_failed
}
