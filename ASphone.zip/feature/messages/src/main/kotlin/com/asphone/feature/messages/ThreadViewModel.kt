package com.asphone.feature.messages

import android.content.Intent
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.common.Gsm7
import com.asphone.core.common.SmsSegmentInfo
import com.asphone.core.data.contacts.ContactsRepository
import com.asphone.core.data.sms.SmsRepository
import com.asphone.core.data.sms.SmsSender
import com.asphone.core.data.telecom.RoleHelper
import com.asphone.core.model.SmsMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ThreadUiState(
    val address: String = "",
    val title: String = "",
    val messages: List<SmsMessage> = emptyList(),
    val draft: String = "",
    val analysis: SmsSegmentInfo = Gsm7.analyze(""),
    val smsRoleHeld: Boolean = false,
    val sending: Boolean = false,
    val needsSmsRole: Boolean = false,
    val permissionMissing: Boolean = false,
    val error: Boolean = false,
)

/**
 * Fil de messages. Un message n'est affiché comme envoyé que lorsque le système a confirmé l'envoi.
 * L'écriture dans le fournisseur SMS exige que A.Sphone soit l'application SMS par défaut.
 */
@HiltViewModel
class ThreadViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val sms: SmsRepository,
    private val sender: SmsSender,
    private val roles: RoleHelper,
    private val contacts: ContactsRepository,
) : ViewModel() {

    private val address: String = savedStateHandle.get<String>(ARG_ADDRESS).orEmpty()
    private var threadId: Long? = (savedStateHandle.get<Long>(ARG_THREAD_ID) ?: NEW_THREAD).takeIf { it >= 0 }

    private val _uiState = MutableStateFlow(
        ThreadUiState(address = address, smsRoleHeld = roles.isSmsHeld()),
    )
    val uiState: StateFlow<ThreadUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val name = try {
                contacts.displayNameFor(address) ?: address
            } catch (error: SecurityException) {
                address
            }
            _uiState.update { it.copy(title = name) }
            reload()
        }
        viewModelScope.launch {
            sms.changes().collect { reload() }
        }
    }

    fun onDraftChange(value: String) {
        val text = value.take(MAX_DRAFT_CHARS)
        _uiState.update { it.copy(draft = text, analysis = Gsm7.analyze(text)) }
    }

    fun send() {
        val state = _uiState.value
        if (state.sending || state.draft.isBlank() || state.address.isBlank()) return
        if (!roles.isSmsHeld()) {
            _uiState.update { it.copy(needsSmsRole = true) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(sending = true) }
            try {
                sender.send(state.address, state.draft, subscriptionId = null)
                _uiState.update { it.copy(draft = "", analysis = Gsm7.analyze(""), sending = false) }
                reload()
            } catch (error: SecurityException) {
                _uiState.update { it.copy(sending = false, permissionMissing = true) }
            } catch (error: IllegalArgumentException) {
                _uiState.update { it.copy(sending = false, error = true) }
            }
        }
    }

    fun dismissRoleRequest() {
        _uiState.update { it.copy(needsSmsRole = false) }
    }

    fun smsRoleIntent(): Intent? = roles.smsRequestIntent()

    private suspend fun reload() {
        try {
            if (threadId == null && address.isNotBlank()) {
                threadId = sms.threadIdFor(address)
            }
            val id = threadId
            val messages = if (id != null) sms.messages(id) else emptyList()
            if (id != null) {
                runCatching { sms.markThreadRead(id) }
            }
            _uiState.update {
                it.copy(messages = messages, smsRoleHeld = roles.isSmsHeld(), permissionMissing = false)
            }
        } catch (error: SecurityException) {
            _uiState.update { it.copy(permissionMissing = true) }
        }
    }

    companion object {
        const val ARG_THREAD_ID = "threadId"
        const val ARG_ADDRESS = "address"
        const val NEW_THREAD = -1L
        private const val MAX_DRAFT_CHARS = 1_600
    }
}
