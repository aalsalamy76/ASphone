package com.asphone.feature.messages

import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.data.sms.SmsRepository
import com.asphone.core.data.telecom.RoleHelper
import com.asphone.core.model.Conversation
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ConversationsUiState(
    val conversations: List<Conversation> = emptyList(),
    val loading: Boolean = true,
    val smsRoleHeld: Boolean = false,
    val permissionMissing: Boolean = false,
)

/** Liste des conversations, mise à jour à chaque changement du fournisseur SMS. */
@HiltViewModel
class ConversationsViewModel @Inject constructor(
    private val sms: SmsRepository,
    private val roles: RoleHelper,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConversationsUiState())
    val uiState: StateFlow<ConversationsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            sms.changes().collect { reload() }
        }
    }

    fun reload() {
        viewModelScope.launch {
            val held = roles.isSmsHeld()
            try {
                val list = sms.conversations()
                _uiState.update {
                    it.copy(conversations = list, loading = false, smsRoleHeld = held, permissionMissing = false)
                }
            } catch (error: SecurityException) {
                _uiState.update { it.copy(loading = false, smsRoleHeld = held, permissionMissing = true) }
            }
        }
    }

    fun smsRoleIntent(): Intent? = roles.smsRequestIntent()
}
