package com.asphone.feature.messages

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.common.SmsEncoding
import com.asphone.core.common.SmsSegmentInfo
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.ASphoneCard
import com.asphone.core.designsystem.components.ConfirmDialog
import com.asphone.core.model.MessageState
import com.asphone.core.model.SmsDirection
import com.asphone.core.model.SmsMessage
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

/** Conversation avec un correspondant : historique, composeur et compteur de segments SMS. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThreadScreen(
    onBack: () -> Unit,
    viewModel: ThreadViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val listState = rememberLazyListState()

    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        viewModel.send()
    }
    val sendPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.send()
    }

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = state.title.ifBlank { stringResource(R.string.messages_new) },
                        maxLines = 1,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                        )
                    }
                },
            )
        },
        bottomBar = {
            Composer(
                draft = state.draft,
                analysis = state.analysis,
                enabled = state.address.isNotBlank() && !state.sending,
                onDraftChange = viewModel::onDraftChange,
                onSend = {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) ==
                        PackageManager.PERMISSION_GRANTED
                    if (granted) viewModel.send() else sendPermission.launch(Manifest.permission.SEND_SMS)
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            if (!state.smsRoleHeld) {
                ASphoneCard(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text(
                        text = stringResource(R.string.messages_role_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = {
                        viewModel.smsRoleIntent()?.let { intent -> roleLauncher.launch(intent) }
                    }) {
                        Text(stringResource(R.string.messages_role_action))
                    }
                }
            }
            if (state.permissionMissing) {
                Text(
                    text = stringResource(R.string.messages_permission_missing),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(state.messages, key = { it.id }) { message ->
                    MessageBubble(message)
                }
            }
        }
    }

    if (state.needsSmsRole) {
        ConfirmDialog(
            title = stringResource(R.string.messages_role_title),
            message = stringResource(R.string.messages_role_body),
            confirmLabel = stringResource(R.string.messages_role_action),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                viewModel.dismissRoleRequest()
                viewModel.smsRoleIntent()?.let { intent -> roleLauncher.launch(intent) }
            },
            onDismiss = viewModel::dismissRoleRequest,
        )
    }
}

@Composable
private fun Composer(
    draft: String,
    analysis: SmsSegmentInfo,
    enabled: Boolean,
    onDraftChange: (String) -> Unit,
    onSend: () -> Unit,
) {
    Surface(
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars)),
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = onDraftChange,
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    placeholder = { Text(stringResource(R.string.messages_composer_hint)) },
                )
                IconButton(onClick = onSend, enabled = enabled && draft.isNotBlank()) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.messages_send),
                    )
                }
            }
            if (draft.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.messages_counter, analysis.units, analysis.segments),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = stringResource(
                        if (analysis.encoding == SmsEncoding.GSM_7) {
                            R.string.messages_encoding_gsm
                        } else {
                            R.string.messages_encoding_ucs2
                        },
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun MessageBubble(message: SmsMessage) {
    val outgoing = message.direction != SmsDirection.INBOX
    val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(message.timestampMillis))
    val statusLabel = if (outgoing) stateLabel(message.state) else null

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (outgoing) Alignment.End else Alignment.Start,
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (outgoing) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
        ) {
            Text(
                text = message.body,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .padding(12.dp)
                    .widthIn(max = 300.dp),
            )
        }
        Text(
            text = listOfNotNull(time, statusLabel?.let { stringResource(it) }).joinToString(" · "),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun stateLabel(state: MessageState): Int? = when (state) {
    MessageState.QUEUED -> R.string.messages_state_queued
    MessageState.SENDING -> R.string.messages_state_sending
    MessageState.SENT -> R.string.messages_state_sent
    MessageState.DELIVERED -> R.string.messages_state_delivered
    MessageState.FAILED -> R.string.messages_state_failed
    else -> null
}
