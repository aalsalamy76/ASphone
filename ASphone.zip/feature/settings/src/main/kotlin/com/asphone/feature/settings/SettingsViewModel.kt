package com.asphone.feature.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.data.backup.BackupRepository
import com.asphone.core.data.backup.RestoreResult
import com.asphone.core.data.settings.SettingsRepository
import com.asphone.core.data.telecom.RoleHelper
import com.asphone.core.model.AppSettings
import com.asphone.core.model.ThemeMode
import com.asphone.core.security.BackupException
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import javax.inject.Inject

/** Résultat d'une sauvegarde ou d'une restauration, affiché par l'écran. */
sealed interface BackupOutcome {
    data object Exported : BackupOutcome
    data class Restored(val result: RestoreResult) : BackupOutcome
    data object PassphraseTooShort : BackupOutcome
    data object WrongPassphraseOrDamaged : BackupOutcome
    data object Failed : BackupOutcome
}

data class SettingsUiState(
    val settings: AppSettings = AppSettings(themeMode = ThemeMode.SYSTEM, amoled = false, dynamicColor = true),
    val showMessageDetails: Boolean = true,
    val dialerHeld: Boolean = false,
    val smsHeld: Boolean = false,
    val languageTag: String = "",
    val busy: Boolean = false,
    val outcome: BackupOutcome? = null,
)

/**
 * Préférences, rôles système, langue et sauvegarde chiffrée.
 * La phrase de passe n'est jamais journalisée et est effacée de la mémoire après usage.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
    private val roles: RoleHelper,
    private val backup: BackupRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settings.settings.collect { value -> _uiState.update { it.copy(settings = value) } }
        }
        viewModelScope.launch {
            settings.showMessageDetails.collect { value ->
                _uiState.update { it.copy(showMessageDetails = value) }
            }
        }
        refreshRoles()
        _uiState.update { it.copy(languageTag = AppCompatDelegate.getApplicationLocales().toLanguageTags()) }
    }

    fun refreshRoles() {
        _uiState.update { it.copy(dialerHeld = roles.isDialerHeld(), smsHeld = roles.isSmsHeld()) }
    }

    fun dialerRoleIntent(): Intent? = roles.dialerRequestIntent()

    fun smsRoleIntent(): Intent? = roles.smsRequestIntent()

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settings.setThemeMode(mode) }
    }

    fun setAmoled(enabled: Boolean) {
        viewModelScope.launch { settings.setAmoled(enabled) }
    }

    fun setDynamicColor(enabled: Boolean) {
        viewModelScope.launch { settings.setDynamicColor(enabled) }
    }

    fun setShowMessageDetails(enabled: Boolean) {
        viewModelScope.launch { settings.setShowMessageDetails(enabled) }
    }

    /** Change la langue de l'application ; une chaîne vide rétablit la langue du système. */
    fun setLanguage(tag: String) {
        val locales = if (tag.isEmpty()) {
            LocaleListCompat.getEmptyLocaleList()
        } else {
            LocaleListCompat.forLanguageTags(tag)
        }
        AppCompatDelegate.setApplicationLocales(locales)
        _uiState.update { it.copy(languageTag = tag) }
    }

    fun consumeOutcome() {
        _uiState.update { it.copy(outcome = null) }
    }

    fun exportBackup(uri: Uri, passphrase: CharArray) {
        if (passphrase.size < MIN_PASSPHRASE_LENGTH) {
            passphrase.fill('\u0000')
            _uiState.update { it.copy(outcome = BackupOutcome.PassphraseTooShort) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, outcome = null) }
            val outcome = withContext(Dispatchers.IO) {
                try {
                    val bytes = backup.export(passphrase, System.currentTimeMillis())
                    val stream = context.contentResolver.openOutputStream(uri)
                        ?: return@withContext BackupOutcome.Failed
                    stream.use { it.write(bytes) }
                    BackupOutcome.Exported
                } catch (error: IOException) {
                    BackupOutcome.Failed
                } finally {
                    passphrase.fill('\u0000')
                }
            }
            _uiState.update { it.copy(busy = false, outcome = outcome) }
        }
    }

    fun restoreBackup(uri: Uri, passphrase: CharArray) {
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, outcome = null) }
            val outcome = withContext(Dispatchers.IO) {
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: return@withContext BackupOutcome.Failed
                    if (bytes.size > MAX_BACKUP_BYTES) return@withContext BackupOutcome.Failed
                    BackupOutcome.Restored(backup.restore(bytes, passphrase, System.currentTimeMillis()))
                } catch (error: BackupException) {
                    BackupOutcome.WrongPassphraseOrDamaged
                } catch (error: IOException) {
                    BackupOutcome.Failed
                } finally {
                    passphrase.fill('\u0000')
                }
            }
            refreshRoles()
            _uiState.update { it.copy(busy = false, outcome = outcome) }
        }
    }

    companion object {
        const val MIN_PASSPHRASE_LENGTH = 12
        private const val MAX_BACKUP_BYTES = 8 * 1024 * 1024
    }
}
