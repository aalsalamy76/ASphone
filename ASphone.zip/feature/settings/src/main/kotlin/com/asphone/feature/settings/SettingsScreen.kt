package com.asphone.feature.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.SectionTitle
import com.asphone.core.model.ThemeMode
import kotlinx.coroutines.launch

private data class LanguageOption(val tag: String, val label: String)

/** Noms des langues écrits dans leur propre langue, pour que chacun retrouve la sienne. */
private val LANGUAGES = listOf(
    LanguageOption("fr", "Français"),
    LanguageOption("en", "English"),
    LanguageOption("es", "Español"),
    LanguageOption("ar", "العربية"),
    LanguageOption("hi", "हिन्दी"),
    LanguageOption("zh-CN", "简体中文"),
)

private enum class PassphraseMode { EXPORT, IMPORT }

/** Réglages : apparence, langue, rôles système, notifications et sauvegarde chiffrée. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onOpenAbout: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var passphraseMode by remember { mutableStateOf<PassphraseMode?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }

    val createLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri ->
        if (uri != null) {
            pendingUri = uri
            passphraseMode = PassphraseMode.EXPORT
        }
    }
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingUri = uri
            passphraseMode = PassphraseMode.IMPORT
        }
    }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        viewModel.refreshRoles()
    }

    LaunchedEffect(state.outcome) {
        val outcome = state.outcome ?: return@LaunchedEffect
        val message = when (outcome) {
            BackupOutcome.Exported -> context.getString(R.string.backup_done_export)
            is BackupOutcome.Restored -> context.getString(
                R.string.backup_done_import,
                outcome.result.schedules,
                outcome.result.reminders,
                outcome.result.blockedNumbers,
                outcome.result.skipped,
            )
            BackupOutcome.PassphraseTooShort -> context.getString(
                R.string.backup_passphrase_short,
                SettingsViewModel.MIN_PASSPHRASE_LENGTH,
            )
            BackupOutcome.WrongPassphraseOrDamaged -> context.getString(R.string.backup_wrong_or_damaged)
            BackupOutcome.Failed -> context.getString(R.string.backup_failed)
        }
        viewModel.consumeOutcome()
        scope.launch { snackbarHostState.showSnackbar(message) }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = { TopAppBar(title = { Text(stringResource(R.string.settings_title)) }) },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.padding(innerPadding),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            item { SectionTitle(stringResource(R.string.settings_appearance), Modifier.padding(horizontal = 16.dp)) }
            items(ThemeMode.entries, key = { it.name }) { mode ->
                ChoiceRow(
                    label = stringResource(themeLabel(mode)),
                    selected = state.settings.themeMode == mode,
                    onSelect = { viewModel.setThemeMode(mode) },
                )
            }
            item {
                SwitchRow(
                    label = stringResource(R.string.settings_amoled),
                    checked = state.settings.amoled,
                    onChange = viewModel::setAmoled,
                )
            }
            item {
                SwitchRow(
                    label = stringResource(R.string.settings_dynamic_color),
                    checked = state.settings.dynamicColor,
                    onChange = viewModel::setDynamicColor,
                )
            }

            item { SectionTitle(stringResource(R.string.settings_language), Modifier.padding(horizontal = 16.dp)) }
            item {
                ChoiceRow(
                    label = stringResource(R.string.settings_language_system),
                    selected = state.languageTag.isEmpty(),
                    onSelect = { viewModel.setLanguage("") },
                )
            }
            items(LANGUAGES, key = { it.tag }) { option ->
                ChoiceRow(
                    label = option.label,
                    selected = state.languageTag == option.tag,
                    onSelect = { viewModel.setLanguage(option.tag) },
                )
            }

            item { SectionTitle(stringResource(R.string.settings_default_apps), Modifier.padding(horizontal = 16.dp)) }
            item {
                RoleRow(
                    title = stringResource(R.string.settings_dialer_role),
                    held = state.dialerHeld,
                    onRequest = {
                        viewModel.dialerRoleIntent()?.let { intent -> roleLauncher.launch(intent) }
                    },
                )
            }
            item {
                RoleRow(
                    title = stringResource(R.string.settings_sms_role),
                    held = state.smsHeld,
                    onRequest = {
                        viewModel.smsRoleIntent()?.let { intent -> roleLauncher.launch(intent) }
                    },
                )
            }

            item { SectionTitle(stringResource(R.string.settings_notifications), Modifier.padding(horizontal = 16.dp)) }
            item {
                SwitchRow(
                    label = stringResource(R.string.settings_show_details),
                    checked = state.showMessageDetails,
                    onChange = viewModel::setShowMessageDetails,
                )
            }

            item { SectionTitle(stringResource(R.string.settings_backup), Modifier.padding(horizontal = 16.dp)) }
            item {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.settings_backup_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedButton(
                        onClick = { createLauncher.launch("A-Sphone-sauvegarde.asphb") },
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(stringResource(R.string.settings_backup_export))
                    }
                    OutlinedButton(
                        onClick = { openLauncher.launch(arrayOf("*/*")) },
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(stringResource(R.string.settings_backup_import))
                    }
                }
            }

            item { SectionTitle(stringResource(R.string.settings_about_section), Modifier.padding(horizontal = 16.dp)) }
            item {
                ListItem(
                    headlineContent = { Text(stringResource(R.string.about_title)) },
                    leadingContent = { Icon(Icons.Filled.Info, contentDescription = null) },
                    trailingContent = {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    },
                    modifier = Modifier.selectable(
                        selected = false,
                        role = Role.Button,
                        onClick = onOpenAbout,
                    ),
                )
            }
        }
    }

    passphraseMode?.let { mode ->
        PassphraseDialog(
            mode = mode,
            onDismiss = {
                passphraseMode = null
                pendingUri = null
            },
            onConfirm = { passphrase ->
                val uri = pendingUri
                passphraseMode = null
                pendingUri = null
                if (uri != null) {
                    when (mode) {
                        PassphraseMode.EXPORT -> viewModel.exportBackup(uri, passphrase)
                        PassphraseMode.IMPORT -> viewModel.restoreBackup(uri, passphrase)
                    }
                }
            },
        )
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, role = Role.RadioButton, onClick = onSelect)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(text = label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(label) },
        trailingContent = { Switch(checked = checked, onCheckedChange = null) },
        modifier = Modifier.toggleable(value = checked, role = Role.Switch, onValueChange = onChange),
    )
}

@Composable
private fun RoleRow(title: String, held: Boolean, onRequest: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = {
            Text(
                stringResource(
                    if (held) R.string.settings_role_granted else R.string.settings_role_missing,
                ),
            )
        },
        trailingContent = {
            if (!held) {
                TextButton(onClick = onRequest) { Text(stringResource(R.string.settings_role_action)) }
            }
        },
    )
}

@Composable
private fun PassphraseDialog(
    mode: PassphraseMode,
    onDismiss: () -> Unit,
    onConfirm: (CharArray) -> Unit,
) {
    var passphrase by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf("") }
    val mismatch = mode == PassphraseMode.EXPORT && confirmation.isNotEmpty() && confirmation != passphrase
    val canConfirm = passphrase.isNotEmpty() && (mode == PassphraseMode.IMPORT || confirmation == passphrase)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                stringResource(
                    if (mode == PassphraseMode.EXPORT) R.string.backup_passphrase_title_export else R.string.backup_passphrase_title_import,
                ),
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.backup_passphrase_warning),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = passphrase,
                    onValueChange = { passphrase = it },
                    label = { Text(stringResource(R.string.backup_passphrase_label)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (mode == PassphraseMode.EXPORT) {
                    OutlinedTextField(
                        value = confirmation,
                        onValueChange = { confirmation = it },
                        label = { Text(stringResource(R.string.backup_passphrase_confirm)) },
                        singleLine = true,
                        isError = mismatch,
                        supportingText = {
                            if (mismatch) Text(stringResource(R.string.backup_passphrase_mismatch))
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(passphrase.toCharArray()) },
                enabled = canConfirm,
            ) {
                Text(stringResource(R.string.action_continue))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}

private fun themeLabel(mode: ThemeMode): Int = when (mode) {
    ThemeMode.SYSTEM -> R.string.settings_theme_system
    ThemeMode.LIGHT -> R.string.settings_theme_light
    ThemeMode.DARK -> R.string.settings_theme_dark
}
