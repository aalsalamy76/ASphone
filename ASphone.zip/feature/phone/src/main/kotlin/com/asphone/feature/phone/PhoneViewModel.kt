package com.asphone.feature.phone

import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.data.blocking.BlockedNumbersRepository
import com.asphone.core.data.calllog.CallLogRepository
import com.asphone.core.data.contacts.ContactsRepository
import com.asphone.core.data.telecom.RoleHelper
import com.asphone.core.model.CallLogEntry
import com.asphone.core.model.ContactSummary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PhoneUiState(
    val query: String = "",
    val suggestions: List<ContactSummary> = emptyList(),
    val recents: List<CallLogEntry> = emptyList(),
    val dialerRoleHeld: Boolean = false,
)

/** Clavier, recherche T9 et historique d'appels. Aucun appel n'est passé sans action explicite. */
@HiltViewModel
class PhoneViewModel @Inject constructor(
    private val contacts: ContactsRepository,
    private val callLog: CallLogRepository,
    private val blocked: BlockedNumbersRepository,
    private val roles: RoleHelper,
) : ViewModel() {

    private val _uiState = MutableStateFlow(PhoneUiState())
    val uiState: StateFlow<PhoneUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun onQueryChange(value: String) {
        _uiState.value = _uiState.value.copy(query = value)
        viewModelScope.launch {
            val suggestions = if (value.isBlank()) emptyList() else contacts.search(value).take(MAX_SUGGESTIONS)
            _uiState.value = _uiState.value.copy(suggestions = suggestions)
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                recents = callLog.recent(),
                dialerRoleHeld = roles.isDialerHeld(),
            )
        }
    }

    fun dialerRoleIntent(): Intent? = roles.dialerRequestIntent()

    fun block(number: String) {
        viewModelScope.launch {
            blocked.block(number)
            refresh()
        }
    }

    private companion object {
        const val MAX_SUGGESTIONS = 8
    }
}
