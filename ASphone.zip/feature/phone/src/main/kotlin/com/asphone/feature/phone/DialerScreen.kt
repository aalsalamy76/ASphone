package com.asphone.feature.phone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.ASphoneCard
import com.asphone.core.designsystem.components.ConfirmDialog
import com.asphone.core.designsystem.components.EmptyState
import com.asphone.core.model.CallLogEntry
import com.asphone.core.model.CallType
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private val KEYS = listOf(
    "1" to "", "2" to "ABC", "3" to "DEF",
    "4" to "GHI", "5" to "JKL", "6" to "MNO",
    "7" to "PQRS", "8" to "TUV", "9" to "WXYZ",
    "*" to "", "0" to "", "#" to "",
)

private const val TAG = "DialerScreen"

/** Écran téléphone : recherche T9, historique, clavier et appel explicite. */
@Composable
fun DialerScreen(
    onOpenThread: (String) -> Unit,
    viewModel: PhoneViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    var pendingCall by remember { mutableStateOf<String?>(null) }
    var pendingBlock by remember { mutableStateOf<String?>(null) }

    val callPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val number = pendingCall
        pendingCall = null
        if (granted && number != null) placeCall(context, number)
    }
    val readPermissions = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { viewModel.refresh() }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        viewModel.refresh()
    }

    LaunchedEffect(Unit) {
        val missing = listOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS)
            .filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) readPermissions.launch(missing.toTypedArray())
    }

    val onCall: (String) -> Unit = { number ->
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            placeCall(context, number)
        } else {
            pendingCall = number
            callPermission.launch(Manifest.permission.CALL_PHONE)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (!state.dialerRoleHeld) {
            DialerRoleBanner(
                onRequest = {
                    val intent = viewModel.dialerRoleIntent()
                    if (intent != null) roleLauncher.launch(intent)
                },
            )
        }

        OutlinedTextField(
            value = state.query,
            onValueChange = viewModel::onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(stringResource(R.string.phone_number_hint)) },
        )

        if (state.query.isBlank()) {
            if (state.recents.isEmpty()) {
                EmptyState(
                    icon = Icons.Filled.Call,
                    title = stringResource(R.string.phone_no_calls),
                    message = stringResource(R.string.phone_no_calls_message),
                    modifier = Modifier.weight(1f),
                )
            } else {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(state.recents, key = { it.id }) { entry ->
                        CallRow(
                            entry = entry,
                            onCall = onCall,
                            onBlock = { pendingBlock = entry.number },
                        )
                    }
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (isDialable(state.query)) {
                    item(key = "dial-typed") {
                        ListItem(
                            headlineContent = {
                                Text(stringResource(R.string.phone_call_number, state.query))
                            },
                            leadingContent = { Icon(Icons.Filled.Call, contentDescription = null) },
                            modifier = Modifier.clickable { onCall(state.query) },
                        )
                    }
                }
                items(state.suggestions, key = { "contact-${it.id}" }) { contact ->
                    ListItem(
                        headlineContent = { Text(contact.displayName) },
                        supportingContent = {
                            Text(contact.primaryPhone ?: stringResource(R.string.contacts_no_phone))
                        },
                        modifier = Modifier.clickable {
                            contact.primaryPhone?.let(onCall)
                        },
                    )
                }
            }
        }

        Keypad(
            onDigit = { symbol ->
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                viewModel.onQueryChange(state.query + symbol)
            },
            onBackspace = {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                viewModel.onQueryChange(state.query.dropLast(1))
            },
            onCall = { if (state.query.isNotBlank()) onCall(state.query) },
            onMessage = { if (state.query.isNotBlank()) onOpenThread(state.query) },
        )
        Spacer(Modifier.size(8.dp))
    }

    pendingBlock?.let { number ->
        ConfirmDialog(
            title = stringResource(R.string.phone_block_title),
            message = stringResource(R.string.phone_block_message, number),
            confirmLabel = stringResource(R.string.action_block),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                viewModel.block(number)
                pendingBlock = null
            },
            onDismiss = { pendingBlock = null },
        )
    }
}

@Composable
private fun DialerRoleBanner(onRequest: () -> Unit) {
    ASphoneCard {
        Text(
            text = stringResource(R.string.phone_role_title),
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.size(4.dp))
        Text(
            text = stringResource(R.string.phone_role_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        TextButton(onClick = onRequest) {
            Text(stringResource(R.string.phone_role_action))
        }
    }
}

@Composable
private fun CallRow(entry: CallLogEntry, onCall: (String) -> Unit, onBlock: () -> Unit) {
    val title = entry.contactName ?: entry.number
    val typeLabel = stringResource(callTypeLabel(entry.type))
    val time = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        .format(Date(entry.timestampMillis))
    ListItem(
        headlineContent = {
            Text(
                text = title,
                fontWeight = if (entry.type == CallType.MISSED) FontWeight.SemiBold else FontWeight.Normal,
            )
        },
        supportingContent = { Text("$typeLabel · $time") },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBlock) {
                    Icon(Icons.Filled.Block, contentDescription = stringResource(R.string.action_block))
                }
                IconButton(onClick = { onCall(entry.number) }) {
                    Icon(Icons.Filled.Call, contentDescription = stringResource(R.string.phone_call_action))
                }
            }
        },
        modifier = Modifier.clickable { onCall(entry.number) },
    )
}

@Composable
private fun Keypad(
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    onCall: () -> Unit,
    onMessage: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        KEYS.chunked(3).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                row.forEach { (symbol, letters) ->
                    OutlinedButton(
                        onClick = { onDigit(symbol) },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 56.dp),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = symbol, style = MaterialTheme.typography.titleLarge)
                            if (letters.isNotEmpty()) {
                                Text(text = letters, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onMessage, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.Sms, contentDescription = stringResource(R.string.messages_new))
            }
            FilledIconButton(
                onClick = onCall,
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color(0xFF15803D),
                    contentColor = Color.White,
                ),
            ) {
                Icon(Icons.Filled.Call, contentDescription = stringResource(R.string.phone_call_action))
            }
            IconButton(onClick = onBackspace, modifier = Modifier.size(56.dp)) {
                Icon(
                    Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = stringResource(R.string.phone_backspace),
                )
            }
        }
    }
}

private fun isDialable(query: String): Boolean =
    query.any { it.isDigit() } && query.all { it.isDigit() || it in "+*# -()." }

private fun callTypeLabel(type: CallType): Int = when (type) {
    CallType.INCOMING -> R.string.call_incoming
    CallType.OUTGOING -> R.string.call_outgoing
    CallType.MISSED -> R.string.call_missed
    CallType.REJECTED -> R.string.call_rejected
    CallType.BLOCKED -> R.string.call_blocked
    CallType.VOICEMAIL -> R.string.call_voicemail
}

/** Lance l'appel explicitement ; l'autorisation CALL_PHONE doit déjà être accordée. */
private fun placeCall(context: Context, number: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (error: SecurityException) {
        Log.w(TAG, "Appel refusé : autorisation absente.", error)
    }
}
