package com.asphone.feature.phone

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.data.telecom.CallPhase
import com.asphone.core.designsystem.R

/**
 * Écran d'appel en cours. Affiché par [InCallActivity] ; [onFinished] est appelé quand
 * le dernier appel est terminé.
 */
@Composable
fun InCallScreen(
    onFinished: () -> Unit,
    viewModel: InCallViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(state.ended) {
        if (state.ended) onFinished()
    }

    val call = state.call
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Spacer(Modifier.height(48.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = call?.displayName ?: call?.number ?: stringResource(R.string.incall_unknown_number),
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(phaseLabel(call?.phase)),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (call?.phase == CallPhase.RINGING) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                LabelledAction(
                    label = stringResource(R.string.incall_reject),
                    containerColor = Color(0xFFB91C1C),
                    onClick = viewModel::reject,
                ) {
                    Icon(Icons.Filled.CallEnd, contentDescription = null)
                }
                LabelledAction(
                    label = stringResource(R.string.incall_answer),
                    containerColor = Color(0xFF15803D),
                    onClick = viewModel::answer,
                ) {
                    Icon(Icons.Filled.Call, contentDescription = null)
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                ToggleAction(
                    label = stringResource(R.string.incall_mute),
                    active = state.muted,
                    onClick = viewModel::toggleMute,
                ) {
                    Icon(
                        if (state.muted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        contentDescription = null,
                    )
                }
                ToggleAction(
                    label = stringResource(R.string.incall_speaker),
                    active = state.speaker,
                    onClick = viewModel::toggleSpeaker,
                ) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = null)
                }
                ToggleAction(
                    label = stringResource(R.string.incall_hold),
                    active = state.onHold,
                    onClick = viewModel::toggleHold,
                ) {
                    Icon(
                        if (state.onHold) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = null,
                    )
                }
            }
            LabelledAction(
                label = stringResource(R.string.incall_hangup),
                containerColor = Color(0xFFB91C1C),
                onClick = viewModel::hangUp,
            ) {
                Icon(Icons.Filled.CallEnd, contentDescription = null)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun LabelledAction(
    label: String,
    containerColor: Color,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = onClick,
            modifier = Modifier.size(72.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = containerColor,
                contentColor = Color.White,
            ),
        ) {
            icon()
        }
        Spacer(Modifier.height(8.dp))
        Text(text = label, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun ToggleAction(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    val stateText = stringResource(if (active) R.string.incall_state_on else R.string.incall_state_off)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledTonalIconButton(
            onClick = onClick,
            modifier = Modifier
                .size(64.dp)
                .semantics { stateDescription = stateText },
            colors = if (active) {
                IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                )
            } else {
                IconButtonDefaults.filledTonalIconButtonColors()
            },
        ) {
            icon()
        }
        Spacer(Modifier.height(8.dp))
        Text(text = label, style = MaterialTheme.typography.labelLarge)
    }
}

private fun phaseLabel(phase: CallPhase?): Int = when (phase) {
    CallPhase.RINGING -> R.string.incall_ringing
    CallPhase.DIALING -> R.string.incall_dialing
    CallPhase.ACTIVE -> R.string.incall_active
    CallPhase.ON_HOLD -> R.string.incall_on_hold
    CallPhase.DISCONNECTED -> R.string.incall_ended
    null -> R.string.incall_ended
}
