package com.asphone.feature.phone

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.data.telecom.ActiveCall
import com.asphone.core.data.telecom.ActiveCallRegistry
import com.asphone.core.data.telecom.CallPhase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class InCallUiState(
    val call: ActiveCall? = null,
    val muted: Boolean = false,
    val speaker: Boolean = false,
    val onHold: Boolean = false,
    val ended: Boolean = false,
)

/**
 * Pilote l'appel principal affiché pendant une communication. Les commandes passent par
 * [ActiveCallRegistry] vers l'InCallService ; aucun enregistrement ni transcription n'est effectué.
 */
@HiltViewModel
class InCallViewModel @Inject constructor(
    private val registry: ActiveCallRegistry,
) : ViewModel() {

    private val muted = MutableStateFlow(false)
    private val speaker = MutableStateFlow(false)

    val uiState: StateFlow<InCallUiState> = combine(registry.calls, muted, speaker) { calls, isMuted, isSpeaker ->
        val call = calls.firstOrNull { it.phase != CallPhase.DISCONNECTED }
        InCallUiState(
            call = call,
            muted = isMuted,
            speaker = isSpeaker,
            onHold = call?.phase == CallPhase.ON_HOLD,
            ended = calls.isNotEmpty() && call == null,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), InCallUiState())

    fun answer() {
        uiState.value.call?.let { registry.answer(it.id) }
    }

    fun reject() {
        uiState.value.call?.let { registry.reject(it.id) }
    }

    fun hangUp() {
        uiState.value.call?.let { registry.hangUp(it.id) }
    }

    fun toggleHold() {
        val call = uiState.value.call ?: return
        registry.setOnHold(call.id, hold = call.phase != CallPhase.ON_HOLD)
    }

    fun toggleMute() {
        val next = !muted.value
        muted.value = next
        registry.setMuted(next)
    }

    fun toggleSpeaker() {
        val next = !speaker.value
        speaker.value = next
        registry.setSpeaker(next)
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
