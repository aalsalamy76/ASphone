package com.asphone.feature.reminders

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.common.PhoneNumbers
import com.asphone.core.data.reminders.ReminderNotifier
import com.asphone.core.data.reminders.ReminderRepository
import com.asphone.core.model.Reminder
import com.asphone.core.model.ReminderKind
import com.asphone.core.model.ReminderPreset
import com.asphone.core.model.ReminderStatus
import com.asphone.core.model.ReminderTiming
import com.asphone.core.model.SnoozeOption
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.ZoneId
import java.time.ZonedDateTime
import javax.inject.Inject

data class RemindersUiState(
    val pending: List<Reminder> = emptyList(),
)

/** Rappels d'appel et de message. Ils ne composent jamais un numéro et n'envoient jamais de message. */
@HiltViewModel
class RemindersViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: ReminderRepository,
    private val notifier: ReminderNotifier,
) : ViewModel() {

    /** Numéro et nom transmis depuis une fiche contact (facultatifs). */
    val prefillNumber: String = savedStateHandle.get<String>(ARG_NUMBER).orEmpty()
    val prefillName: String = savedStateHandle.get<String>(ARG_NAME).orEmpty()

    val uiState: StateFlow<RemindersUiState> = repository.observe()
        .map { list ->
            RemindersUiState(
                pending = list
                    .filter { it.status == ReminderStatus.PENDING }
                    .sortedBy { it.dueAtMillis },
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), RemindersUiState())

    /** Vrai si le numéro saisi peut servir de destinataire. */
    fun isValidNumber(number: String): Boolean = PhoneNumbers.isPlausible(number)

    fun create(
        kind: ReminderKind,
        number: String,
        contactName: String,
        note: String,
        preset: ReminderPreset,
    ) {
        if (!isValidNumber(number)) return
        viewModelScope.launch {
            val zone = ZoneId.systemDefault()
            val due = ReminderTiming.resolvePreset(ZonedDateTime.now(zone), preset).toInstant().toEpochMilli()
            repository.create(
                kind = kind,
                number = PhoneNumbers.normalize(number),
                contactName = contactName.trim().ifEmpty { null },
                note = note.trim(),
                dueAtMillis = due,
                zoneId = zone.id,
                draftText = null,
            )
        }
    }

    fun complete(id: Long) {
        viewModelScope.launch {
            repository.complete(id)
            notifier.cancel(id)
        }
    }

    fun cancel(id: Long) {
        viewModelScope.launch {
            repository.cancel(id)
            notifier.cancel(id)
        }
    }

    fun snooze(id: Long, option: SnoozeOption) {
        viewModelScope.launch {
            repository.snooze(id, option)
            notifier.cancel(id)
        }
    }

    companion object {
        const val ARG_NUMBER = "number"
        const val ARG_NAME = "name"
        private const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
