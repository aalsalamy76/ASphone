package com.asphone.feature.reminders

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.ASphoneCard
import com.asphone.core.designsystem.components.EmptyState
import com.asphone.core.model.Reminder
import com.asphone.core.model.ReminderKind
import com.asphone.core.model.ReminderPreset
import com.asphone.core.model.SnoozeOption
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

private const val TAG = "RemindersScreen"

/**
 * Liste des rappels en attente. Un rappel d'appel ouvre seulement le composeur (ACTION_DIAL) :
 * l'appel doit toujours être confirmé par l'utilisateur.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemindersScreen(
    onOpenThread: (String) -> Unit,
    viewModel: RemindersViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showCreate by remember { mutableStateOf(viewModel.prefillNumber.isNotBlank()) }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(title = { Text(stringResource(R.string.reminders_title)) })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }) {
                Icon(Icons.Filled.Alarm, contentDescription = stringResource(R.string.reminders_new))
            }
        },
    ) { innerPadding ->
        if (state.pending.isEmpty()) {
            EmptyState(
                icon = Icons.Filled.Alarm,
                title = stringResource(R.string.reminders_empty),
                message = stringResource(R.string.reminders_empty_message),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(state.pending, key = { it.id }) { reminder ->
                    ReminderCard(
                        reminder = reminder,
                        onDial = { dial(context, reminder.number) },
                        onMessage = { onOpenThread(reminder.number) },
                        onSnooze = { option -> viewModel.snooze(reminder.id, option) },
                        onDone = { viewModel.complete(reminder.id) },
                        onCancel = { viewModel.cancel(reminder.id) },
                    )
                }
            }
        }
    }

    if (showCreate) {
        CreateReminderDialog(
            initialNumber = viewModel.prefillNumber,
            initialName = viewModel.prefillName,
            isValidNumber = viewModel::isValidNumber,
            onDismiss = { showCreate = false },
            onCreate = { kind, number, name, note, preset ->
                viewModel.create(kind, number, name, note, preset)
                showCreate = false
            },
        )
    }
}

@Composable
private fun ReminderCard(
    reminder: Reminder,
    onDial: () -> Unit,
    onMessage: () -> Unit,
    onSnooze: (SnoozeOption) -> Unit,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    ASphoneCard {
        Text(
            text = stringResource(
                if (reminder.kind == ReminderKind.CALL) R.string.reminders_kind_call else R.string.reminders_kind_message,
            ),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = reminder.contactName ?: reminder.number,
            style = MaterialTheme.typography.titleMedium,
        )
        if (reminder.note.isNotBlank()) {
            Text(
                text = reminder.note,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.reminders_due, formatDue(reminder.dueAtMillis, reminder.zoneId)),
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (reminder.kind == ReminderKind.CALL) {
                IconButton(onClick = onDial) {
                    Icon(Icons.Filled.Call, contentDescription = stringResource(R.string.action_call_now))
                }
            } else {
                IconButton(onClick = onMessage) {
                    Icon(Icons.Filled.Sms, contentDescription = stringResource(R.string.action_compose))
                }
            }
            TextButton(onClick = { onSnooze(SnoozeOption.TEN_MINUTES) }) {
                Text(stringResource(R.string.action_snooze_10))
            }
            TextButton(onClick = { onSnooze(SnoozeOption.ONE_HOUR) }) {
                Text(stringResource(R.string.reminders_snooze_hour))
            }
            IconButton(onClick = onDone) {
                Icon(Icons.Filled.Check, contentDescription = stringResource(R.string.action_done))
            }
            IconButton(onClick = onCancel) {
                Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.reminders_cancel))
            }
        }
    }
}

@Composable
private fun CreateReminderDialog(
    initialNumber: String,
    initialName: String,
    isValidNumber: (String) -> Boolean,
    onDismiss: () -> Unit,
    onCreate: (ReminderKind, String, String, String, ReminderPreset) -> Unit,
) {
    var kind by remember { mutableStateOf(ReminderKind.CALL) }
    var number by remember { mutableStateOf(initialNumber) }
    var name by remember { mutableStateOf(initialName) }
    var note by remember { mutableStateOf("") }
    var preset by remember { mutableStateOf(ReminderPreset.IN_ONE_HOUR) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.reminders_create_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = kind == ReminderKind.CALL,
                        onClick = { kind = ReminderKind.CALL },
                        label = { Text(stringResource(R.string.reminders_kind_call)) },
                    )
                    FilterChip(
                        selected = kind == ReminderKind.MESSAGE,
                        onClick = { kind = ReminderKind.MESSAGE },
                        label = { Text(stringResource(R.string.reminders_kind_message)) },
                    )
                }
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text(stringResource(R.string.contacts_phone_label)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.contacts_name_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(stringResource(R.string.reminders_note_hint)) },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    text = stringResource(R.string.reminders_when),
                    style = MaterialTheme.typography.labelLarge,
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    ReminderPreset.entries.forEach { option ->
                        FilterChip(
                            selected = preset == option,
                            onClick = { preset = option },
                            label = { Text(stringResource(presetLabel(option))) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onCreate(kind, number, name, note, preset) },
                enabled = isValidNumber(number),
            ) {
                Text(stringResource(R.string.action_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}

private fun presetLabel(preset: ReminderPreset): Int = when (preset) {
    ReminderPreset.IN_15_MINUTES -> R.string.reminders_preset_15
    ReminderPreset.IN_30_MINUTES -> R.string.reminders_preset_30
    ReminderPreset.IN_ONE_HOUR -> R.string.reminders_preset_hour
    ReminderPreset.THIS_AFTERNOON -> R.string.reminders_preset_afternoon
    ReminderPreset.TOMORROW -> R.string.reminders_preset_tomorrow
}

private fun formatDue(millis: Long, zoneId: String): String =
    DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
        .format(Instant.ofEpochMilli(millis).atZone(ZoneId.of(zoneId)))

/** Ouvre le composeur téléphonique sans lancer l'appel. */
private fun dial(context: Context, number: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (error: IllegalArgumentException) {
        Log.w(TAG, "Numéro non composable.", error)
    }
}
