package com.asphone.feature.contacts

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.common.PhoneNumbers
import com.asphone.core.data.contacts.ContactDetail
import com.asphone.core.data.telecom.CallIntents
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.ConfirmDialog
import com.asphone.core.designsystem.components.EmptyState
import com.asphone.core.designsystem.components.SectionTitle
import kotlinx.coroutines.launch

private const val TAG = "ContactDetailScreen"

/** Fiche contact. Toute action destructive (suppression, blocage) demande une confirmation. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    onBack: () -> Unit,
    onOpenThread: (String) -> Unit,
    onSchedule: (String) -> Unit,
    onReminder: (number: String, name: String) -> Unit,
    viewModel: ContactDetailViewModel = hiltViewModel(),
) {
    val detail by viewModel.detail.collectAsStateWithLifecycle()
    val blockedNumbers by viewModel.blockedNumbers.collectAsStateWithLifecycle()
    val permissionMissing by viewModel.permissionMissing.collectAsStateWithLifecycle()
    val deleted by viewModel.deleted.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var pendingCall by remember { mutableStateOf<String?>(null) }
    var pendingBlock by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    val callPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val number = pendingCall
        pendingCall = null
        if (granted && number != null) placeCall(context, number)
    }
    val onCall: (String) -> Unit = { number ->
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            placeCall(context, number)
        } else {
            pendingCall = number
            callPermission.launch(Manifest.permission.CALL_PHONE)
        }
    }

    LaunchedEffect(deleted) {
        if (deleted) onBack()
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text(detail?.displayName.orEmpty()) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                        )
                    }
                },
                actions = {
                    if (detail != null) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.contacts_detail_delete))
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        val current: ContactDetail? = detail
        when {
            permissionMissing -> EmptyState(
                icon = Icons.Filled.Person,
                title = stringResource(R.string.contacts_permission_missing),
                message = stringResource(R.string.contacts_permission_hint),
                modifier = Modifier.padding(innerPadding),
            )
            current == null -> EmptyState(
                icon = Icons.Filled.Person,
                title = stringResource(R.string.contacts_not_found),
                message = stringResource(R.string.contacts_not_found_message),
                modifier = Modifier.padding(innerPadding),
            )
            else -> LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    Text(
                        text = current.displayName.ifBlank { stringResource(R.string.contacts_no_name) },
                        style = MaterialTheme.typography.headlineSmall,
                    )
                }
                item { SectionTitle(stringResource(R.string.contacts_phones_section)) }
                if (current.phones.isEmpty()) {
                    item { Text(stringResource(R.string.contacts_no_phone)) }
                }
                items(current.phones, key = { it }) { number ->
                    val isBlocked = blockedNumbers.any { PhoneNumbers.sameNumber(it, number) }
                    PhoneRow(
                        number = number,
                        isBlocked = isBlocked,
                        onCall = { onCall(number) },
                        onMessage = { onOpenThread(number) },
                        onSchedule = { onSchedule(number) },
                        onReminder = { onReminder(number, current.displayName) },
                        onToggleBlock = {
                            if (isBlocked) {
                                viewModel.setBlocked(number, block = false)
                            } else {
                                pendingBlock = number
                            }
                        },
                    )
                }
                item { SectionTitle(stringResource(R.string.contacts_emails_section)) }
                if (current.emails.isEmpty()) {
                    item { Text(stringResource(R.string.contacts_no_email)) }
                }
                items(current.emails, key = { it }) { email ->
                    Text(text = email, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }

    pendingBlock?.let { number ->
        ConfirmDialog(
            title = stringResource(R.string.phone_block_title),
            message = stringResource(R.string.phone_block_message, number),
            confirmLabel = stringResource(R.string.action_block),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                viewModel.setBlocked(number, block = true)
                pendingBlock = null
            },
            onDismiss = { pendingBlock = null },
        )
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.contacts_delete_title),
            message = stringResource(R.string.contacts_delete_message),
            confirmLabel = stringResource(R.string.action_delete),
            dismissLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                confirmDelete = false
                viewModel.delete()
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

@Composable
private fun PhoneRow(
    number: String,
    isBlocked: Boolean,
    onCall: () -> Unit,
    onMessage: () -> Unit,
    onSchedule: () -> Unit,
    onReminder: () -> Unit,
    onToggleBlock: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = if (isBlocked) "$number · ${stringResource(R.string.contacts_blocked_label)}" else number,
            style = MaterialTheme.typography.bodyLarge,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            IconButton(onClick = onCall) {
                Icon(Icons.Filled.Call, contentDescription = stringResource(R.string.phone_call_action))
            }
            IconButton(onClick = onMessage) {
                Icon(Icons.Filled.Sms, contentDescription = stringResource(R.string.messages_new))
            }
            IconButton(onClick = onSchedule) {
                Icon(Icons.Filled.Schedule, contentDescription = stringResource(R.string.schedule_new))
            }
            IconButton(onClick = onReminder) {
                Icon(Icons.Filled.Alarm, contentDescription = stringResource(R.string.reminders_new))
            }
            TextButton(onClick = onToggleBlock) {
                Text(
                    stringResource(
                        if (isBlocked) R.string.contacts_detail_unblock else R.string.contacts_detail_block,
                    ),
                )
            }
        }
    }
}

/** Lance l'appel explicitement ; l'autorisation CALL_PHONE doit déjà être accordée. */
private fun placeCall(context: Context, number: String) {
    try {
        context.startActivity(CallIntents.call(number))
    } catch (error: SecurityException) {
        Log.w(TAG, "Appel refusé : autorisation absente.", error)
    }
}
