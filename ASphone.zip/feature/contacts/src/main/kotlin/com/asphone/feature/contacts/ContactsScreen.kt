package com.asphone.feature.contacts

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asphone.core.common.DuplicateGroup
import com.asphone.core.common.DuplicateReason
import com.asphone.core.common.PhoneNumbers
import com.asphone.core.designsystem.R
import com.asphone.core.designsystem.components.ASphoneCard
import com.asphone.core.designsystem.components.EmptyState
import com.asphone.core.designsystem.components.LoadingIndicator
import com.asphone.core.designsystem.components.PrimaryActionButton
import com.asphone.core.model.ContactSummary
import kotlinx.coroutines.launch

/** Liste des contacts avec recherche, création, et proposition de doublons (sans fusion automatique). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(
    onOpenContact: (Long) -> Unit,
    viewModel: ContactsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showCreate by remember { mutableStateOf(false) }

    val readLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.reload()
    }
    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) showCreate = true
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            readLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        showCreate = true
                    } else {
                        writeLauncher.launch(Manifest.permission.WRITE_CONTACTS)
                    }
                },
            ) {
                Icon(Icons.Filled.PersonAdd, contentDescription = stringResource(R.string.contacts_add))
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.contacts_title),
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = viewModel::findDuplicates) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = stringResource(R.string.contacts_duplicates_action))
                }
            }

            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                placeholder = { Text(stringResource(R.string.contacts_search_hint)) },
            )
            Spacer(Modifier.height(8.dp))

            when {
                state.loading -> LoadingIndicator(
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(32.dp),
                    description = stringResource(R.string.loading),
                )
                state.permissionMissing -> ASphoneCard {
                    Text(
                        text = stringResource(R.string.contacts_permission_missing),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(12.dp))
                    PrimaryActionButton(
                        text = stringResource(R.string.action_grant),
                        onClick = { readLauncher.launch(Manifest.permission.READ_CONTACTS) },
                    )
                }
                state.contacts.isEmpty() -> EmptyState(
                    icon = Icons.Filled.Person,
                    title = stringResource(R.string.contacts_empty),
                    message = stringResource(R.string.contacts_empty_message),
                    modifier = Modifier.weight(1f),
                )
                else -> LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 88.dp),
                ) {
                    items(state.contacts, key = { it.id }) { contact ->
                        ContactRow(contact = contact, onClick = { onOpenContact(contact.id) })
                    }
                }
            }
        }
    }

    if (showCreate) {
        CreateContactDialog(
            onDismiss = { showCreate = false },
            onSave = { name, phone, email ->
                viewModel.createContact(name, phone, email) { showCreate = false }
            },
        )
    }

    if (state.showDuplicates) {
        DuplicatesDialog(
            groups = state.duplicates,
            names = state.duplicateNames,
            onDismiss = viewModel::dismissDuplicates,
        )
    }
}

@Composable
private fun ContactRow(contact: ContactSummary, onClick: () -> Unit) {
    ListItem(
        leadingContent = {
            Column(
                modifier = Modifier
                    .size(40.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    text = contact.displayName.firstOrNull()?.uppercase() ?: "?",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        },
        headlineContent = {
            Text(
                text = contact.displayName.ifBlank { stringResource(R.string.contacts_no_name) },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        },
        supportingContent = {
            Text(contact.primaryPhone ?: stringResource(R.string.contacts_no_phone))
        },
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
private fun CreateContactDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, phone: String, email: String?) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    val nameError = name.isBlank()
    val phoneError = !PhoneNumbers.isPlausible(phone)
    val canSave = !nameError && !phoneError

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.contacts_create_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.contacts_name_label)) },
                    singleLine = true,
                    isError = name.isNotEmpty() && nameError,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(stringResource(R.string.contacts_phone_label)) },
                    singleLine = true,
                    isError = phone.isNotEmpty() && phoneError,
                    supportingText = {
                        if (phone.isNotEmpty() && phoneError) {
                            Text(stringResource(R.string.contacts_phone_invalid))
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(stringResource(R.string.contacts_email_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name, phone, email) },
                enabled = canSave,
            ) {
                Text(stringResource(R.string.action_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}

@Composable
private fun DuplicatesDialog(
    groups: List<DuplicateGroup>,
    names: Map<Long, String>,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.contacts_duplicates_title)) },
        text = {
            if (groups.isEmpty()) {
                Text(stringResource(R.string.contacts_duplicates_none))
            } else {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = stringResource(R.string.contacts_duplicates_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    groups.forEach { group ->
                        Column {
                            Text(
                                text = stringResource(
                                    if (group.reason == DuplicateReason.SAME_PHONE) {
                                        R.string.contacts_duplicates_same_phone
                                    } else {
                                        R.string.contacts_duplicates_same_name
                                    },
                                ),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                            )
                            group.contactIds.forEach { id ->
                                Text(
                                    text = names[id] ?: stringResource(R.string.contacts_no_name),
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        },
    )
}
