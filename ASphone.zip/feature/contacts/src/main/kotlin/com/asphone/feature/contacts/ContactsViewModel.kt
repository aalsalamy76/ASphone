package com.asphone.feature.contacts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.common.DuplicateGroup
import com.asphone.core.common.PhoneNumbers
import com.asphone.core.common.T9
import com.asphone.core.data.contacts.ContactsRepository
import com.asphone.core.model.ContactSummary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ContactsUiState(
    val query: String = "",
    val contacts: List<ContactSummary> = emptyList(),
    val loading: Boolean = true,
    val permissionMissing: Boolean = false,
    val duplicates: List<DuplicateGroup> = emptyList(),
    val duplicateNames: Map<Long, String> = emptyMap(),
    val showDuplicates: Boolean = false,
    val error: Boolean = false,
)

/**
 * Liste et recherche des contacts. La détection de doublons ne fait que proposer des groupes :
 * aucune fusion ni suppression n'est jamais effectuée automatiquement.
 */
@HiltViewModel
class ContactsViewModel @Inject constructor(
    private val contacts: ContactsRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ContactsUiState())
    val uiState: StateFlow<ContactsUiState> = _uiState.asStateFlow()

    private var all: List<ContactSummary> = emptyList()

    init {
        reload()
    }

    fun reload() {
        viewModelScope.launch {
            _uiState.update { it.copy(loading = true) }
            try {
                all = contacts.listAll()
                _uiState.update { it.copy(loading = false, permissionMissing = false, error = false) }
                applyFilter()
            } catch (error: SecurityException) {
                all = emptyList()
                _uiState.update { it.copy(loading = false, permissionMissing = true, contacts = emptyList(), error = false) }
            }
        }
    }

    fun onQueryChange(value: String) {
        _uiState.update { it.copy(query = value) }
        applyFilter()
    }

    fun findDuplicates() {
        viewModelScope.launch {
            try {
                val groups = contacts.findDuplicates()
                _uiState.update {
                    it.copy(
                        duplicates = groups,
                        duplicateNames = all.associate { summary -> summary.id to summary.displayName },
                        showDuplicates = true,
                    )
                }
            } catch (error: SecurityException) {
                _uiState.update { it.copy(permissionMissing = true) }
            }
        }
    }

    fun dismissDuplicates() {
        _uiState.update { it.copy(showDuplicates = false) }
    }

    /** Crée un contact après validation de la saisie par l'écran. */
    fun createContact(name: String, phone: String, email: String?, onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                contacts.create(name.trim(), phone.trim(), email?.trim()?.ifEmpty { null })
                reload()
                onDone()
            } catch (error: SecurityException) {
                _uiState.update { it.copy(permissionMissing = true) }
            } catch (error: IllegalArgumentException) {
                _uiState.update { it.copy(error = true) }
            }
        }
    }

    private fun applyFilter() {
        val query = _uiState.value.query.trim()
        val filtered = if (query.isEmpty()) all else all.filter { matches(it, query) }
        _uiState.update { it.copy(contacts = filtered) }
    }

    private fun matches(contact: ContactSummary, query: String): Boolean {
        val digitsOnly = query.all { it.isDigit() || it == '+' || it == ' ' }
        return contact.displayName.contains(query, ignoreCase = true) ||
            T9.matches(query, contact.displayName) ||
            (digitsOnly && contact.primaryPhone?.let { phone ->
                PhoneNumbers.key(phone).contains(PhoneNumbers.key(query))
            } == true)
    }
}
