package com.asphone.feature.contacts

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asphone.core.data.blocking.BlockedNumbersRepository
import com.asphone.core.data.contacts.ContactDetail
import com.asphone.core.data.contacts.ContactsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Fiche d'un contact : appels, blocage et suppression, toujours après confirmation côté écran. */
@HiltViewModel
class ContactDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val contacts: ContactsRepository,
    private val blocked: BlockedNumbersRepository,
) : ViewModel() {

    private val contactId: Long = checkNotNull(savedStateHandle.get<Long>(ARG_CONTACT_ID)) {
        "Identifiant de contact manquant."
    }

    private val _detail = MutableStateFlow<ContactDetail?>(null)
    val detail: StateFlow<ContactDetail?> = _detail.asStateFlow()

    private val _permissionMissing = MutableStateFlow(false)
    val permissionMissing: StateFlow<Boolean> = _permissionMissing.asStateFlow()

    private val _deleted = MutableStateFlow(false)
    val deleted: StateFlow<Boolean> = _deleted.asStateFlow()

    val blockedNumbers: StateFlow<List<String>> = blocked.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), emptyList())

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            try {
                _detail.value = contacts.detail(contactId)
                _permissionMissing.value = false
            } catch (error: SecurityException) {
                _permissionMissing.value = true
            }
        }
    }

    fun setBlocked(number: String, block: Boolean) {
        viewModelScope.launch {
            if (block) blocked.block(number) else blocked.unblock(number)
        }
    }

    fun delete() {
        viewModelScope.launch {
            try {
                contacts.delete(contactId)
                _deleted.value = true
            } catch (error: SecurityException) {
                _permissionMissing.value = true
            }
        }
    }

    companion object {
        const val ARG_CONTACT_ID = "contactId"
        private const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
